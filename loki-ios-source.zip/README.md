# Loki iOS build

This standalone workspace builds an unsigned iPhone app. Use Actions → Loki iOS unsigned build → Run workflow.

This build uses synthetic image placeholders. XcodeGen generates the project and the scripts fetch pinned public fonts and build the attributed qiaosi scene. Signing and installation happen separately.

qiaosi windowsill: https://github.com/TangfanOVO/qiaosi/tree/309508f1ce637269638810d9b1e43cb5d1aeb7bd/scenes/windowsill (AGPL-3.0). The build script and adapter contain the Loki modifications.
