#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v xcodegen >/dev/null || { echo 'Install XcodeGen on the Mac first: brew install xcodegen'; exit 1; }
xcodebuild -version
python3 scripts/fetch-chat-fonts.py
swift scripts/verify-chat-fonts.swift
swift scripts/generate-app-icon.swift
python3 scripts/prepare-qiaosi-study.py
xcodegen generate --spec project.yml
mkdir -p build
if [[ "${1:-check}" == "check" ]]; then
  # No Apple account or provisioning required; this produces a simulator app, not an IPA.
  xcodebuild -project Loki.xcodeproj -scheme Loki -configuration Debug \
    -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' \
    -derivedDataPath build/DerivedData CODE_SIGNING_ALLOWED=NO build \
    > build/xcodebuild.log 2>&1 || { tail -100 build/xcodebuild.log; exit 1; }
  ditto -c -k --sequesterRsrc --keepParent build/DerivedData/Build/Products/Debug-iphonesimulator/Loki.app build/Loki-simulator.zip
  echo 'Simulator build complete. This file cannot be installed on an iPhone.'
elif [[ "$1" == "device-unsigned" ]]; then
  # Real arm64 iPhone binary. Still NOT installable until every bundle is signed
  # with the matching capabilities and registered-device development profiles.
  xcodebuild -project Loki.xcodeproj -scheme Loki -configuration Debug \
    -sdk iphoneos -destination 'generic/platform=iOS' \
    -derivedDataPath build/DeviceDerivedData CODE_SIGNING_ALLOWED=NO build \
    > build/device-xcodebuild.log 2>&1 || { tail -100 build/device-xcodebuild.log; exit 1; }
  python3 scripts/verify-device-build.py build/DeviceDerivedData/Build/Products/Debug-iphoneos/Loki.app
  ditto -c -k --sequesterRsrc --keepParent build/DeviceDerivedData/Build/Products/Debug-iphoneos/Loki.app build/Loki-device-unsigned.zip
  echo 'Unsigned iPhone build complete. Signing and phone acceptance remain required.'
elif [[ "$1" == "development" ]]; then
  : "${LOKI_TEAM_ID:?Set your Apple Developer Team ID on this Mac}"
  # Requires an authenticated Xcode account, registered device, capabilities and
  # development profiles for the app AND every embedded extension.
  xcodebuild -project Loki.xcodeproj -scheme Loki -configuration Debug \
    -destination 'generic/platform=iOS' -archivePath build/Loki.xcarchive \
    DEVELOPMENT_TEAM="$LOKI_TEAM_ID" -allowProvisioningUpdates archive \
    > build/archive.log 2>&1 || { tail -100 build/archive.log; exit 1; }
  /usr/libexec/PlistBuddy -c "Set :teamID $LOKI_TEAM_ID" ExportOptions.plist
  xcodebuild -exportArchive -archivePath build/Loki.xcarchive \
    -exportOptionsPlist ExportOptions.plist -exportPath build/development \
    -allowProvisioningUpdates > build/export.log 2>&1 || { tail -100 build/export.log; exit 1; }
  echo 'Development export created. Verify signing/entitlements before installing on the registered phone.'
else
  echo 'Usage: bash scripts/build-macos.sh check|device-unsigned|development'; exit 2
fi
