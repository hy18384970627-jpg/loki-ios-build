// Draw the app's vector emblem locally on the build Mac; no remote assets.
import AppKit

let side = 1024
let context = CGContext(data: nil, width: side, height: side, bitsPerComponent: 8,
    bytesPerRow: side * 4, space: CGColorSpaceCreateDeviceRGB(),
    bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue)!
NSGraphicsContext.saveGraphicsState()
NSGraphicsContext.current = NSGraphicsContext(cgContext: context, flipped: false)
let canvas = CGRect(x: 0, y: 0, width: side, height: side)
NSColor(calibratedRed: 0.025, green: 0.08, blue: 0.075, alpha: 1).setFill()
canvas.fill()
let gradient = NSGradient(starting: NSColor(calibratedRed: 0.06, green: 0.22, blue: 0.18, alpha: 1),
                          ending: NSColor(calibratedRed: 0.015, green: 0.045, blue: 0.043, alpha: 1))!
gradient.draw(in: canvas, angle: -55)
let gold = NSColor(calibratedRed: 0.84, green: 0.73, blue: 0.46, alpha: 1)
gold.setStroke()
let ring = NSBezierPath(ovalIn: CGRect(x: 168, y: 168, width: 688, height: 688))
ring.lineWidth = 5
ring.stroke()
// Swept horns frame an initial, rather than borrowing a third-party app icon.
gold.setFill()
let left = NSBezierPath()
left.move(to: CGPoint(x: 432, y: 651))
left.curve(to: CGPoint(x: 286, y: 856), controlPoint1: CGPoint(x: 331, y: 675), controlPoint2: CGPoint(x: 264, y: 730))
left.curve(to: CGPoint(x: 394, y: 604), controlPoint1: CGPoint(x: 231, y: 729), controlPoint2: CGPoint(x: 292, y: 623))
left.close(); left.fill()
let right = NSBezierPath()
right.move(to: CGPoint(x: 592, y: 651))
right.curve(to: CGPoint(x: 738, y: 856), controlPoint1: CGPoint(x: 693, y: 675), controlPoint2: CGPoint(x: 760, y: 730))
right.curve(to: CGPoint(x: 630, y: 604), controlPoint1: CGPoint(x: 793, y: 729), controlPoint2: CGPoint(x: 732, y: 623))
right.close(); right.fill()
let font = NSFont(name: "Baskerville", size: 425) ?? NSFont.systemFont(ofSize: 425, weight: .light)
let letter = NSAttributedString(string: "L", attributes: [.font: font, .foregroundColor: gold])
let size = letter.size()
letter.draw(at: CGPoint(x: (1024 - size.width) / 2, y: 217))
NSGraphicsContext.restoreGraphicsState()
let bitmap = NSBitmapImageRep(cgImage: context.makeImage()!)
let data = bitmap.representation(using: .png, properties: [:])!
let output = URL(fileURLWithPath: "Sources/App/Assets.xcassets/AppIcon.appiconset/AppIcon.png")
try data.write(to: output, options: .atomic)
print("Generated opaque 1024px Loki app icon")
