"""Bundle pinned, unmodified fonts; no runtime font download on the iPhone."""
import hashlib
import io
import json
from pathlib import Path
import urllib.request
import zipfile

root = Path(__file__).resolve().parents[1]
target = root / 'Sources/App/Fonts'
target.mkdir(exist_ok=True)
entries = json.loads((root / 'scripts/chat-font-sources.json').read_text('utf-8'))
for entry in entries:
    path = target / entry['file']
    if path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256']:
        continue
    request = urllib.request.Request(entry['url'], headers={'User-Agent': 'Mozilla/5.0 (Loki private font build)'})
    data = urllib.request.urlopen(request, timeout=90).read(40_000_000)
    if entry.get('zip'):
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            fonts = [p for p in archive.namelist() if p.lower().endswith('.ttf')]
            assert len(fonts) == 1
            data = archive.read(fonts[0])
    assert hashlib.sha256(data).hexdigest() == entry['sha256'], 'Font/source integrity mismatch: ' + entry['file']
    path.write_bytes(data)
print(json.dumps({'verified_font_and_license_files': len(entries), 'runtime_download_required': False}))
