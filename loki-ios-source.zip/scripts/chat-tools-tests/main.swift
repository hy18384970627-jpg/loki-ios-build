import Foundation

let zone = TimeZone(secondsFromGMT: 8 * 3600)!
let formatter = ISO8601DateFormatter()
let now = formatter.date(from: "2026-11-02T21:00:00+08:00")!
if case .specific(let date) = AlarmChatIntent.parse("帮我定明天早上七点半的闹钟", now: now, zone: zone) {
    precondition(date == formatter.date(from: "2026-11-03T07:30:00+08:00")!)
} else { fatalError("Chinese explicit alarm was not parsed") }
if case .specific(let date) = AlarmChatIntent.parse("帮我设一分钟后响的闹钟", now: now, zone: zone) {
    precondition(date.timeIntervalSince(now) == 60)
} else { fatalError("Relative alarm was not parsed") }
if case .course(let day, let lead) = AlarmChatIntent.parse("按课表自动帮我设闹钟，提前40分钟", now: now, zone: zone) {
    precondition(day == nil && lead == 40)
} else { fatalError("Automatic course mode was not parsed") }
for text in ["不要帮我设明天七点的闹钟", "如果帮我定明天七点闹钟会怎样", "我已经定好了七点的闹钟", "帮我取消明天七点的闹钟", "为什么不能设置明天七点的闹钟"] {
    if case .none = AlarmChatIntent.parse(text, now: now, zone: zone) {} else { fatalError("Non-command caused an alarm") }
}
if case .specific(let date) = AlarmChatIntent.parse("帮我定11月9日早上七点的闹钟", now: now, zone: zone) {
    precondition(date == formatter.date(from: "2026-11-09T07:00:00+08:00")!)
} else { fatalError("Explicit date must not become tomorrow") }
if case .needsTime = AlarmChatIntent.parse("帮我定11月31日早上七点的闹钟", now: now, zone: zone) {} else { fatalError("Invalid date must not roll over") }
let midnight = formatter.date(from: "2026-11-06T01:25:00+08:00")!
let confirmedWake = formatter.date(from: "2026-11-06T11:00:00+08:00")!
for text in ["对的，帮我订好", "帮我订好起床闹钟", "确认这个时间，帮我订好明早的闹钟"] {
    if case .confirm = AlarmChatIntent.parse(text, now: midnight, zone: zone) {} else { fatalError("Lost alarm confirmation") }
}
precondition(AlarmChatIntent.confirmedDate(reply: "It needs to be created for 11:00 AM today, November 6—not the seventh.",
    previousRequest: "帮我订好起床闹钟", repliedAt: midnight, now: midnight, zone: zone) == confirmedWake)
precondition(AlarmChatIntent.confirmedDate(reply: "Eleven o’clock, tomorrow morning by your private calendar.",
    previousRequest: "对的，是今天早上，只是我喜欢把它称作明天早上", repliedAt: midnight, now: midnight, zone: zone) == confirmedWake)
precondition(AlarmChatIntent.confirmedDate(reply: "11:00 AM today, November 7.",
    previousRequest: "帮我订闹钟", repliedAt: midnight, now: midnight, zone: zone) == nil)
precondition(AlarmChatIntent.confirmedDate(reply: "11:00 AM today or 12:00 PM today.",
    previousRequest: "帮我订闹钟", repliedAt: midnight, now: midnight, zone: zone) == nil)
precondition(AlarmChatIntent.confirmedDate(reply: "11:00 AM today.",
    previousRequest: "什么时候吃午饭", repliedAt: midnight, now: midnight, zone: zone) == nil)
precondition(AlarmChatIntent.confirmedDate(reply: "11:00 AM today.",
    previousRequest: "帮我订闹钟", repliedAt: midnight, now: midnight.addingTimeInterval(21 * 60), zone: zone) == nil)
for text in ["你明天希望我几点起床呀，帮我订个闹钟吧", "明天早上几点起床", "明早什么时候叫醒我"] {
    if case .wakePlan = AlarmChatIntent.parse(text, now: now, zone: zone) {} else { fatalError("Wake choice failed") }
}
if case .course = AlarmChatIntent.parse("帮我定明天课前的闹钟", now: now, zone: zone) {} else { fatalError("Pre-class keyword failed") }
if case .none = AlarmChatIntent.parse("不要安排我明天几点起床", now: now, zone: zone) {} else { fatalError("Wake negation ignored") }
let original = "(laugh) Come here. You did well! (sigh) Stay with me."
let parts = SentenceReplies.split(original)
precondition(parts.count >= 3 && parts.allSatisfy { !SentenceReplies.visible($0).isEmpty })
func compact(_ text: String) -> String { text.filter { !$0.isWhitespace } }
precondition(compact(parts.joined()) == compact(original))
let attributedDialogue = "The door closed. “Come here. Stay with me.” Loki said quietly. The candle flickered."
let attributedParts = SentenceReplies.split(attributedDialogue)
precondition(attributedParts == ["The door closed.", "“Come here. Stay with me.” Loki said quietly.", "The candle flickered."])
let speakers = "Loki leaned closer and said, “You are late. Sit down.” “I know. I am sorry,” Lorelei replied."
let speakerParts = SentenceReplies.split(speakers)
precondition(speakerParts == ["Loki leaned closer and said, “You are late. Sit down.”", "“I know. I am sorry,” Lorelei replied."])
let continued = "“Wait,” Loki whispered, “do you hear it? Listen.”"
precondition(SentenceReplies.split(continued) == [continued])
let sameSpeaker = "“Come here. Stay close,” Loki said. “I want you here,” Loki added."
precondition(SentenceReplies.split(sameSpeaker) == [sameSpeaker])
let contraction = "‘I’m here. I’ll stay,’ Loki said."
precondition(SentenceReplies.split(contraction) == [contraction])
let newSpeaker = "“Wait.” Lorelei said softly, “I heard it. Stay here.”"
precondition(SentenceReplies.split(newSpeaker) == ["“Wait.”", "Lorelei said softly, “I heard it. Stay here.”"])
let unspoken = "(laugh) “You are late. Again.” Loki said dryly."
precondition(SentenceReplies.split(unspoken) == [unspoken])
precondition(!SentenceReplies.visible(unspoken).contains("(laugh)"))
print("Alarm intent and lossless individual-sentence checks passed")
var silence = VoiceTurnBoundary()
for i in 0..<500 { precondition(!silence.observe(power: -80, elapsed: Double(i) / 10)) }
precondition(!silence.hasSpeech)
var speech = VoiceTurnBoundary()
for i in 0..<4 { precondition(!speech.observe(power: -80, elapsed: Double(i) / 10)) }
for i in 4..<14 { precondition(!speech.observe(power: -20, elapsed: Double(i) / 10)) }
precondition(speech.hasSpeech)
precondition(!speech.observe(power: -80, elapsed: 1.8))
precondition(speech.observe(power: -80, elapsed: 2.6))
var soft = VoiceTurnBoundary()
for i in 0..<4 { _ = soft.observe(power: -82, elapsed: Double(i) / 10) }
for i in 4..<14 { _ = soft.observe(power: -58, elapsed: Double(i) / 10) }
precondition(soft.hasSpeech)
precondition(soft.observe(power: -82, elapsed: 2.6))
var room = VoiceTurnBoundary()
for i in 0..<30 { precondition(!room.observe(power: -38, elapsed: Double(i) / 10)) }
precondition(!room.hasSpeech)
for i in 30..<40 { _ = room.observe(power: -24, elapsed: Double(i) / 10) }
precondition(room.hasSpeech)
precondition(room.observe(power: -38, elapsed: 5.2))
var invalid = VoiceTurnBoundary()
precondition(!invalid.observe(power: .nan, elapsed: 0))
for i in 0..<50 { precondition(!invalid.observe(power: -160, elapsed: Double(i) / 10)) }
precondition(!invalid.calibrated && !invalid.hasSpeech)
print("Adaptive call endpoint: quiet voice, raised background, silence, invalid meter and full pause passed")
precondition(LocationFreshness.usable(timestamp: now.addingTimeInterval(-60), accuracy: 100, now: now))
precondition(!LocationFreshness.usable(timestamp: now.addingTimeInterval(-28 * 60), accuracy: 100, now: now))
precondition(!LocationFreshness.usable(timestamp: now, accuracy: -1, now: now))
precondition(!LocationFreshness.usable(timestamp: now.addingTimeInterval(600), accuracy: 100, now: now))
precondition(!LocationFreshness.usable(timestamp: now, accuracy: .infinity, now: now))
print("Nearby location rejects stale, invalid and future fixes")

var audioOrder = SentencePlaybackQueue<String>()
audioOrder.insert(["first", "prepared-next", "third"], interject: false, preservePreparedNext: false)
precondition(audioOrder.take() == "first")
audioOrder.insert(["hrv-one", "hrv-two"], interject: true, preservePreparedNext: true)
precondition(audioOrder.take() == "prepared-next")
precondition(audioOrder.take() == "hrv-one")
precondition(audioOrder.take() == "hrv-two")
precondition(audioOrder.take() == "third" && audioOrder.isEmpty)
print("HRV speech interjects between sentences without cancelling the prefetch")

precondition(SpeechTransportRetry.shouldRetry(URLError(.secureConnectionFailed), attempt: 0, receivedBytes: 0))
precondition(!SpeechTransportRetry.shouldRetry(URLError(.secureConnectionFailed), attempt: 1, receivedBytes: 0))
precondition(!SpeechTransportRetry.shouldRetry(URLError(.networkConnectionLost), attempt: 0, receivedBytes: 4800))
precondition(!SpeechTransportRetry.shouldRetry(URLError(.serverCertificateUntrusted), attempt: 0, receivedBytes: 0))
precondition(!SpeechTransportRetry.shouldRetry(URLError(.serverCertificateHasBadDate), attempt: 0, receivedBytes: 0))
precondition(!SpeechTransportRetry.shouldRetry(CancellationError(), attempt: 0, receivedBytes: 0))
print("Speech retries only once before PCM begins; certificate failures, cancellation and partial speech never replay")

var call = CallPresentation()
call.begin(); let callID = call.identifier
for _ in 0..<5 { call.minimize(); precondition(call.active && call.minimized && call.identifier == callID); call.restore() }
call.begin(); precondition(call.identifier == callID && call.active)
call.end(); call.minimize(); call.restore(); precondition(!call.active && !call.minimized && call.identifier == nil)
call.begin(); precondition(call.identifier != callID)
print("Call minimize/restore preserves one active session; only hangup ends it")

var hold = HoldRecordingState()
let firstHold = hold.begin()!
precondition(hold.begin() == nil && hold.token == firstHold)
hold.move(vertical: -80); precondition(hold.cancelling)
hold.move(vertical: -20); precondition(!hold.cancelling)
precondition(hold.finish() == true && hold.finish() == nil && !hold.active)
_ = hold.begin(); hold.move(vertical: -65)
precondition(hold.finish() == false && !hold.active)
_ = hold.begin(); hold.cancel()
precondition(hold.token == nil && hold.finish() == nil)
precondition(hold.begin() != firstHold)
print("Hold recording: one press, slide-back, cancel, release-once and interrupted gesture tests passed")

precondition(MusicCallRestorePolicy.canResume(wasPlaying: true, beforeRoute: ["speaker"], afterRoute: ["speaker"], beforeVolume: 0.4, afterVolume: 0.4))
precondition(!MusicCallRestorePolicy.canResume(wasPlaying: true, beforeRoute: ["headphones"], afterRoute: ["speaker"], beforeVolume: 0.4, afterVolume: 0.4))
precondition(!MusicCallRestorePolicy.canResume(wasPlaying: true, beforeRoute: ["speaker"], afterRoute: ["speaker"], beforeVolume: 0.4, afterVolume: 0.7))
precondition(!MusicCallRestorePolicy.canResume(wasPlaying: false, beforeRoute: ["speaker"], afterRoute: ["speaker"], beforeVolume: 0.4, afterVolume: 0.4))
precondition(!MusicCallRestorePolicy.canResume(wasPlaying: true, beforeRoute: [], afterRoute: [], beforeVolume: 0.4, afterVolume: 0.4))
let gains = (0...16).map { MusicCallRestorePolicy.gain(start: 0.18, target: 0.85, step: $0) }
precondition(abs(gains.first! - 0.18) < 0.001 && abs(gains.last! - 0.85) < 0.001)
for pair in zip(gains, gains.dropFirst()) { precondition(pair.1 >= pair.0 && pair.1 - pair.0 < 0.05) }
print("Music call restoration: changed route or raised system volume stays paused; gain ramps without an abrupt jump")
