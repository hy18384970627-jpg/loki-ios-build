// Runs inside the bundled qiaosi scene. Only fixed routes cross the local bridge.
const lokiRoutes = {book: ['works', '作品'], letter: ['interests', '兴趣'], notes: ['journal', '创作近况']};
const lokiGo = document.getElementById('k-go');
const qiaosiAction = lokiGo.onclick;
const ambientActions = new Set(['candle', 'pet', 'quick']);
const lokiExcerpt = {works: '', interests: '', journal: ''};
const postToLoki = body => window.webkit?.messageHandlers.lokiStudy?.postMessage(body);

// Start in the original scene's low-resolution profile. Leave refraction and
// color grading active, but skip the two passes that redraw scene geometry.
goLowQ();
renderer.setPixelRatio(.75);
composer.setPixelRatio(.75);
resize();
bokeh.enabled = false;
candleLight.castShadow = false;
sun.shadow.mapSize.set(512, 512);
sun.shadow.autoUpdate = false;
sun.shadow.needsUpdate = true;
glass.enabled = false;
document.body.classList.add('loki-lite-glass');
let lokiSceneVisible = true;
let lokiLastFrame = -Infinity;
const lokiShadowDirection = new THREE.Vector3();
let lokiClockPaused = false;
function lokiShouldRender(timestamp) {
  if (!lokiSceneVisible || document.hidden) {
    if (!lokiClockPaused) clock.getDelta();
    lokiClockPaused = true;
    return false;
  }
  if (lokiClockPaused) {
    clock.getDelta();
    lokiClockPaused = false;
  }
  if (timestamp - lokiLastFrame < 32) return false;
  lokiLastFrame = timestamp;
  if (!down && lokiShadowDirection.distanceToSquared(cur.sunDir) > .0025) {
    sun.shadow.needsUpdate = true;
    lokiShadowDirection.copy(cur.sunDir);
  }
  glass.enabled = Boolean(focusKey) && !down && focusT > .85;
  document.body.classList.toggle('loki-lite-glass', !glass.enabled);
  if (!glass.enabled) ctlTop = CTL.getBoundingClientRect().top;
  return true;
}

for (const tag of TAGS) {
  const route = lokiRoutes[tag.key];
  if (!route) continue;
  tag.fn = route[1];
  tag.go = '打开' + route[1];
  tag.el.querySelector('b').textContent = route[1];
  tag.el.style.pointerEvents = 'auto';
  tag.el.style.cursor = 'pointer';
  tag.el.setAttribute('role', 'button');
  tag.el.setAttribute('aria-label', route[1]);
  tag.el.tabIndex = 0;
  tag.el.onclick = () => focus(tag.key);
  tag.el.onkeydown = event => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      focus(tag.key);
    }
  };
}

const qiaosiFocus = focus;
focus = key => {
  qiaosiFocus(key);
  if (focusKey !== key) return;
  const route = lokiRoutes[key];
  lokiGo.hidden = !route && !ambientActions.has(key);
  if (route) document.getElementById('k-note').textContent = lokiExcerpt[route[0]] || '打开查看书房内容。';
  else if (!ambientActions.has(key)) {
    document.getElementById('k-title').textContent = BYKEY[key].name;
    document.getElementById('k-note').textContent = '';
  }
};
lokiGo.onclick = event => {
  const route = lokiRoutes[focusKey];
  if (route) postToLoki({open: route[0]});
  else if (ambientActions.has(focusKey)) qiaosiAction(event);
};

window.lokiStudy = {
  setVisible(visible) { lokiSceneVisible = visible; },
  update({works = '', title = '', interests = '', journal = '', notes = []}) {
    Object.assign(lokiExcerpt, {works: title || works, interests, journal});
    fuyue.setBookPage({title, left: works.slice(0, 220), right: works.slice(220, 440)});
    fuyue.setNotes(Array.from({length: NOTE_TEX.length}, (_, index) => notes[index] || ''));
    const route = lokiRoutes[focusKey];
    if (route) document.getElementById('k-note').textContent = lokiExcerpt[route[0]] || '打开查看书房内容。';
  },
};
window.lokiStudy.update({});
fuyue.setNowPlaying({title: '', artist: '', playing: false, pos: 0, dur: 0, lyrics: []});
canvas.addEventListener('webglcontextlost', () => postToLoki({status: 'failed'}), {once: true});
requestAnimationFrame(() => requestAnimationFrame(() => postToLoki({status: 'ready'})));
