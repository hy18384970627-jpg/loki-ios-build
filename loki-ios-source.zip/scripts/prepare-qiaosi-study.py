"""Bundle the pinned qiaosi scene into a self-contained file for WKWebView."""
import io
import json
import platform
import re
import shutil
import subprocess
import tarfile
import tempfile
from pathlib import Path
from urllib.request import urlopen
from zipfile import ZipFile

REVISION = "309508f1ce637269638810d9b1e43cb5d1aeb7bd"
UPSTREAM = f"https://github.com/TangfanOVO/qiaosi/tree/{REVISION}/scenes/windowsill"
ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "Generated" / "QiaosiStudy"
ADAPTER = Path(__file__).with_name("qiaosi-study-adapter.js")


def npm_archive(name, version):
    with urlopen(f"https://registry.npmjs.org/{name}/-/{name.split('/')[-1]}-{version}.tgz", timeout=45) as response:
        return tarfile.open(fileobj=io.BytesIO(response.read()), mode="r:gz")


def bundle(source, temp):
    three = temp / "node_modules" / "three"
    with npm_archive("three", "0.170.0") as archive:
        for member in archive:
            if not member.isfile() or not member.name.startswith("package/"):
                continue
            path = three / member.name.removeprefix("package/")
            if not path.resolve().is_relative_to(three.resolve()):
                raise RuntimeError("Invalid Three.js archive path.")
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(archive.extractfile(member).read())
    os_name = {"Darwin": "darwin", "Windows": "win32", "Linux": "linux"}[platform.system()]
    architecture = {"arm64": "arm64", "aarch64": "arm64", "x86_64": "x64", "AMD64": "x64"}[platform.machine()]
    is_windows = os_name == "win32"
    executable = temp / ("esbuild.exe" if is_windows else "esbuild")
    with npm_archive(f"@esbuild/{os_name}-{architecture}", "0.25.12") as archive:
        executable.write_bytes(archive.extractfile("package/esbuild.exe" if is_windows else "package/bin/esbuild").read())
    executable.chmod(0o755)
    (temp / "scene.mjs").write_text(source, encoding="utf-8")
    subprocess.run([str(executable), "scene.mjs", "--bundle", "--platform=browser", "--format=iife",
                    "--minify", "--outfile=scene.js"], cwd=temp, check=True)
    return (temp / "scene.js").read_text(encoding="utf-8"), three / "LICENSE"


def main():
    with urlopen(f"https://codeload.github.com/TangfanOVO/qiaosi/zip/{REVISION}", timeout=45) as response:
        archive = ZipFile(io.BytesIO(response.read()))
    base = f"qiaosi-{REVISION}/"
    scene = base + "scenes/windowsill/"
    parts = sorted(name for name in archive.namelist()
                   if name.startswith(scene + "src/js/") and name.endswith(".js"))
    if len(parts) != 20:
        raise RuntimeError("Unexpected qiaosi scene layout.")
    source = "\n".join(archive.read(name).decode() for name in parts)
    models = {f"./models/{Path(name).name}": json.loads(archive.read(name))
              for name in archive.namelist()
              if name.startswith(scene + "models/") and name.endswith(".gltf.json")}
    if len(models) != 4:
        raise RuntimeError("Expected all four qiaosi furniture models.")
    model_fetch = "fetch(url).then(r => { if (!r.ok) throw new Error(r.status); return r.json(); })"
    if source.count(model_fetch) != 1:
        raise RuntimeError("Could not find qiaosi's furniture loader.")
    source = source.replace(model_fetch, "Promise.resolve().then(() => structuredClone(LOKI_MODELS[url]))")
    # Decorative scene audio must not take iOS's audio session from chat.
    weather_audio = re.compile(r"^addEventListener\('pointerdown', .*?AC\.resume\(\).*?$", re.M)
    source, weather_count = weather_audio.subn("", source)
    chime = re.compile(r"^const furinRing = \(k = 1\) => \{.*?^\};", re.M | re.S)
    source, chime_count = chime.subn("const furinRing = () => {};", source)
    if weather_count != 1 or chime_count != 1:
        raise RuntimeError("Could not find qiaosi's ambient audio hooks.")
    frame_start = "function frame(){\n  const dt = Math.min(clock.getDelta(), .05), t = clock.elapsedTime;"
    if source.count(frame_start) != 1:
        raise RuntimeError("Could not find qiaosi's frame loop.")
    source = source.replace(frame_start, """function frame(timestamp){
  if (!lokiShouldRender(timestamp)) {
    requestAnimationFrame(frame);
    return;
  }
  const dt = Math.min(clock.getDelta(), .05), t = clock.elapsedTime;""")
    source = source.replace("glassSync(); grade.uniforms.time.value",
                            "if (glass.enabled) glassSync(); grade.uniforms.time.value")
    source = source.replace("stepNP(dt); stepCrisp();", "stepNP(dt);")
    source = f"const LOKI_MODELS = {json.dumps(models, separators=(',', ':'))};\n" + source
    source += "\n" + ADAPTER.read_text(encoding="utf-8")
    template = archive.read(scene + "src/index.template.html").decode()
    template = re.sub(r'<script type="importmap">.*?</script>\s*', "", template, count=1, flags=re.S)
    template = template.replace('<script type="module">', "<script>", 1)
    template = template.replace("草稿 · 演示数据", "LOKI / STUDY", 1)
    template = template.replace("</head>", """<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; connect-src 'none'">
<style>
#k-note { overflow-wrap: anywhere; display: -webkit-box; -webkit-line-clamp: 4; -webkit-box-orient: vertical; overflow: hidden }
#card .go[hidden] { display: none }
#err { background: #12211b; color: #f4efde }
body.loki-lite-glass .tag .p, body.loki-lite-glass #head,
body.loki-lite-glass #ctl > button, body.loki-lite-glass #wxp,
body.loki-lite-glass #back, body.loki-lite-glass #hint, body.loki-lite-glass #card {
  background: linear-gradient(145deg, rgba(45,54,51,.72), rgba(18,28,26,.82)) !important;
  box-shadow: inset 0 0 0 1px rgba(255,255,255,.20) !important;
}
</style>
</head>""", 1)

    with tempfile.TemporaryDirectory(prefix="loki-qiaosi-build-") as temp:
        temp = Path(temp)
        script, three_license = bundle(source, temp)
        script = re.sub(r"</script", lambda match: "<\\/" + match[0][2:], script, flags=re.I)
        OUTPUT.mkdir(parents=True, exist_ok=True)
        (OUTPUT / "windowsill.html").write_text(template.replace("/*@@SCRIPT@@*/", script), encoding="utf-8")
        (OUTPUT / "qiaosi-LICENSE.txt").write_bytes(archive.read(base + "LICENSE"))
        shutil.copyfile(three_license, OUTPUT / "three-LICENSE.txt")
        (OUTPUT / "Source.txt").write_text(
            f"赴约 · 窗台 by TangfanOVO (AGPL-3.0)\n{UPSTREAM}\n"
            "Loki adaptation: offline assets and private, in-app content routing.\n"
            "Three.js 0.170.0 (MIT) https://github.com/mrdoob/three.js/tree/r170\n",
            encoding="utf-8",
        )
        print(f"Bundled {len(models)} original models and {len(parts)} scene modules.")

if __name__ == "__main__":
    main()
