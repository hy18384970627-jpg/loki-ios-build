"""Reject simulator products before preparing any development signatures."""
import argparse
import hashlib
import json
import plistlib
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('app', type=Path)
app = parser.parse_args().app
manifest = json.loads((Path(__file__).parents[1] / 'scripts/chat-font-sources.json').read_text('utf-8'))
info = plistlib.loads((app / 'Info.plist').read_bytes())
font_entries = [entry for entry in manifest if entry['kind'] == 'font']
assert set(info.get('UIAppFonts', [])) == {entry['file'] for entry in font_entries}
for entry in font_entries:
    path = app / entry['file']
    assert path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256'], 'Missing or changed bundled font'
print('All three bundled message fonts matched their pinned source hashes')
bundles = [app, *sorted((app / 'PlugIns').glob('*.appex'))]
assert len(bundles) == 5, 'Expected app plus four Screen Time extensions'
identifiers = set()
for bundle in bundles:
    info = plistlib.loads((bundle / 'Info.plist').read_bytes())
    assert info['CFBundleSupportedPlatforms'] == ['iPhoneOS'], 'Simulator build cannot be installed'
    assert info.get('DTPlatformName') == 'iphoneos'
    identifier = info['CFBundleIdentifier']
    assert identifier not in identifiers
    identifiers.add(identifier)
    binary = bundle / info['CFBundleExecutable']
    architecture = subprocess.check_output(['lipo', '-archs', str(binary)], text=True).strip().split()
    assert 'arm64' in architecture and not {'x86_64', 'i386'} & set(architecture)
    print(f'{bundle.name}: iPhoneOS / arm64 verified; not yet development-signed')
