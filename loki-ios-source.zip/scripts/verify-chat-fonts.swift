import Foundation
import CoreText
import CoreGraphics

let root = URL(fileURLWithPath: FileManager.default.currentDirectoryPath).appendingPathComponent("Sources/App/Fonts")
let fonts = [("CormorantGaramond-SemiBold", "CormorantGaramond-SemiBold.ttf", "London loves you. 123"),
    ("LXGWWenKaiGBLite-Regular", "LXGWWenKaiGBLite-Regular.ttf", "洛基，我想喝咖啡。English 123"),
    ("LXGWNeoZhiSong", "LXGWNeoZhiSong.ttf", "今晚的月光很好。English 123")]
for (name, file, sample) in fonts {
    let url = root.appendingPathComponent(file)
    var error: Unmanaged<CFError>?
    precondition(CTFontManagerRegisterFontsForURL(url as CFURL, .process, &error), "Cannot register font: \(file)")
    let font = CTFontCreateWithName(name as CFString, 22, nil)
    precondition(CTFontCopyPostScriptName(font) as String == name, "Unexpected font fallback")
    let chars = Array(sample.utf16)
    var glyphs = [CGGlyph](repeating: 0, count: chars.count)
    precondition(CTFontGetGlyphsForCharacters(font, chars, &glyphs, chars.count), "Missing sample glyphs: \(name)")
    print("\(name): registered with expected glyph coverage")
}
