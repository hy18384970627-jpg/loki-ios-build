import XCTest

final class LokiInteractionTests: XCTestCase {
    private func preview(_ page: String) -> XCUIApplication {
        let app = XCUIApplication()
        app.launchArguments = ["--loki-design-\(page)", "-AppleLanguages", "(zh-Hans)", "-AppleLocale", "zh_CN"]
        app.launch()
        return app
    }

    private func capture(_ name: String) {
        let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    func testDeskObjectsAndReading() {
        let app = preview("desk")
        let lookOutside = app.webViews.buttons["抬头看窗外 ↑"]
        XCTAssertTrue(lookOutside.waitForExistence(timeout: 25))
        let bookTag = app.webViews.buttons["作品"]
        XCTAssertTrue(bookTag.waitForExistence(timeout: 12))
        Thread.sleep(forTimeInterval: 2)
        capture("loki-desk-room")
        lookOutside.tap()
        let lookDown = app.webViews.buttons["低头看桌上 ↓"]
        XCTAssertTrue(lookDown.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 3)
        capture("loki-desk-window")
        lookDown.tap()

        XCTAssertTrue(bookTag.waitForExistence(timeout: 12))
        bookTag.tap()
        let openBook = app.webViews.buttons["打开作品"]
        XCTAssertTrue(openBook.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 2)
        capture("loki-desk-book")
        openBook.tap()
        let work = app.descendants(matching: .any)["desk-project-window"].firstMatch
        XCTAssertTrue(work.waitForExistence(timeout: 10))
        work.tap()
        XCTAssertTrue(app.navigationBars["阅读"].waitForExistence(timeout: 10))
        capture("loki-desk-reading")
    }

    func testHealthTapAndDrag() {
        let app = preview("health")
        let hrv = app.descendants(matching: .any)["health-card-hrv"].firstMatch
        XCTAssertTrue(hrv.waitForExistence(timeout: 15))
        capture("loki-health-overview")

        hrv.tap()
        let trend = app.descendants(matching: .any)["health-trend-chart"].firstMatch
        XCTAssertTrue(trend.waitForExistence(timeout: 15))
        capture("loki-health-trend-open")
        let trendDate = app.staticTexts["health-trend-date"]
        let priorDate = trendDate.label
        let start = trend.coordinate(withNormalizedOffset: CGVector(dx: 0.86, dy: 0.50))
        let end = trend.coordinate(withNormalizedOffset: CGVector(dx: 0.24, dy: 0.50))
        start.press(forDuration: 0.1, thenDragTo: end)
        XCTAssertNotEqual(priorDate, trendDate.label)
        capture("loki-health-trend-drag")

        app.navigationBars.buttons.firstMatch.tap()
        let sleep = app.descendants(matching: .any)["health-card-sleep"].firstMatch
        XCTAssertTrue(sleep.waitForExistence(timeout: 15))
        sleep.tap()
        XCTAssertTrue(app.navigationBars["睡眠详情"].waitForExistence(timeout: 15))
        func sleepPlot() -> XCUIElement { app.descendants(matching: .any)["sleep-stage-plot"].firstMatch }
        let plot = sleepPlot()
        XCTAssertTrue(plot.waitForExistence(timeout: 15))
        XCTAssertLessThan(plot.frame.maxY, app.tabBars.firstMatch.frame.minY)
        let early = plot.coordinate(withNormalizedOffset: CGVector(dx: 0.23, dy: 0.84))
        early.tap()
        capture("loki-sleep-tap")
        let readout = app.staticTexts["sleep-stage-readout"]
        guard readout.exists else {
            XCTFail("Sleep readout unavailable after tap. App state: \(app.state.rawValue). \(app.debugDescription)")
            return
        }
        let selected = readout.label
        XCTAssertTrue(selected.contains("深睡"), "Sleep readout after tap: \(selected)")
        let selectedPlot = sleepPlot()
        let from = selectedPlot.coordinate(withNormalizedOffset: CGVector(dx: 0.23, dy: 0.84))
        let late = selectedPlot.coordinate(withNormalizedOffset: CGVector(dx: 0.70, dy: 0.65))
        from.press(forDuration: 0.10, thenDragTo: late)
        let dragged = readout.label
        capture("loki-sleep-drag")
        XCTAssertTrue(dragged.contains("核心睡眠"), "Sleep readout after drag: \(dragged)")
        XCTAssertNotEqual(selected, dragged)
    }
}
