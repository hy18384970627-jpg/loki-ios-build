import ManagedSettings
import ManagedSettingsUI
import UIKit

final class ShieldStyle: ShieldConfigurationDataSource {
    private var style: ShieldConfiguration {
        ShieldConfiguration(backgroundBlurStyle: .systemUltraThinMaterialDark,
            backgroundColor: UIColor(red: 0.04, green: 0.12, blue: 0.11, alpha: 1),
            icon: UIImage(systemName: "moon.stars.fill"),
            title: .init(text: "Loki · 专注时间", color: .white),
            subtitle: .init(text: "先做完眼前的事。需要提前结束时，打开 Loki 的专注页。", color: .lightGray),
            primaryButtonLabel: .init(text: "回去做事", color: .black),
            primaryButtonBackgroundColor: UIColor(red: 0.77, green: 0.66, blue: 0.41, alpha: 1))
    }
    override func configuration(shielding application: Application) -> ShieldConfiguration { style }
    override func configuration(shielding application: Application, in category: ActivityCategory) -> ShieldConfiguration { style }
    override func configuration(shielding webDomain: WebDomain) -> ShieldConfiguration { style }
    override func configuration(shielding webDomain: WebDomain, in category: ActivityCategory) -> ShieldConfiguration { style }
}
