import DeviceActivity
import Foundation

final class FocusMonitor: DeviceActivityMonitor {
    override func intervalDidEnd(for activity: DeviceActivityName) {
        super.intervalDidEnd(for: activity)
        if activity == FocusState.activity { FocusState.clear() }
        if activity == NightFocusState.activity { NightFocusState.clearShield() }
    }
    override func intervalDidStart(for activity: DeviceActivityName) {
        super.intervalDidStart(for: activity)
        if activity == DailyLimitState.activity { DailyLimitState.resetDayIfNeeded() }
        if activity == NightFocusState.activity { NightFocusState.clearShield() }
        FocusState.clearIfExpired()
    }
    override func eventDidReachThreshold(_ event: DeviceActivityEvent.Name, activity: DeviceActivityName) {
        super.eventDidReachThreshold(event, activity: activity)
        if activity == DailyLimitState.activity { DailyLimitState.reached(event) }
        if activity == NightFocusState.activity && event == NightFocusState.event { NightFocusState.reached() }
    }
}
