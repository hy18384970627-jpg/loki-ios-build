import Foundation
import Combine

@MainActor final class CallSession: ObservableObject {
    @Published private(set) var presentation = CallPresentation()
    @Published private(set) var muted = false
    @Published private(set) var status = "正在接通…"
    @Published private(set) var startedAt = Date()
    private var foreground = true
    private var worker: Task<Void, Never>?
    private weak var voice: VoiceService?
    var active: Bool { presentation.active }
    var minimized: Bool { presentation.minimized }
    func start(app: AppState, voice: VoiceService, health: HealthService, alarms: AlarmService, focus: FocusService) {
        if active { restore(); return }
        guard worker == nil else { app.notice = "上一通正在结束，请稍后再接通。"; return }
        guard app.paired else { app.notice = "请先配对私人接口。"; return }
        self.voice = voice; muted = false; startedAt = Date(); status = "正在接通…"
        MusicService.shared.callBegan()
        presentation.begin(); app.callActive = true
        worker = Task { [weak self] in
            await self?.run(app: app, voice: voice, health: health, alarms: alarms, focus: focus)
        }
    }
    func minimize() { presentation.minimize() }
    func restore() { presentation.restore() }
    func toggleMute() { muted.toggle(); if muted { voice?.stopRecording(keep: false) } }
    func interrupt() { voice?.stopPlayback() }
    func end() {
        presentation.end(); worker?.cancel()
        voice?.stopRecording(keep: false); voice?.stopPlayback()
    }
    func setForeground(_ value: Bool) {
        foreground = value
        if !value { voice?.stopRecording(keep: false) }
    }
    private func run(app: AppState, voice: VoiceService, health: HealthService, alarms: AlarmService, focus: FocusService) async {
        defer {
            app.callActive = false
            presentation.end()
            worker = nil
            voice.stopRecording(keep: false); voice.stopPlayback()
            MusicService.shared.callEnded()
        }
        do {
            while presentation.active && !Task.isCancelled {
                if app.busy || app.checkingCare {
                    status = "等待当前回复结束…"
                    try await Task.sleep(for: .milliseconds(100)); continue
                }
                if muted || !foreground {
                    status = muted ? "麦克风已静音" : "等待返回 Loki"
                    try await Task.sleep(for: .milliseconds(100)); continue
                }
                status = "正在连接麦克风…"
                try await voice.startRecording(forCall: true)
                var endpoint = VoiceTurnBoundary()
                let captureStart = ContinuousClock.now
                while voice.recording && presentation.active && !muted {
                    try await Task.sleep(for: .milliseconds(100))
                    try Task.checkCancellation()
                    let interval = captureStart.duration(to: .now).components
                    let elapsed = Double(interval.seconds) + Double(interval.attoseconds) / 1e18
                    let ended = endpoint.observe(power: voice.microphoneLevel, elapsed: elapsed)
                    if endpoint.calibrated { status = "在听你说…" }
                    else if elapsed > 5 { throw LokiError.message("没有收到麦克风输入，请检查麦克风权限或耳机连接后重新接通。") }
                    if ended || elapsed >= 80 { break }
                }
                try Task.checkCancellation()
                guard presentation.active && !muted else { voice.stopRecording(keep: false); continue }
                guard endpoint.hasSpeech else { voice.stopRecording(keep: false); continue }
                guard let clip = voice.stopRecording() else { continue }
                status = "Loki 正在想…"
                let success = await app.sendVoice(clip, health: health, voice: voice, alarms: alarms, inCall: true, focus: focus)
                if !success && app.voiceNeedsRepeat && presentation.active && !Task.isCancelled {
                    status = "再说一遍，我在听…"
                    await app.askForRepeat(voice: voice)
                    continue
                }
                if !success && !Task.isCancelled { status = app.messages.last(where: { $0.delivery == .failed })?.deliveryError ?? "这句暂未完成，请关闭后重新接通"; app.notice = status; presentation.end(); break }
            }
        } catch {
            if !Task.isCancelled { status = error.localizedDescription; app.notice = status; presentation.end() }
        }
    }
}
