import Foundation

/// Calibrate the microphone's local noise floor before announcing that we listen.
/// Quiet voices and a raised voice-chat noise floor must not share one fixed gate.
struct VoiceTurnBoundary {
    private(set) var voicedSeconds: Double = 0
    private var lastVoiceAt: Double = 0
    private var calibration: [Float] = []
    private var noiseFloor: Float = -75
    private(set) var calibrated = false
    var silenceSeconds: Double = 1.2
    mutating func observe(power: Float, elapsed: Double, step: Double = 0.1) -> Bool {
        guard power.isFinite, elapsed.isFinite, elapsed >= 0 else { return false }
        if !calibrated {
            // AVAudioRecorder reports its sentinel until real input frames arrive.
            guard power > -155 else { return false }
            calibration.append(power)
            guard calibration.count >= 4 else { return false }
            let sorted = calibration.sorted()
            noiseFloor = max(-100, sorted[sorted.count / 2])
            calibrated = true
            return false
        }
        let threshold = max(-68, noiseFloor + 8)
        if power > threshold {
            voicedSeconds += max(0, min(step, 0.2)); lastVoiceAt = elapsed
        } else {
            // Adapt only from quiet frames so speech cannot raise its own gate.
            noiseFloor = max(-100, noiseFloor * 0.95 + power * 0.05)
        }
        return voicedSeconds >= 0.3 && elapsed - lastVoiceAt >= silenceSeconds
    }
    var hasSpeech: Bool { voicedSeconds >= 0.3 }
}
