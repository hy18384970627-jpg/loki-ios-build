import Foundation

enum MusicLinkError: LocalizedError {
    case missingEntry, trialOnly, missingURL(Int?), invalidURL, wrongSong
    var errorDescription: String? {
        switch self {
        case .missingEntry: return "网易云音源响应缺少歌曲数据。"
        case .trialOnly: return "网易云本次只返回试听音源；尚未取得完整音源，不代表你的账号没有会员。"
        case .missingURL(let code): return "网易云没有返回完整音源地址（歌曲状态 \(code.map(String.init) ?? "未知")）；请在官方 App 对照同一版本。"
        case .invalidURL: return "音源地址未通过 App 的 HTTPS 兼容校验；这不是会员不足提示。"
        case .wrongSong: return "网易云返回的音源与所选歌曲不一致，未播放。"
        }
    }
}

enum MusicPlaybackPolicy {
    static func source(_ response: [String: Any], song: String) throws -> URL {
        guard let entries = response["data"] as? [[String: Any]], let entry = entries.first else { throw MusicLinkError.missingEntry }
        if let id = MusicSong.identifier(entry["id"]), id != song { throw MusicLinkError.wrongSong }
        if let trial = entry["freeTrialInfo"], !(trial is NSNull) { throw MusicLinkError.trialOnly }
        guard let text = entry["url"] as? String, !text.isEmpty else {
            throw MusicLinkError.missingURL((entry["code"] as? NSNumber)?.intValue)
        }
        guard let url = MusicPolicy.mediaURL(text) else { throw MusicLinkError.invalidURL }
        return url
    }
    static func searchQuery(_ text: String) -> String {
        text.replacingOccurrences(of: "—", with: " ").replacingOccurrences(of: "–", with: " ")
            .split(whereSeparator: { $0.isWhitespace }).joined(separator: " ")
    }
    static func candidates(_ songs: [MusicSong]) -> [MusicSong] {
        guard let first = songs.first else { return [] }
        // Only try alternate results for this same title and artist, not a different song.
        func key(_ text: String) -> String { text.lowercased().filter { $0.isLetter || $0.isNumber } }
        return Array(songs.filter { key($0.title) == key(first.title) && key($0.artist) == key(first.artist) }.prefix(4))
    }
    static func playerError(_ error: NSError?) -> String {
        guard let error else { return "播放器报告歌曲加载失败；未确认开始播放。" }
        var result = "歌曲加载失败（\(error.domain) \(error.code)）"
        if let underlying = error.userInfo[NSUnderlyingErrorKey] as? NSError {
            result += "，底层错误 \(underlying.domain) \(underlying.code)"
        }
        return result + "。"
    }
}
