import Foundation

enum LocationFreshness {
    static func usable(timestamp: Date, accuracy: Double, now: Date = Date()) -> Bool {
        let age = now.timeIntervalSince(timestamp)
        return age.isFinite && (-30...300).contains(age) && accuracy.isFinite && (0...5000).contains(accuracy)
    }
}
