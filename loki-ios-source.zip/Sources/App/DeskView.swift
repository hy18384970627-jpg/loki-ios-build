import SwiftUI
import WebKit

struct DeskEnvelope: Codable {
    let data: DeskData
    let revision: String
    let synced_at: Double
    let source_updated_at: Double
}
struct DeskData: Codable {
    let schema: String
    let interests: [DeskInterest]
    let projects: [DeskProject]
    let revisions: [DeskRevision]
    let sessions: [DeskSession]
    let next_at: Double
}
struct DeskInterest: Codable, Identifiable {
    let id: String
    let title: String
    let reason: String
    let status: String
    let updated: Double
}
struct DeskProject: Codable, Identifiable {
    let id: String
    let title: String
    let interest_id: String
    let status: String
    let updated: Double
}
struct DeskRevision: Codable, Identifiable {
    let id: Int
    let project_id: String
    let created: Double
    let kind: String
    let body: String
    let source_ids: [String]
}
struct DeskSession: Codable {
    let action: String
    let note: String
    let started: Double
    let finished: Double
    let next_at: Double
}

struct DeskView: View {
    @EnvironmentObject private var app: AppState
    @Environment(\.scenePhase) private var phase
    @State private var envelope: DeskEnvelope? = PrivateFiles.load("desk-cache.json", fallback: nil)
    @State private var refreshing = false
    @State private var error: String?
    private var visible: Bool { app.selectedTab == 3 && phase == .active }
    var body: some View {
        NavigationStack {
            DeskRoom(envelope: envelope, error: error, refreshing: refreshing, sceneActive: visible) {
                Task { await refresh() }
            }
            .refreshable { await refresh() }
            .task(id: visible) {
                guard visible else { return }
                while !Task.isCancelled {
                    await refresh()
                    do { try await Task.sleep(for: .seconds(15)) } catch { break }
                }
            }
        }.tint(LokiDesign.gold)
    }
    private func refresh() async {
        guard app.paired, !refreshing else { return }
        refreshing = true; defer { refreshing = false }
        do {
            let value = try JSONDecoder().decode(DeskEnvelope.self, from: await app.api.data("/v1/desk", timeout: 8))
            guard value.data.schema == "loki_desk_v1" else { throw LokiError.message("书桌数据版本不匹配。") }
            envelope = value; error = nil
            try PrivateFiles.save(value, "desk-cache.json")
        } catch is CancellationError {} catch { self.error = error.localizedDescription }
    }
}

private func deskStatusName(_ value: String) -> String {
    ["active": "进行中", "dormant": "暂存", "dropped": "已放下", "paused": "暂停",
     "completed": "完成", "abandoned": "已搁置"][value] ?? value
}

private enum DeskShelf: String, CaseIterable {
    case works, interests, journal

    var title: String {
        switch self {
        case .works: "作品"
        case .interests: "兴趣"
        case .journal: "创作近况"
        }
    }

}

struct DeskRoom: View {
    let envelope: DeskEnvelope?
    let error: String?
    let refreshing: Bool
    var sceneActive = true
    let refresh: () -> Void
    @State private var shelf: DeskShelf?
    @State private var sceneState: DeskSceneState = .loading
    @State private var roomVisible = true

    var body: some View {
        ZStack {
            LokiBackdrop()
            if sceneActive {
                QiaosiStudyScene(excerpt: DeskSceneExcerpt(envelope?.data), visible: roomVisible,
                                 open: open, updateState: { sceneState = $0 })
                    .accessibilityIdentifier("loki-qiaosi-scene")
            }
            if sceneActive && sceneState != .ready {
                VStack(spacing: 12) {
                    if sceneState == .loading {
                        ProgressView().tint(LokiDesign.gold)
                        Text("正在打开窗台").font(.footnote)
                    } else {
                        Text("此设备暂时无法显示窗台").font(.headline)
                        Text("仍可从右上角打开书房内容。").font(.footnote)
                    }
                }
                .padding(18).lokiPanel().allowsHitTesting(false)
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            if let error {
                Text(envelope == nil ? error : "\(error) · 显示上次保存的内容")
                    .font(.caption).padding(8).frame(maxWidth: .infinity)
                    .background(LokiDesign.ground)
            }
        }
        .foregroundStyle(LokiDesign.ink)
        .onAppear { roomVisible = true }
        .onDisappear { roomVisible = false }
        .onChange(of: sceneActive) { _, active in
            if !active { sceneState = .loading }
        }
        .navigationTitle("书房").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    ForEach(DeskShelf.allCases, id: \.self) { shelf in
                        Button(shelf.title) { open(shelf) }.disabled(envelope == nil)
                    }
                    Button("刷新书房", systemImage: "arrow.clockwise", action: refresh).disabled(refreshing)
                } label: {
                    Image(systemName: "ellipsis")
                }
                .accessibilityLabel("书房目录")
            }
        }
        .navigationDestination(item: $shelf) { shelf in
            if let desk = envelope?.data {
                DeskShelfPage(shelf: shelf, desk: desk)
            }
        }
    }

    private func open(_ target: DeskShelf) {
        guard envelope != nil else { return }
        shelf = target
    }
}

private enum DeskSceneState { case loading, ready, failed }

private struct DeskSceneExcerpt: Encodable, Equatable {
    let title: String
    let works: String
    let interests: String
    let journal: String
    let notes: [String]

    init(_ desk: DeskData?) {
        let project = desk?.projects.first
        title = project?.title ?? ""
        works = String((desk?.revisions.last { $0.project_id == project?.id }?.body ?? "").prefix(440))
        interests = String((desk?.interests.first?.title ?? "").prefix(120))
        notes = desk?.sessions.prefix(4).map { String($0.note.prefix(120)) } ?? []
        journal = notes.first ?? ""
    }
}

private struct QiaosiStudyScene: UIViewRepresentable {
    let excerpt: DeskSceneExcerpt
    let visible: Bool
    let open: (DeskShelf) -> Void
    let updateState: (DeskSceneState) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(open: open, updateState: updateState) }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        let coordinator = context.coordinator
        config.userContentController.add(coordinator, name: "lokiStudy")
        let web = WKWebView(frame: .zero, configuration: config)
        web.isOpaque = false
        web.backgroundColor = .clear
        web.scrollView.isScrollEnabled = false
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.navigationDelegate = coordinator
        coordinator.web = web
        coordinator.excerpt = excerpt
        coordinator.visible = visible
        if let page = Bundle.main.url(forResource: "windowsill", withExtension: "html", subdirectory: "QiaosiStudy") {
            coordinator.page = page
            web.loadFileURL(page, allowingReadAccessTo: page)
        } else {
            Task { @MainActor in updateState(.failed) }
        }
        return web
    }

    func updateUIView(_ web: WKWebView, context: Context) {
        let coordinator = context.coordinator
        coordinator.open = open
        coordinator.updateState = updateState
        if coordinator.visible != visible {
            coordinator.visible = visible
            coordinator.sendVisibility()
        }
        if coordinator.excerpt != excerpt {
            coordinator.excerpt = excerpt
            coordinator.sendExcerpt()
        }
    }

    static func dismantleUIView(_ web: WKWebView, coordinator: Coordinator) {
        web.stopLoading()
        web.configuration.userContentController.removeScriptMessageHandler(forName: "lokiStudy")
        web.navigationDelegate = nil
    }

    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate {
        weak var web: WKWebView?
        var page: URL?
        var excerpt: DeskSceneExcerpt?
        var visible = true
        var open: (DeskShelf) -> Void
        var updateState: (DeskSceneState) -> Void
        private var ready = false

        init(open: @escaping (DeskShelf) -> Void, updateState: @escaping (DeskSceneState) -> Void) {
            self.open = open
            self.updateState = updateState
        }

        func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.frameInfo.isMainFrame, message.webView === web,
                  let body = message.body as? [String: String] else { return }
            if body["status"] == "ready" {
                ready = true
                updateState(.ready)
                sendVisibility()
                sendExcerpt()
            } else if body["status"] == "failed" {
                ready = false
                updateState(.failed)
            } else if ready, let route = body["open"], let shelf = DeskShelf(rawValue: route) {
                open(shelf)
            }
        }

        func sendExcerpt() {
            guard ready, let excerpt, let bytes = try? JSONEncoder().encode(excerpt),
                  let payload = String(data: bytes, encoding: .utf8) else { return }
            web?.callAsyncJavaScript("window.lokiStudy.update(JSON.parse(payload));",
                                     arguments: ["payload": payload], in: nil, in: .page,
                                     completionHandler: nil)
        }

        func sendVisibility() {
            guard ready else { return }
            web?.evaluateJavaScript("window.lokiStudy.setVisible(\(visible))", completionHandler: nil)
        }

        func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            decisionHandler(action.targetFrame?.isMainFrame == true && action.request.url == page ? .allow : .cancel)
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            updateState(.failed)
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            webView.evaluateJavaScript("typeof window.lokiStudy === 'object'") { [weak self] value, _ in
                if value as? Bool != true { self?.updateState(.failed) }
            }
        }

        func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
            ready = false
            updateState(.failed)
        }
    }
}

private struct DeskShelfPage: View {
    let shelf: DeskShelf
    let desk: DeskData

    var body: some View {
        ScrollView {
            shelfContent(desk).padding(LokiDesign.pageInset).padding(.bottom, 16)
        }
        .background { LokiBackdrop() }.foregroundStyle(LokiDesign.ink)
        .navigationTitle(shelf.title).navigationBarTitleDisplayMode(.inline)
    }

    private func shelfContent(_ desk: DeskData) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .firstTextBaseline) {
                Text(shelf.title).font(.title2.weight(.semibold))
                    .accessibilityAddTraits(.isHeader)
                    .accessibilityIdentifier("desk-shelf-title")
                Spacer()

            }
            switch shelf {
            case .works:
                if desk.projects.isEmpty { empty("暂时没有作品项目。") }
                ForEach(desk.projects) { project in
                    let revisions = desk.revisions.filter { $0.project_id == project.id }
                    NavigationLink {
                        DeskProjectView(project: project, revisions: revisions)
                    } label: {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text(project.title).font(.headline)
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption).foregroundStyle(LokiDesign.gold)
                            }
                            Text(deskStatusName(project.status)).font(.caption).foregroundStyle(LokiDesign.gold)
                            if let latest = revisions.last {
                                Text(latest.body).font(.subheadline).lineLimit(3).foregroundStyle(LokiDesign.muted)
                            }
                        }.deskPaper()
                    }
                    .buttonStyle(.plain)
                    .accessibilityIdentifier("desk-project-\(project.id)")
                }
            case .interests:
                if desk.interests.isEmpty { empty("暂时没有兴趣笔记。") }
                ForEach(desk.interests) { interest in
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text(interest.title).font(.headline)
                            Spacer()
                            Text(deskStatusName(interest.status)).font(.caption).foregroundStyle(LokiDesign.gold)
                        }
                        Text(interest.reason).font(.subheadline).textSelection(.enabled)
                    }.deskPaper()
                }
            case .journal:
                if desk.sessions.isEmpty { empty("暂时没有创作记录。") }
                ForEach(Array(desk.sessions.prefix(20).enumerated()), id: \.offset) { entry in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(Date(timeIntervalSince1970: entry.element.finished), format: .dateTime.month().day().hour().minute())
                            .font(.caption).foregroundStyle(LokiDesign.gold)
                        Text(entry.element.note).font(.subheadline).textSelection(.enabled)
                    }.deskPaper()
                }
            }
        }
    }

    private func empty(_ text: String) -> some View {
        Text(text).font(.subheadline).foregroundStyle(LokiDesign.muted).deskPaper()
    }
}

private struct DeskProjectView: View {
    let project: DeskProject
    let revisions: [DeskRevision]
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                LokiEyebrow(title: "LOKI  /  MANUSCRIPTS")
                Text(project.title).font(.system(.largeTitle, design: .serif).weight(.semibold))
                    .accessibilityAddTraits(.isHeader)
                if revisions.isEmpty { Text("这个项目还没有作品版本。").deskPaper() }
                ForEach(revisions.reversed()) { revision in
                    VStack(alignment: .leading, spacing: 12) {
                        Text(revision.kind == "original" ? "作品" : "来源笔记")
                            .font(.caption.weight(.semibold)).foregroundStyle(LokiDesign.gold)
                        Text(Date(timeIntervalSince1970: revision.created), format: .dateTime.year().month().day().hour().minute())
                            .font(.caption).foregroundStyle(LokiDesign.muted)
                        Text(.init(revision.body)).lineSpacing(5).textSelection(.enabled)
                        if !revision.source_ids.isEmpty {
                            Text("引用编号：" + revision.source_ids.joined(separator: "、"))
                                .font(.caption2).foregroundStyle(LokiDesign.muted)
                        }
                    }.deskPaper()
                }
            }.padding(LokiDesign.pageInset).padding(.bottom, 16)
        }
        .background { LokiBackdrop() }.foregroundStyle(LokiDesign.ink)
        .navigationTitle("阅读").navigationBarTitleDisplayMode(.inline)
    }
}

private extension View {
    func deskPaper() -> some View {
        padding(16).frame(maxWidth: .infinity, alignment: .leading).lokiPanel()
    }
}
