import SwiftUI

struct DeskEnvelope: Codable {
    let data: DeskData
    let revision: String
    let synced_at: Double
    let source_updated_at: Double
}
struct DeskData: Codable {
    let schema: String
    let interests: [DeskInterest]
    let projects: [DeskProject]
    let revisions: [DeskRevision]
    let sessions: [DeskSession]
    let next_at: Double
}
struct DeskInterest: Codable, Identifiable {
    let id: String
    let title: String
    let reason: String
    let status: String
    let updated: Double
}
struct DeskProject: Codable, Identifiable {
    let id: String
    let title: String
    let interest_id: String
    let status: String
    let updated: Double
}
struct DeskRevision: Codable, Identifiable {
    let id: Int
    let project_id: String
    let created: Double
    let kind: String
    let body: String
    let source_ids: [String]
}
struct DeskSession: Codable {
    let action: String
    let note: String
    let started: Double
    let finished: Double
    let next_at: Double
}

struct DeskView: View {
    @EnvironmentObject private var app: AppState
    @Environment(\.scenePhase) private var phase
    @State private var envelope: DeskEnvelope?
    @State private var refreshing = false
    @State private var error: String?
    private var visible: Bool { app.selectedTab == 3 && phase == .active }
    var body: some View {
        NavigationStack {
            List {
                if let envelope {
                    Section("Loki 的书桌") {
                        shelfLink(.works, count: envelope.data.projects.count, icon: "doc.text", desk: envelope.data)
                        shelfLink(.interests, count: envelope.data.interests.count, icon: "sparkles", desk: envelope.data)
                        shelfLink(.journal, count: envelope.data.sessions.count, icon: "clock", desk: envelope.data)
                    }
                    if let latest = envelope.data.revisions.last,
                       let project = envelope.data.projects.first(where: { $0.id == latest.project_id }) {
                        Section("最近写下的") {
                            NavigationLink {
                                DeskProjectView(project: project, revisions: envelope.data.revisions.filter { $0.project_id == project.id })
                            } label: {
                                VStack(alignment: .leading, spacing: 8) {
                                    Text(project.title).font(.headline)
                                    Text(latest.body).font(.subheadline).foregroundStyle(LokiDesign.muted).lineLimit(4)
                                }.padding(.vertical, 6)
                            }
                        }
                    }
                    if envelope.source_updated_at > 0 {
                        Section {
                            LabeledContent("内容更新") {
                                Text(Date(timeIntervalSince1970: envelope.source_updated_at),
                                     format: .dateTime.month().day().hour().minute())
                            }.font(.caption).foregroundStyle(LokiDesign.muted)
                        }
                    }
                } else if refreshing {
                    ProgressView("正在同步书桌…")
                } else {
                    ContentUnavailableView("暂无已同步的书桌内容", systemImage: "books.vertical",
                                           description: Text("下拉刷新，或连接 Loki 的私人接口后再试。"))
                }
                if let error {
                    Section { Text(error).font(.footnote).foregroundStyle(LokiDesign.muted) }
                }
            }
            .scrollContentBackground(.hidden)
            .background { LokiBackdrop() }
            .foregroundStyle(LokiDesign.ink)
            .navigationTitle("书桌").navigationBarTitleDisplayMode(.inline)
            .refreshable { await refresh() }
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("刷新书桌", systemImage: "arrow.clockwise") { Task { await refresh() } }
                        .disabled(refreshing)
                }
            }
            .task(id: visible) {
                guard visible else { return }
                let cached = await DeskSync.shared.cached()
                guard !Task.isCancelled else { return }
                if let cached, cached.revision != envelope?.revision { envelope = cached }
                while !Task.isCancelled {
                    await refresh()
                    do { try await Task.sleep(for: .seconds(60)) } catch { break }
                }
            }
        }.tint(LokiDesign.gold)
    }

    private func shelfLink(_ shelf: DeskShelf, count: Int, icon: String, desk: DeskData) -> some View {
        NavigationLink {
            DeskShelfPage(shelf: shelf, desk: desk)
        } label: {
            HStack {
                Label(shelf.title, systemImage: icon)
                Spacer()
                Text(count, format: .number).foregroundStyle(LokiDesign.muted)
            }
        }
    }

    private func refresh() async {
        guard !refreshing else { return }
        guard app.paired else { error = "尚未连接私人接口，已保存的书桌内容仍可阅读。"; return }
        refreshing = true; defer { refreshing = false }
        do {
            try await DeskSync.shared.refresh(api: app.api)
            let value = await DeskSync.shared.cached()
            guard !Task.isCancelled else { return }
            guard let value else { throw LokiError.message("书桌内容尚未同步，请稍后刷新。") }
            if value.revision != envelope?.revision { envelope = value }
            error = nil
        } catch is CancellationError {} catch { self.error = error.localizedDescription }
    }
}

private func deskStatusName(_ value: String) -> String {
    ["active": "进行中", "dormant": "暂存", "dropped": "已放下", "paused": "暂停",
     "completed": "完成", "abandoned": "已搁置"][value] ?? value
}

private enum DeskShelf: String, CaseIterable {
    case works, interests, journal

    var title: String {
        switch self {
        case .works: "作品"
        case .interests: "兴趣"
        case .journal: "创作近况"
        }
    }

}

private struct DeskShelfPage: View {
    let shelf: DeskShelf
    let desk: DeskData

    var body: some View {
        ScrollView {
            shelfContent(desk).padding(LokiDesign.pageInset).padding(.bottom, 16)
        }
        .background { LokiBackdrop() }.foregroundStyle(LokiDesign.ink)
        .navigationTitle(shelf.title).navigationBarTitleDisplayMode(.inline)
    }

    private func shelfContent(_ desk: DeskData) -> some View {
        LazyVStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .firstTextBaseline) {
                Text(shelf.title).font(.title2.weight(.semibold))
                    .accessibilityAddTraits(.isHeader)
                    .accessibilityIdentifier("desk-shelf-title")
                Spacer()

            }
            switch shelf {
            case .works:
                if desk.projects.isEmpty { empty("暂时没有作品项目。") }
                ForEach(desk.projects) { project in
                    let revisions = desk.revisions.filter { $0.project_id == project.id }
                    NavigationLink {
                        DeskProjectView(project: project, revisions: revisions)
                    } label: {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text(project.title).font(.headline)
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption).foregroundStyle(LokiDesign.gold)
                            }
                            Text(deskStatusName(project.status)).font(.caption).foregroundStyle(LokiDesign.gold)
                            if let latest = revisions.last {
                                Text(latest.body).font(.subheadline).lineLimit(3).foregroundStyle(LokiDesign.muted)
                            }
                        }.deskPaper()
                    }
                    .buttonStyle(.plain)
                    .accessibilityIdentifier("desk-project-\(project.id)")
                }
            case .interests:
                if desk.interests.isEmpty { empty("暂时没有兴趣笔记。") }
                ForEach(desk.interests) { interest in
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text(interest.title).font(.headline)
                            Spacer()
                            Text(deskStatusName(interest.status)).font(.caption).foregroundStyle(LokiDesign.gold)
                        }
                        Text(interest.reason).font(.subheadline).textSelection(.enabled)
                    }.deskPaper()
                }
            case .journal:
                if desk.sessions.isEmpty { empty("暂时没有创作记录。") }
                ForEach(Array(desk.sessions.prefix(20).enumerated()), id: \.offset) { entry in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(Date(timeIntervalSince1970: entry.element.finished), format: .dateTime.month().day().hour().minute())
                            .font(.caption).foregroundStyle(LokiDesign.gold)
                        Text(entry.element.note).font(.subheadline).textSelection(.enabled)
                    }.deskPaper()
                }
            }
        }
    }

    private func empty(_ text: String) -> some View {
        Text(text).font(.subheadline).foregroundStyle(LokiDesign.muted).deskPaper()
    }
}

private struct DeskProjectView: View {
    let project: DeskProject
    let revisions: [DeskRevision]
    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 16) {
                LokiEyebrow(title: "LOKI  /  MANUSCRIPTS")
                Text(project.title).font(.system(.largeTitle, design: .serif).weight(.semibold))
                    .accessibilityAddTraits(.isHeader)
                if revisions.isEmpty { Text("这个项目还没有作品版本。").deskPaper() }
                ForEach(revisions.reversed()) { revision in
                    VStack(alignment: .leading, spacing: 12) {
                        Text(revision.kind == "original" ? "作品" : "来源笔记")
                            .font(.caption.weight(.semibold)).foregroundStyle(LokiDesign.gold)
                        Text(Date(timeIntervalSince1970: revision.created), format: .dateTime.year().month().day().hour().minute())
                            .font(.caption).foregroundStyle(LokiDesign.muted)
                        Text(.init(revision.body)).lineSpacing(5).textSelection(.enabled)
                        if !revision.source_ids.isEmpty {
                            Text("引用编号：" + revision.source_ids.joined(separator: "、"))
                                .font(.caption2).foregroundStyle(LokiDesign.muted)
                        }
                    }.deskPaper()
                }
            }.padding(LokiDesign.pageInset).padding(.bottom, 16)
        }
        .background { LokiBackdrop() }.foregroundStyle(LokiDesign.ink)
        .navigationTitle("阅读").navigationBarTitleDisplayMode(.inline)
    }
}

private extension View {
    func deskPaper() -> some View {
        padding(16).frame(maxWidth: .infinity, alignment: .leading).lokiPanel()
    }
}
