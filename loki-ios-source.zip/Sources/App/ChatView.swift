import SwiftUI
import PhotosUI
import UIKit
import Translation

struct ChatView: View {
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let previewMessages: [ChatItem]?

    init(previewMessages: [ChatItem]? = nil) {
        self.previewMessages = previewMessages
    }
    @State private var showingMusic = false
    @State private var showingShopping = false
    @EnvironmentObject private var app: AppState
    @EnvironmentObject private var voice: VoiceService
    @EnvironmentObject private var health: HealthService
    @EnvironmentObject private var focus: FocusService
    @EnvironmentObject private var notifications: NotificationService
    @EnvironmentObject private var alarms: AlarmService
    @EnvironmentObject private var device: DeviceTools
    @State private var submitting = false
    @State private var voiceInput = false
    @State private var hold = HoldRecordingState()
    @State private var recordStart: Task<Void, Never>?
    @SwiftUI.FocusState private var composerFocused: Bool
    @AppStorage("lokiDoubleTapReplayTipSeen") private var replayTipSeen = false
    @State private var replayTip: UUID?
    @AppStorage("autoVoice") private var autoVoice = true
    @State private var photo: PhotosPickerItem?
    @State private var image: UIImage?
    @State private var visibleMessageCount = 80
    @EnvironmentObject private var call: CallSession
    private var messages: [ChatItem] { Array((previewMessages ?? app.messages).suffix(visibleMessageCount)) }
    private var paired: Bool { previewMessages != nil || app.paired }
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 9) {
                            if (previewMessages ?? app.messages).count > visibleMessageCount {
                                Button("加载更早的消息") { visibleMessageCount += 80 }
                                    .font(.footnote).foregroundStyle(LokiDesign.gold)
                                    .frame(maxWidth: .infinity).padding(.vertical, 10)
                            }
                            if messages.isEmpty {
                                VStack(spacing: 10) {
                                    LokiPortrait(size: 56)
                                    Text("与 Loki 对话").font(.title3.weight(.semibold))
                                    Text(paired ? "发一句话，或者按住说话。" : "在设置中扫描配对码后即可聊天。")
                                        .font(.footnote).foregroundStyle(LokiDesign.muted)
                                }.padding(24).frame(maxWidth: .infinity).lokiPanel()
                            }
                            ForEach(Array(messages.enumerated()), id: \.element.id) { index, message in
                                let previous = index > 0 ? messages[index - 1] : nil
                                let newDay = previous.map { !Calendar.current.isDate($0.date, inSameDayAs: message.date) } ?? true
                                let newGroup = newDay || previous?.role != message.role
                                    || message.date.timeIntervalSince(previous?.date ?? message.date) > 300
                                if newDay { ChatDayDivider(date: message.date) }
                                ChatBubble(message: message, beginsGroup: newGroup,
                                           canReplay: message.recordedVoice != nil || paired,
                                           isPlaying: voice.playing && voice.playingMessageID == message.id,
                                           canRetry: !app.callActive,
                                           preview: previewMessages != nil,
                                           playbackFraction: { voice.recordedPlaybackFraction(for: message.id) },
                                           retry: {
                                    Task { await app.retry(message.id, health: health, voice: voice, autoVoice: autoVoice, alarms: alarms, focus: focus) }
                                }) {
                                    if voice.playing && voice.playingMessageID == message.id { voice.stopPlayback() }
                                    else if let clip = message.recordedVoice { voice.playRecording(clip, messageID: message.id) }
                                    else { voice.speak(message.voiceText, api: app.api, messageID: message.id) }
                                }.padding(.top, newGroup && !newDay ? 6 : 0).id(message.id)
                            }
                            if app.checkingCare || app.busy {
                                HStack(spacing: 8) {
                                    LokiPortrait(size: 28)
                                    ProgressView().controlSize(.small)
                                    Text(app.voiceStage.isEmpty ? "Loki 正在回复…" : app.voiceStage)
                                        .font(.caption).foregroundStyle(.secondary)
                                }.accessibilityLabel("Loki 正在回复")
                            }
                            ForEach(app.commands) { command in
                                GroupBox("设备请求 · \(command.name)") {
                                    VStack(alignment: .leading, spacing: 10) {
                                        Text(command.summary).font(.caption)
                                        Text("只在当前手机确认后执行；过期自动作废。").font(.caption2).foregroundStyle(.secondary)
                                        HStack {
                                            Button("允许一次") {
                                                Task { await app.execute(command, health: health, focus: focus, notifications: notifications, alarms: alarms, device: device) }
                                            }.disabled(app.commandBusy)
                                            Button("拒绝", role: .cancel) { Task { await app.decline(command) } }
                                        }
                                    }.frame(maxWidth: .infinity, alignment: .leading)
                                }
                            }
                        }.padding(.horizontal, LokiDesign.pageInset).padding(.vertical, 14)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .contentShape(Rectangle())
                    .scrollDismissesKeyboard(.interactively)
                    .defaultScrollAnchor(.bottom, for: .initialOffset)
                    .simultaneousGesture(TapGesture().onEnded { composerFocused = false })
                    .onAppear {
                        if let last = messages.last { proxy.scrollTo(last.id, anchor: .bottom) }
                    }
                    .onChange(of: scenePhase) { _, phase in
                        if phase == .active, app.selectedTab == 0, let last = app.messages.last {
                            proxy.scrollTo(last.id, anchor: .bottom)
                        }
                    }
                    .onChange(of: app.selectedTab) { _, tab in
                        if tab == 0, let last = app.messages.last { proxy.scrollTo(last.id, anchor: .bottom) }
                    }
                    .onChange(of: app.messages.count) { _, _ in
                        guard let last = app.messages.last else { return }
                        if reduceMotion { proxy.scrollTo(last.id, anchor: .bottom) }
                        else { withAnimation { proxy.scrollTo(last.id, anchor: .bottom) } }
                    }
                }
                if replayTip != nil {
                    Label("双击重播原声，长按翻译中文", systemImage: "hand.tap")
                        .font(.footnote).foregroundStyle(LokiDesign.gold)
                        .padding(.horizontal, 12).padding(.vertical, 7)
                        .lokiPanel(fill: LokiDesign.raised, radius: 12)
                        .padding(.bottom, 6)
                        .accessibilityIdentifier("loki-replay-tip")
                }
                if hold.active {
                    Text(hold.cancelling ? "松开取消" : "正在录音 · \(Int(voice.recordingSeconds)) 秒 · 上滑取消")
                        .font(.caption).foregroundStyle(hold.cancelling ? LokiDesign.danger : LokiDesign.ink).padding(8)
                }
                if let clip = voice.draftRecording {
                    HStack(spacing: 16) {
                        Button { voice.playRecording(clip) } label: {
                            Label("\(Int(ceil(clip.duration))) 秒", systemImage: "waveform")
                        }.accessibilityLabel("试听待发送语音")
                        Spacer()
                        Button("取消", role: .cancel) { voice.stopPlayback(); voice.discardDraft() }
                    }.padding(12).background(LokiDesign.raised)
                }
                if let image {
                    HStack {
                        Image(uiImage: image).resizable().scaledToFit().frame(width: 70, height: 70)
                        Spacer()
                        Button { self.image = nil; photo = nil } label: { Image(systemName: "xmark.circle.fill") }
                            .accessibilityLabel("移除照片")
                    }.padding(.horizontal)
                }
                ChatDraftScope { draft in
                    HStack(alignment: .bottom, spacing: 5) {
                        PhotosPicker(selection: $photo, matching: .images) { Image(systemName: "photo") }
                            .frame(width: 44, height: 44).contentShape(Rectangle()).accessibilityLabel("添加照片")
                            .disabled(voiceInput || voice.recording || voice.draftRecording != nil)
                        Button {
                            cancelHeldRecording(); voiceInput.toggle(); composerFocused = !voiceInput
                        } label: { Image(systemName: voiceInput ? "keyboard" : "mic") }
                            .frame(width: 44, height: 44).contentShape(Rectangle()).accessibilityLabel(voiceInput ? "切换文字输入" : "切换按住说话")
                            .disabled(image != nil || voice.draftRecording != nil || app.callActive)
                        if voiceInput {
                            Text(hold.active ? (hold.cancelling ? "松开取消" : "松开发送") : "按住说话")
                                .font(.body).frame(maxWidth: .infinity, minHeight: 44)
                                .lokiPanel(fill: hold.cancelling ? LokiDesign.danger.opacity(0.18) : (hold.active ? LokiDesign.owner : LokiDesign.raised), radius: 18)
                                .contentShape(Rectangle())
                                .gesture(DragGesture(minimumDistance: 0)
                                    .onChanged { value in
                                        beginHeldRecording(); hold.move(vertical: Double(value.translation.height))
                                    }.onEnded { value in hold.move(vertical: Double(value.translation.height)); finishHeldRecording() })
                                .accessibilityLabel("按住说话，松开发送，上滑取消")
                                .allowsHitTesting(app.paired && !submitting && !app.callActive && (hold.active || voice.draftRecording == nil))
                        } else {
                            TextField("发条消息", text: draft, axis: .vertical).lineLimit(1...5)
                            .font(ChatTypography.owner)
                            .padding(.horizontal, 12).padding(.vertical, 11)
                            .lokiPanel(fill: LokiDesign.raised, radius: 18)
                            .accessibilityLabel("消息")
                            .focused($composerFocused)
                            .disabled(voice.recording || voice.draftRecording != nil)
                        }
                        Button {
                            guard !submitting else { return }
                            submitting = true
                            composerFocused = false
                            if let clip = voice.draftRecording {
                                voice.draftRecording = nil; voice.stopPlayback()
                                Task {
                                    defer { submitting = false }
                                    let sent = await app.sendVoice(clip, health: health, voice: voice, alarms: alarms, autoVoice: autoVoice, focus: focus)
                                    if !sent && !app.messages.contains(where: { $0.id == clip.id }) { voice.draftRecording = clip }
                                }
                                return
                            }
                            let input = draft.wrappedValue
                            let text = input.isEmpty && image != nil ? "看看这张照片。" : input
                            let data = image?.jpegData(compressionQuality: 0.65)
                            draft.wrappedValue = ""; image = nil; photo = nil
                            Task {
                                defer { submitting = false }
                                await app.send(text, image: data, health: health.snapshotForChat,
                                               voice: voice, autoVoice: autoVoice, alarms: alarms, focus: focus, healthService: health)
                            }
                        } label: {
                            Image(systemName: "arrow.up").font(.system(size: 16, weight: .semibold))
                                .foregroundStyle(LokiDesign.ground)
                                .frame(width: 34, height: 34)
                                .background(LokiDesign.gold, in: Circle())
                        }
                            .frame(width: 44, height: 44).contentShape(Rectangle()).accessibilityLabel("发送")
                            .disabled(submitting || (draft.wrappedValue.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && image == nil && voice.draftRecording == nil) || voice.recording)
                    }.padding(.horizontal, 12).padding(.vertical, 8)
                        .background(LokiDesign.ground.opacity(0.98))
                        .overlay(alignment: .top) { Rectangle().fill(LokiDesign.line).frame(height: 1) }
                }
            }
            .background {
                ChatWallpaperView(name: previewMessages == nil ? app.wallpaperName : "Wallpaper06").ignoresSafeArea()
            }
            .foregroundStyle(LokiDesign.ink)
            .tint(LokiDesign.gold)
            .navigationTitle("").navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(.hidden, for: .navigationBar)
            .onChange(of: voice.finishedReplyID) { _, id in
                guard let id, !replayTipSeen, !app.callActive, app.selectedTab == 0,
                      scenePhase == .active, messages.contains(where: { $0.id == id && $0.role == "assistant" })
                else { return }
                replayTipSeen = true
                replayTip = id
            }
            .task(id: replayTip) {
                guard replayTip != nil else { return }
                do { try await Task.sleep(for: .seconds(4)) } catch { return }
                replayTip = nil
            }
            .onChange(of: voice.errorMessage) { _, value in if let value { app.notice = value; voice.errorMessage = nil } }
            .onChange(of: composerFocused) { _, value in app.composing = value }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Menu {
                        Button("一起听", systemImage: "music.note") { composerFocused = false; showingMusic = true }
                        Button("淘宝", systemImage: "bag") { composerFocused = false; showingShopping = true }
                    } label: { Image(systemName: "sparkles") }
                        .accessibilityLabel("音乐与淘宝")
                }
                ToolbarItem(placement: .principal) {
                    Image("LokiSignature")
                        .renderingMode(.template)
                        .resizable().scaledToFit()
                        .foregroundStyle(.primary)
                        .frame(width: 34, height: 17)
                        .background {
                            Capsule().fill(LokiDesign.ground.opacity(0.8))
                                .frame(width: 29, height: 17)
                        }
                        .accessibilityLabel("Loki")
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { composerFocused = false; call.start(app: app, voice: voice, health: health, alarms: alarms, focus: focus) } label: { Image(systemName: "phone") }
                        .accessibilityLabel("与 Loki 语音通话")
                        .disabled(!call.active && (!app.paired || app.busy || app.checkingCare || voice.recording || voice.draftRecording != nil))
                }
                ToolbarItem(placement: .topBarTrailing) {
                    if composerFocused {
                        Button { composerFocused = false } label: { Image(systemName: "keyboard.chevron.compact.down") }
                            .frame(width: 44, height: 44).contentShape(Rectangle())
                            .accessibilityLabel("收起键盘")
                    }
                }
                ToolbarItem(placement: .topBarLeading) {
                    if voice.playing {
                        Button { voice.stopPlayback() } label: { Image(systemName: "stop.circle") }
                            .accessibilityLabel("停止播放").accessibilityHint(voice.streamStatus)
                    }
                }
                ToolbarItem(placement: .topBarTrailing) { Button("设备请求", systemImage: "arrow.clockwise") { Task { await app.refreshCommands() } } }
            }
            .onChange(of: photo) { _, selection in
                Task { if let data = try? await selection?.loadTransferable(type: Data.self) { image = MobileImage.from(data) } }
            }
            .sheet(isPresented: $showingMusic) { NavigationStack { MusicView() } }
            .sheet(isPresented: $showingShopping) { NavigationStack { ShoppingView() } }
            .onDisappear { replayTip = nil; cancelHeldRecording(); composerFocused = false; app.composing = false }
            .onChange(of: scenePhase) { _, phase in if phase != .active { cancelHeldRecording() } }
        }
    }
    private func beginHeldRecording() {
        guard !hold.active, recordStart == nil, !voice.recording, voice.draftRecording == nil,
              app.paired, !app.callActive, !submitting, let token = hold.begin() else { return }
        composerFocused = false
        recordStart = Task { @MainActor in
            defer { recordStart = nil }
            do {
                try await voice.startRecording()
                guard hold.token == token, !Task.isCancelled else { voice.stopRecording(keep: false); return }
            } catch {
                voice.releaseAudioSessionIfIdle()
                if hold.token == token { hold.cancel(); if !(error is CancellationError) { app.tell(error) } }
            }
        }
    }
    private func finishHeldRecording() {
        guard let send = hold.finish() else { return }
        recordStart?.cancel()
        guard send else { voice.stopRecording(keep: false); voice.discardDraft(); return }
        let clip = voice.stopRecording() ?? voice.draftRecording
        guard let clip else { return }
        voice.draftRecording = nil
        submitting = true
        Task { @MainActor in
            defer { submitting = false }
            let sent = await app.sendVoice(clip, health: health, voice: voice, alarms: alarms, autoVoice: autoVoice, focus: focus)
            if !sent && !app.messages.contains(where: { $0.id == clip.id }) { voice.draftRecording = clip }
        }
    }
    private func cancelHeldRecording() {
        guard hold.active else { return }
        hold.cancel(); recordStart?.cancel(); voice.stopRecording(keep: false); voice.discardDraft()
    }
}

private struct ChatDayDivider: View {
    let date: Date
    var body: some View {
        HStack(spacing: 12) {
            Rectangle().fill(LokiDesign.line).frame(height: 1)
            Text(date, format: .dateTime.month().day()).font(.caption2.monospacedDigit())
                .fixedSize().foregroundStyle(LokiDesign.muted)
            Rectangle().fill(LokiDesign.line).frame(height: 1)
        }.padding(.vertical, 6)
    }
}

private struct ChatWallpaperView: View {
    let name: String
    private var preserveFullFrame: Bool {
        guard let image = UIImage(named: name) else { return false }
        return image.size.width > image.size.height * 0.75 || name == "Wallpaper11" || name == "Wallpaper17"
    }
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                LokiDesign.ground
                Image(name).resizable().scaledToFill()
                    .frame(width: geometry.size.width, height: geometry.size.height).clipped()
                    .blur(radius: preserveFullFrame ? 24 : 0)
                if preserveFullFrame {
                    Color.black.opacity(0.30)
                    Image(name).resizable().scaledToFit()
                        .frame(width: geometry.size.width, height: geometry.size.height)
                }
            }.overlay {
                LinearGradient(colors: [LokiDesign.ground.opacity(0.72), LokiDesign.ground.opacity(0.57),
                                        LokiDesign.ground.opacity(0.91)], startPoint: .top, endPoint: .bottom)
            }
                .frame(width: geometry.size.width, height: geometry.size.height).clipped()
        }
    }
}

private struct ChatDraftScope<Content: View>: View {
    @State private var draft = ""
    @ViewBuilder let content: (Binding<String>) -> Content

    var body: some View { content($draft) }
}

private struct ChatBubble: View {
    @State private var showingDeliveryError = false
    let message: ChatItem
    let beginsGroup: Bool
    let canReplay: Bool
    let isPlaying: Bool
    let canRetry: Bool
    let preview: Bool
    let playbackFraction: () -> Double?
    let retry: () -> Void
    let replay: () -> Void
    private var outgoing: Bool { message.role == "user" }
    private var careLabel: (title: String, icon: String)? {
        guard let event = message.careEventID else { return nil }
        if event.hasPrefix("hrv:") || event.hasPrefix("hrv-dnd:") { return ("HRV 关心", "heart") }
        if event.hasPrefix("weather:") { return ("天气关心", "cloud.sun") }
        return nil
    }
    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            if outgoing { Spacer(minLength: 28) }
            if outgoing && message.delivery == .steering {
                Image(systemName: "arrow.turn.up.right").font(.caption).foregroundStyle(.secondary)
                    .frame(width: 32, height: 44).accessibilityLabel("正在补充当前回答")
            } else if outgoing && message.delivery == .queued {
                Image(systemName: "clock").font(.caption).foregroundStyle(.secondary)
                    .frame(width: 32, height: 44).accessibilityLabel("消息已保存，等待依次发送")
            } else if outgoing && message.delivery == .sending {
                ProgressView().controlSize(.small).tint(.white)
                    .frame(width: 32, height: 44)
                    .accessibilityLabel("消息发送中")
            } else if outgoing && message.delivery == .failed {
                Button(action: retry) {
                    Image(systemName: "exclamationmark.circle")
                        .font(.system(size: 22, weight: .semibold)).foregroundStyle(.red)
                        .frame(width: 32, height: 44).contentShape(Rectangle())
                }.buttonStyle(.plain).disabled(!canRetry)
                    .accessibilityLabel(message.acceptedByServer == true ? "消息已接收，点按重试取得回复" : "发送失败，点按重新发送")
                    .accessibilityHint(message.deliveryError ?? "保留原消息内容重试")
                    .contextMenu {
                        Button("重新发送", systemImage: "arrow.clockwise", action: retry).disabled(!canRetry)
                        Button("查看失败原因", systemImage: "info.circle") { showingDeliveryError = true }
                    }
                    .alert(message.acceptedByServer == true ? "回复尚未取得" : "消息未发送", isPresented: $showingDeliveryError) {
                        Button("知道了", role: .cancel) {}
                    } message: { Text(message.deliveryError ?? "发送被中断，请点红色感叹号重试。") }
            }
            if !outgoing {
                if beginsGroup {
                    LokiPortrait(size: 32)
                        .overlay { Circle().strokeBorder(LokiDesign.gold.opacity(0.52)) }
                        .accessibilityHidden(true)
                } else { Color.clear.frame(width: 32, height: 1) }
            }
            VStack(alignment: outgoing ? .trailing : .leading, spacing: 5) {
                if beginsGroup {
                    HStack(spacing: 6) {
                        if !outgoing { Text("Loki").foregroundStyle(LokiDesign.gold) }
                        Text(message.date, style: .time).foregroundStyle(LokiDesign.muted)
                    }.font(.caption2.monospacedDigit())
                }
                if let careLabel {
                    Label(careLabel.title, systemImage: careLabel.icon)
                        .font(.caption2)
                        .foregroundStyle(LokiDesign.gold)
                }
                Group {
                    if let clip = message.recordedVoice {
                        LokiVoiceNote(clip: clip, isPlaying: isPlaying, preview: preview,
                                      playbackFraction: playbackFraction, replay: replay)
                    } else if outgoing { Text(message.displayText).font(ChatTypography.owner).lineSpacing(4) }
                    else { Text(ChatTypography.loki(message.displayText)).lineSpacing(6) }
                }
                .padding(.horizontal, 14).padding(.vertical, 11)
                .foregroundStyle(LokiDesign.ink)
                .lokiPanel(fill: outgoing ? LokiDesign.owner : LokiDesign.surface, radius: 17)
                .overlay {
                    if isPlaying {
                        RoundedRectangle(cornerRadius: 17).strokeBorder(LokiDesign.gold.opacity(0.72))
                            .allowsHitTesting(false).accessibilityHidden(true)
                    }
                }
                .modifier(MessageBubbleGestures(replaysReply: !outgoing && message.recordedVoice == nil,
                                             canReplay: canReplay, isPlaying: isPlaying,
                                             text: !outgoing && message.recordedVoice == nil ? message.displayText : "",
                                             replay: replay))
                .accessibilityLabel(outgoing ? "发出的消息" : "Loki 的消息")
                .accessibilityValue(message.recordedVoice.map { "语音 \(Int(ceil($0.duration))) 秒" } ?? message.displayText)
                if let note = message.localActionNote {
                    Text(note).font(.caption).padding(8)
                        .lokiPanel(fill: LokiDesign.raised, radius: 10)
                }
            }
            if !outgoing { Spacer(minLength: 16) }
        }.frame(maxWidth: .infinity, alignment: outgoing ? .trailing : .leading)
    }

}

private struct MessageBubbleGestures: ViewModifier {
    @State private var translation: String?
    @State private var configuration: TranslationSession.Configuration?
    @State private var showingTranslation = false
    @State private var translating = false
    @State private var translationFailed = false
    let replaysReply: Bool
    let canReplay: Bool
    let isPlaying: Bool
    let text: String
    let replay: () -> Void

    @ViewBuilder func body(content: Content) -> some View {
        if replaysReply && canReplay {
            translatable(content.contentShape(Rectangle()).onTapGesture(count: 2, perform: replay))
                .accessibilityAction(named: Text(isPlaying ? "停止播放" : "重播原声"), replay)
        } else {
            translatable(content)
        }
    }

    @ViewBuilder private func translatable<V: View>(_ view: V) -> some View {
        if text.isEmpty {
            view
        } else {
            VStack(alignment: .leading, spacing: 6) {
                view.contentShape(Rectangle())
                    .onLongPressGesture(perform: translate)
                    .accessibilityAction(named: Text(showingTranslation ? "收起译文" : "翻译成中文"), translate)
                if showingTranslation {
                    if let translation {
                        Text(translation).font(ChatTypography.owner).lineSpacing(4)
                            .foregroundStyle(LokiDesign.ink)
                            .padding(.horizontal, 12).padding(.vertical, 8)
                            .lokiPanel(fill: LokiDesign.surface, radius: 12)
                            .accessibilityLabel("中文译文：\(translation)")
                    } else if translationFailed {
                        Text("暂时无法翻译，再长按一次重试。").font(.caption)
                    } else {
                        ProgressView().controlSize(.small).accessibilityLabel("正在翻译")
                    }
                }
            }
            .translationTask(configuration) { session in
                do {
                    translation = try await session.translate(text).targetText
                } catch {
                    if !Task.isCancelled { translationFailed = true }
                }
                translating = false
            }
            .onChange(of: text) { _, _ in
                configuration = nil
                translation = nil
                showingTranslation = false
                translationFailed = false
                translating = false
            }
        }
    }

    private func translate() {
        guard !translating else { return }
        if translation != nil {
            showingTranslation.toggle()
            return
        }
        showingTranslation = true
        translationFailed = false
        translating = true
        if configuration != nil {
            configuration?.invalidate()
        } else {
            configuration = .init(source: Locale.Language(identifier: "en-GB"),
                                  target: Locale.Language(identifier: "zh-Hans"))
        }
    }
}

struct LokiPortrait: View {
    let size: CGFloat
    var body: some View {
        // Display a face-and-shoulders crop of the original 719 x 1280 photo.
        // Keep the source pixels untouched; crop only the view, not the person.
        GeometryReader { _ in
            Image("LokiAvatar").resizable()
                .frame(width: size * 719 / 480, height: size * 1280 / 480)
                .offset(x: -size * 160 / 480, y: -size * 470 / 480)
        }.frame(width: size, height: size).clipShape(Circle())
    }
}
