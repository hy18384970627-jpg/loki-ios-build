import Foundation

struct SleepStagePeriod: Codable, Identifiable {
    let stage: String
    let startAt: Date
    let endAt: Date
    var id: String { "\(stage):\(startAt.timeIntervalSince1970):\(endAt.timeIntervalSince1970)" }
    var duration: TimeInterval { endAt.timeIntervalSince(startAt) }
    var payload: [String: Any] {
        let format = ISO8601DateFormatter()
        return ["stage": stage, "start_at": format.string(from: startAt), "end_at": format.string(from: endAt)]
    }
}

struct SleepDetails: Codable {
    let startAt: Date
    let endAt: Date
    let source: String
    let periods: [SleepStagePeriod]
    let followingAwake: SleepStagePeriod?
    static let stageOrder = ["deep", "core", "rem", "awake", "unspecified", "unrecorded", "conflicting"]
    static func title(_ stage: String) -> String {
        ["deep": "深睡", "core": "核心睡眠", "rem": "快速眼动睡眠", "awake": "中途清醒记录",
         "unspecified": "未分期睡眠", "unrecorded": "没有阶段记录", "conflicting": "重叠冲突记录"][stage] ?? stage
    }
    var payload: [String: Any] {
        let format = ISO8601DateFormatter()
        var result: [String: Any] = ["start_at": format.string(from: startAt), "end_at": format.string(from: endAt),
            "source": source, "periods": periods.filter { $0.duration >= 1 }.map(\.payload)]
        if let followingAwake, followingAwake.duration >= 1 { result["following_awake"] = followingAwake.payload }
        return result
    }
}

enum SleepStageTimeline {
    static func build(_ raw: [SleepStagePeriod], session: SleepIntervals.Session, source: String) -> SleepDetails {
        let clipped = raw.compactMap { interval -> SleepStagePeriod? in
            let start = max(session.start, interval.startAt), end = min(session.end, interval.endAt)
            guard end > start else { return nil }
            return .init(stage: interval.stage, startAt: start, endAt: end)
        }
        let boundaries = Set([session.start, session.end] + clipped.flatMap { [$0.startAt, $0.endAt] }).sorted()
        var result: [SleepStagePeriod] = []
        if boundaries.count >= 2 {
            for index in 0..<(boundaries.count - 1) {
                let start = boundaries[index], end = boundaries[index + 1]
                let active = Set(clipped.filter { $0.startAt < end && $0.endAt > start }.map(\.stage))
                let specific = active.intersection(["deep", "core", "rem"])
                let asleep = !specific.isEmpty || active.contains("unspecified")
                let stage: String
                if specific.count > 1 || (active.contains("awake") && asleep) { stage = "conflicting" }
                else if let value = specific.first { stage = value }
                else if active.contains("awake") { stage = "awake" }
                else if active.contains("unspecified") { stage = "unspecified" }
                else { stage = "unrecorded" }
                if let last = result.last, last.stage == stage && last.endAt == start {
                    result[result.count - 1] = .init(stage: stage, startAt: last.startAt, endAt: end)
                } else { result.append(.init(stage: stage, startAt: start, endAt: end)) }
            }
        }
        let tail = raw.filter { $0.stage == "awake" && $0.endAt > session.end
            && $0.startAt <= session.end.addingTimeInterval(5 * 60) }.sorted { $0.startAt < $1.startAt }
        var following: SleepStagePeriod?
        for interval in tail {
            let start = max(session.end, interval.startAt)
            if let last = following {
                if start <= last.endAt { following = .init(stage: "awake", startAt: last.startAt, endAt: max(last.endAt, interval.endAt)) }
            } else { following = .init(stage: "awake", startAt: start, endAt: interval.endAt) }
        }
        return .init(startAt: session.start, endAt: session.end, source: source, periods: result, followingAwake: following)
    }
}
