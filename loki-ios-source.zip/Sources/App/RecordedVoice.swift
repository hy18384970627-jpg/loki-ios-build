import Foundation

struct RecordedVoice: Codable, Identifiable {
    let id: UUID
    let duration: Double
    var url: URL { get throws { try PrivateFiles.url("voice-\(id.uuidString).m4a") } }
    func data() throws -> Data {
        let value = try Data(contentsOf: url)
        guard value.count <= 2_000_000, (0.2...90.5).contains(duration) else { throw LokiError.message("录音为空、过长或过大。") }
        return value
    }
}
