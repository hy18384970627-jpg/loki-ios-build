import Foundation

/// Retry only audio-session acquisition, never synthesis or model requests.
@MainActor enum AudioActivationRetry {
    static func run(shouldRetry: (Error) -> Bool, activate: () throws -> Void,
                    sleep: (Int) async throws -> Void = { milliseconds in
                        try await Task.sleep(for: .milliseconds(milliseconds))
                    }) async throws {
        let delays = [200, 400, 800]
        for attempt in 0...delays.count {
            try Task.checkCancellation()
            do { try activate(); return }
            catch {
                guard shouldRetry(error), attempt < delays.count else { throw error }
                try await sleep(delays[attempt])
            }
        }
    }
}
