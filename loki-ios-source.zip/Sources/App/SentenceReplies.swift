import Foundation
import NaturalLanguage

enum SentenceReplies {
    private static let quotations = try! NSRegularExpression(
        pattern: #"“[^”]+”|«[^»]+»|「[^」]+」|『[^』]+』|"[^"\r\n]+"|‘(?:[^’]|(?<=\p{L})’(?=\p{L}))+’"#)
    private static let speechVerb =
        #"said|asked|replied|answered|murmured|whispered|added|continued|said aloud|called|called out|shouted|snapped|muttered|remarked|exclaimed|insisted|admitted|promised|teased|drawled|sighed|breathed|told|warned|suggested|ordered|called back|uttered|began|concluded"#
    private static let speaker = #"[\p{Lu}\p{Ll}][\p{L}'’\-]*(?:\s+[\p{Lu}][\p{L}'’\-]*){0,2}"#
    private static let manner = #"(?:\s+[^.!?;:“”"\r\n,]+)?"#
    private static let leadIn = #"(?:(?:\s+[^.!?;:“”"\r\n,]{1,80}?\s+and|,\s+[^.!?;:“”"\r\n,]{1,80},))?\s+(?:\p{L}+ly\s+)?"#
    private static let beforeQuote = try! NSRegularExpression(
        pattern: "(?:^|(?<=[.!?。！？\\n]))\\s*(" + speaker + ")" + leadIn + "(?:" +
            speechVerb + ")\\b" + manner + "[,:]\\s*$")
    private static let afterQuote = try! NSRegularExpression(
        pattern: "^\\s*[,，]?\\s*(?:(" + speaker + ")" + leadIn + "(?:" +
            speechVerb + ")\\b|(?:" + speechVerb + ")\\s+(" + speaker + ")\\b)" + manner + "[.!?;,:]?")
    private static let terminal = CharacterSet(charactersIn: ".!?。！？")
    private static let closingQuotes = CharacterSet(charactersIn: "\"”’»」』")

    private struct QuotedPassage {
        var range: NSRange
        var speaker: String?
        var continuesAfterComma: Bool
    }

    private static func protectedPassages(in text: String) -> [NSRange] {
        let source = text as NSString
        let quotes = quotations.matches(in: text, range: NSRange(location: 0, length: source.length))
        var passages: [QuotedPassage] = []
        for (index, quote) in quotes.enumerated() {
            let precedingEnd = index > 0 ? NSMaxRange(quotes[index - 1].range) : 0
            let followingStart = index + 1 < quotes.count ? quotes[index + 1].range.location : source.length
            let preceding = NSRange(location: precedingEnd, length: quote.range.location - precedingEnd)
            let following = NSRange(location: NSMaxRange(quote.range), length: followingStart - NSMaxRange(quote.range))
            let previousContinues = passages.last?.continuesAfterComma == true
            let prefix = previousContinues ? nil : beforeQuote.firstMatch(in: text, range: preceding)
            var suffix = afterQuote.firstMatch(in: text, range: following)
            // A complete quoted sentence followed by “Loki said, …” belongs
            // to the earlier speaker. The leading tag introduces the next quote.
            if index + 1 < quotes.count,
               terminal.contains(source.substring(with: quote.range).trimmingCharacters(in: closingQuotes).unicodeScalars.last ?? " "),
               beforeQuote.firstMatch(in: text, range: following) != nil {
                suffix = nil
            }
            let start = prefix?.range.location ?? quote.range.location
            let end = suffix.map { NSMaxRange($0.range) } ?? NSMaxRange(quote.range)
            let speakerMatch = suffix.flatMap { match in
                (1..<match.numberOfRanges).map { match.range(at: $0) }.first { $0.location != NSNotFound }
            } ?? prefix?.range(at: 1)
            let name = speakerMatch.map { source.substring(with: $0).lowercased() }
            let endsWithComma = suffix.map { source.substring(with: $0.range).hasSuffix(",") } ?? false
            if let previous = passages.last {
                let previousEnd = NSMaxRange(previous.range)
                let gap = start >= previousEnd
                    ? source.substring(with: NSRange(location: previousEnd, length: start - previousEnd))
                    : ""
                if gap.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
                    ((name != nil && name == previous.speaker) || (name == nil && previous.continuesAfterComma)) {
                    passages[passages.count - 1].range.length = max(end, previousEnd) - previous.range.location
                    passages[passages.count - 1].continuesAfterComma = endsWithComma
                    continue
                }
            }
            passages.append(QuotedPassage(range: NSRange(location: start, length: end - start),
                                          speaker: name, continuesAfterComma: endsWithComma))
        }
        return passages.map(\.range)
    }

    static func visible(_ text: String) -> String {
        text.replacingOccurrences(of: #"\((?:laugh|sigh)\)"#, with: "", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
    static func split(_ text: String) -> [String] {
        let tokenizer = NLTokenizer(unit: .sentence); tokenizer.string = text
        let protected = protectedPassages(in: text)
        var boundaries: Set<String.Index> = [text.endIndex]
        tokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { range, _ in
            let boundary = range.upperBound.utf16Offset(in: text)
            if !protected.contains(where: { $0.location < boundary && boundary < NSMaxRange($0) }) {
                boundaries.insert(range.upperBound)
            }
            return true
        }
        for passage in protected {
            guard let range = Range(passage, in: text),
                  let end = String(text[range]).trimmingCharacters(in: closingQuotes).unicodeScalars.last,
                  terminal.contains(end),
                  !protected.contains(where: { $0.location < NSMaxRange(passage) && NSMaxRange(passage) < NSMaxRange($0) })
            else { continue }
            // Some tokenizers end a sentence just before its closing quote.
            // Restore the boundary after the quote or attribution.
            let next = text[range.upperBound...].first { !$0.isWhitespace }
            if next == nil || next?.isUppercase == true || next.map({ "“«「『\"‘".contains($0) }) == true {
                boundaries.insert(range.upperBound)
            }
        }
        var result: [String] = [], pending = ""
        var start = text.startIndex
        for end in boundaries.sorted() {
            pending += text[start..<end]
            start = end
            if !visible(pending).isEmpty {
                result.append(pending.trimmingCharacters(in: .whitespacesAndNewlines)); pending = ""
            }
        }
        if !pending.isEmpty, !result.isEmpty { result[result.count - 1] += pending }
        return result
    }
}
