import Foundation
import NaturalLanguage

enum SentenceReplies {
    static func visible(_ text: String) -> String {
        text.replacingOccurrences(of: #"\((?:laugh|sigh)\)"#, with: "", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
    static func split(_ text: String) -> [String] {
        let tokenizer = NLTokenizer(unit: .sentence); tokenizer.string = text
        var chunks: [String] = [], start = text.startIndex
        tokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { range, _ in
            chunks.append(String(text[start..<range.upperBound])); start = range.upperBound
            return true
        }
        if start < text.endIndex {
            if chunks.isEmpty { chunks.append(String(text[start...])) }
            else { chunks[chunks.count - 1] += String(text[start...]) }
        }
        var result: [String] = [], pending = ""
        for chunk in chunks {
            pending += chunk
            if !visible(pending).isEmpty {
                result.append(pending.trimmingCharacters(in: .whitespacesAndNewlines)); pending = ""
            }
        }
        if !pending.isEmpty, !result.isEmpty { result[result.count - 1] += pending }
        return result
    }
}
