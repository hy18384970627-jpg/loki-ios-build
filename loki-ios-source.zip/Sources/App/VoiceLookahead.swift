import Foundation

/// One ahead-of-playback sentence. A consumer can start before synthesis ends.
@MainActor final class VoiceLookahead {
    enum Failure: LocalizedError {
        case overflow
        var errorDescription: String? { "下一句语音超过缓冲上限，请双击消息重播。" }
    }
    private let limit: Int
    private var producer: Task<Void, Never>?
    private var continuation: AsyncThrowingStream<Data, Error>.Continuation
    private let chunks: AsyncThrowingStream<Data, Error>
    private(set) var samples = Data()
    private(set) var finished = false
    init(limit: Int = 24_000 * 2 * 120) {
        self.limit = limit
        let pair = AsyncThrowingStream<Data, Error>.makeStream()
        chunks = pair.stream; continuation = pair.continuation
    }
    func start(cache: @escaping @MainActor (Data) throws -> Void = { _ in },
               _ generate: @escaping @MainActor (VoiceLookahead) async throws -> Void) {
        guard producer == nil, !finished else { return }
        producer = Task { @MainActor [weak self] in
            guard let self else { return }
            defer { self.producer = nil }
            do {
                try await generate(self)
                try Task.checkCancellation()
                // Persistence is optional; a protected/unwritable cache must not fail valid PCM.
                try? cache(self.samples)
                self.finish()
            }
            catch { self.finish(error) }
        }
    }
    func append(_ data: Data) throws {
        try Task.checkCancellation()
        guard !finished else { throw CancellationError() }
        guard samples.count + data.count <= limit else { throw Failure.overflow }
        samples.append(data); continuation.yield(data)
    }
    func finish(_ error: Error? = nil) {
        guard !finished else { return }
        finished = true
        if let error { continuation.finish(throwing: error) }
        else { continuation.finish() }
    }
    func consume(_ append: @MainActor (Data) async throws -> Void) async throws {
        for try await data in chunks {
            try Task.checkCancellation()
            try await append(data)
        }
    }
    func cancel() { producer?.cancel(); finish(CancellationError()) }
}
