import Foundation
import Combine
import HealthKit

struct HealthReading: Codable, Identifiable {
    let id: String
    let title: String
    let value: Double
    let unit: String
    let recordedAt: Date
    let source: String
    let startAt: Date?
    let endAt: Date?
    init(id: String, title: String, value: Double, unit: String, recordedAt: Date, source: String,
         startAt: Date? = nil, endAt: Date? = nil) {
        self.id = id; self.title = title; self.value = value; self.unit = unit
        self.recordedAt = recordedAt; self.source = source; self.startAt = startAt; self.endAt = endAt
    }
}

@MainActor final class HealthService: ObservableObject {
    static let shared = HealthService()
    @Published var readings: [HealthReading] = []
    @Published var message = "尚未读取健康数据"
    @Published var busy = false
    @Published var sleepDetails: SleepDetails?
    @Published var sleepTrend: [HealthDay] = []
    var recentSleep: [[String: Any]] = []
    @Published var syncMessage = "尚未启用自动同步"
    @Published var lastSyncedAt = UserDefaults.standard.object(forKey: "healthLastSync") as? Date
    let store = HKHealthStore()
    var pendingSnapshot: NativeHealthSnapshot? = PrivateFiles.load("health-pending.json", fallback: nil)
    var syncing = false
    var lastSyncedSamples: Data?
    var sleepCacheUpdatedAt: Date?
    var cachedSleepReading: HealthReading?
    private var observers: [HKObserverQuery] = []
    private var types: Set<HKObjectType> {
        [HKObjectType.quantityType(forIdentifier: .heartRate)!,
         HKObjectType.quantityType(forIdentifier: .heartRateVariabilitySDNN)!,
         HKObjectType.quantityType(forIdentifier: .stepCount)!,
         HKObjectType.categoryType(forIdentifier: .sleepAnalysis)!]
    }
    func authorize() async throws {
        guard HKHealthStore.isHealthDataAvailable() else { throw LokiError.message("这台设备没有可用的健康数据服务。") }
        try await store.requestAuthorization(toShare: [], read: types)
        await refresh()
    }
    func refresh(upload: Bool = true) async {
        guard !busy else { return }
        busy = true; defer { busy = false }
        do {
            var results: [HealthReading] = []
            for (id, title, identifier, unit, label) in [
                ("heart", "心率", HKQuantityTypeIdentifier.heartRate, HKUnit.count().unitDivided(by: .minute()), "次/分"),
                ("hrv", "HRV · SDNN", HKQuantityTypeIdentifier.heartRateVariabilitySDNN, HKUnit.secondUnit(with: .milli), "毫秒")
            ] {
                let type = HKQuantityType.quantityType(forIdentifier: identifier)!
                if let sample = try await samples(type).first as? HKQuantitySample {
                    results.append(.init(id: id, title: title, value: sample.quantity.doubleValue(for: unit),
                        unit: label, recordedAt: sample.endDate, source: sample.sourceRevision.source.name))
                }
            }
            let steps = HKQuantityType.quantityType(forIdentifier: .stepCount)!
            if let count = try await todaySteps(steps) {
                results.append(.init(id: "steps", title: "今日步数", value: count.0, unit: "步",
                                     recordedAt: count.1, source: "Apple 健康聚合"))
            }
            if let sleep = try await sleepSummary() { results.append(sleep) }
            readings = results
            message = results.isEmpty ? "没有可读取的数据。可能尚未授权、未采集或未同步；空结果不能区分原因。" : "显示原始采样时间；旧数据不会当作当前状态。HRV 不用于诊断。"
            if UserDefaults.standard.bool(forKey: "healthAutoSync") {
                queueSnapshot(enabled: true)
                if upload { Task { await syncPending() } }
            }
        } catch { message = error.localizedDescription }
    }
    private func samples(_ type: HKSampleType) async throws -> [HKSample] {
        try await withCheckedThrowingContinuation { continuation in
            let predicate = HKQuery.predicateForSamples(withStart: Date().addingTimeInterval(-7 * 86400), end: Date())
            let query = HKSampleQuery(sampleType: type, predicate: predicate, limit: 1,
                sortDescriptors: [NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)]) { _, samples, error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: samples ?? []) }
            }
            store.execute(query)
        }
    }
    private func todaySteps(_ type: HKQuantityType) async throws -> (Double, Date)? {
        let start = Calendar.current.startOfDay(for: Date())
        let latest = try await samples(type).first
        guard let latest, latest.endDate >= start else { return nil }
        let count: Double? = try await withCheckedThrowingContinuation { continuation in
            let query = HKStatisticsQuery(quantityType: type,
                quantitySamplePredicate: HKQuery.predicateForSamples(withStart: start, end: Date(), options: .strictStartDate),
                options: .cumulativeSum) { _, result, error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: result?.sumQuantity()?.doubleValue(for: .count())) }
            }
            store.execute(query)
        }
        return count.map { ($0, latest.endDate) }
    }
    func background(_ enabled: Bool) async throws {
        if enabled && !observers.isEmpty {
            for type in types.compactMap({ $0 as? HKSampleType }) {
                try await store.enableBackgroundDelivery(for: type, frequency: .immediate)
            }
            UserDefaults.standard.set(true, forKey: "healthBackground")
            return
        }
        observers.forEach { store.stop($0) }; observers.removeAll()
        guard enabled else {
            try await store.disableAllBackgroundDelivery()
            UserDefaults.standard.set(false, forKey: "healthBackground")
            return
        }
        installObservers()
        for type in types.compactMap({ $0 as? HKSampleType }) {
            try await store.enableBackgroundDelivery(for: type, frequency: .immediate)
        }
        UserDefaults.standard.set(true, forKey: "healthBackground")
    }
    func restoreObserversOnLaunch() {
        if UserDefaults.standard.bool(forKey: "healthBackground") { installObservers() }
    }
    private func installObservers() {
        guard observers.isEmpty else { return }
        for type in types.compactMap({ $0 as? HKSampleType }) {
            let query = HKObserverQuery(sampleType: type, predicate: nil) { [weak self] _, completion, error in
                guard error == nil else { completion(); return }
                Task { @MainActor [weak self] in
                    if type.identifier == HKCategoryTypeIdentifier.sleepAnalysis.rawValue { self?.sleepCacheUpdatedAt = nil }
                    await self?.refresh(upload: false)
                    await self?.syncPending()
                    completion() // HealthKit is acknowledged even when the phone has no network.
                }
            }
            store.execute(query); observers.append(query)
        }
    }
    var payload: [[String: Any]] {
        readings.map(\.payload)
    }
}
