import SwiftUI

/// Semantic roles shared by the chat and health surfaces.
enum LokiDesign {
    static let ground = Color(red: 0.035, green: 0.075, blue: 0.064)
    static let surface = Color(red: 0.069, green: 0.124, blue: 0.108)
    static let raised = Color(red: 0.10, green: 0.17, blue: 0.148)
    static let owner = Color(red: 0.135, green: 0.265, blue: 0.213)
    static let gold = Color(red: 0.85, green: 0.72, blue: 0.48)
    static let ink = Color(red: 0.96, green: 0.94, blue: 0.88)
    static let muted = Color(red: 0.69, green: 0.75, blue: 0.69)
    static let line = gold.opacity(0.18)
    static let danger = Color(red: 1, green: 0.64, blue: 0.58)
    static let pageInset: CGFloat = 18
    static let cardRadius: CGFloat = 20
}

struct LokiBackdrop: View {
    var body: some View {
        LokiDesign.ground.overlay(alignment: .top) {
            RadialGradient(colors: [LokiDesign.owner.opacity(0.58), .clear],
                           center: .topLeading, startRadius: 4, endRadius: 440)
        }.ignoresSafeArea().accessibilityHidden(true)
    }
}

struct LokiEyebrow: View {
    let title: String
    var body: some View {
        Text(title).font(.caption2.weight(.semibold)).tracking(2.6)
            .foregroundStyle(LokiDesign.gold)
    }
}

extension View {
    func lokiPanel(fill: Color = LokiDesign.surface, radius: CGFloat = LokiDesign.cardRadius) -> some View {
        background(fill, in: RoundedRectangle(cornerRadius: radius))
            .overlay {
                RoundedRectangle(cornerRadius: radius).strokeBorder(LokiDesign.line)
                    .allowsHitTesting(false).accessibilityHidden(true)
            }
    }
}
