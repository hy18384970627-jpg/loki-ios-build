import Foundation
import Combine
import CoreLocation
import MapKit

@MainActor final class LocationService: NSObject, ObservableObject, CLLocationManagerDelegate {
    static let shared = LocationService()
    @Published var position: CLLocation?
    @Published var places: [MKMapItem] = []
    @Published var message = "仅在你主动查询时定位"
    @Published var weatherMessage = "定位天气尚未开启"
    @Published private(set) var searching = false
    @Published private(set) var nearbyMessage = ""
    private var locationWaiters: [UUID: CheckedContinuation<CLLocation, Error>] = [:]
    private var locationTimeouts: [UUID: Task<Void, Never>] = [:]
    private var activeSearch: MKLocalSearch?
    private var weather: LocalWeather?
    private var syncing = false
    private var lastUploaded: CLLocation?
    private var trackingEpoch = UUID()
    private let manager = CLLocationManager()
    override init() {
        super.init(); manager.delegate = self; manager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        manager.distanceFilter = 50
    }
    func restoreAutomatic() {
        guard UserDefaults.standard.bool(forKey: "locationAutoSync") else { return }
        let status = manager.authorizationStatus
        guard status == .authorizedAlways || status == .authorizedWhenInUse else { return }
        manager.allowsBackgroundLocationUpdates = status == .authorizedAlways
        manager.showsBackgroundLocationIndicator = true
        manager.distanceFilter = locationWaiters.isEmpty ? 50 : kCLDistanceFilterNone
        manager.pausesLocationUpdatesAutomatically = locationWaiters.isEmpty
        manager.startUpdatingLocation()
        if status == .authorizedAlways && CLLocationManager.significantLocationChangeMonitoringAvailable() {
            manager.startMonitoringSignificantLocationChanges()
        }
    }
    func enableWeather() {
        UserDefaults.standard.set(true, forKey: "weatherCompanionEnabled")
        UserDefaults.standard.set(true, forKey: "locationAutoSync")
        locate(); restoreAutomatic()
    }
    func requestAlways() {
        UserDefaults.standard.set(true, forKey: "locationAutoSync")
        if manager.authorizationStatus == .notDetermined { manager.requestWhenInUseAuthorization() }
        else { manager.requestAlwaysAuthorization() }
        restoreAutomatic()
    }
    func stopAutomatic() {
        trackingEpoch = UUID()
        UserDefaults.standard.set(false, forKey: "locationAutoSync")
        UserDefaults.standard.set(false, forKey: "weatherCompanionEnabled")
        manager.stopUpdatingLocation(); manager.stopMonitoringSignificantLocationChanges(); weather = nil
        weatherMessage = "已暂停位置与天气分享"
        Task {
            guard let base = UserDefaults.standard.string(forKey: "gatewayURL"), !SecureToken.read().isEmpty else { return }
            _ = try? await MobileAPI(base: base, token: SecureToken.read()).data("/v1/location", ["enabled": false, "collected_at": Date().timeIntervalSince1970], timeout: 8)
        }
    }
    func locate() {
        switch manager.authorizationStatus {
        case .notDetermined: manager.requestWhenInUseAuthorization()
        case .authorizedAlways, .authorizedWhenInUse: manager.requestLocation()
        default: message = "定位权限未开启，可在系统设置中允许。"
        }
    }
    nonisolated func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        let status = manager.authorizationStatus
        Task { @MainActor [weak self] in
            guard let self else { return }
            if status == .authorizedWhenInUse || status == .authorizedAlways {
                if !self.locationWaiters.isEmpty { self.beginFreshLocation() }
                else { self.manager.requestLocation() }
                self.restoreAutomatic()
            } else if status == .denied || status == .restricted {
                self.trackingEpoch = UUID(); self.position = nil; self.places = []
                self.finishAllLocations(.failure(LokiError.message("定位权限未开启，请在系统设置中允许 Loki 定位。")))
            }
        }
    }
    nonisolated func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let latest = locations.filter { $0.horizontalAccuracy.isFinite && $0.horizontalAccuracy >= 0 && $0.timestamp <= Date().addingTimeInterval(30) }
            .max(by: { $0.timestamp < $1.timestamp })
        Task { @MainActor [weak self] in
            guard let self, let latest else { return }
            if self.position == nil || latest.timestamp >= self.position!.timestamp {
                self.position = latest; self.message = "位置时间：\(latest.timestamp.formatted())"
            }
            if LocationFreshness.usable(timestamp: latest.timestamp, accuracy: latest.horizontalAccuracy) {
                self.finishAllLocations(.success(latest))
            }
            await self.uploadAutomatic(latest)
        }
    }
    private func uploadAutomatic(_ location: CLLocation) async {
        guard UserDefaults.standard.bool(forKey: "locationAutoSync"), !syncing,
              manager.authorizationStatus == .authorizedAlways || manager.authorizationStatus == .authorizedWhenInUse,
              abs(location.timestamp.timeIntervalSinceNow) < 300, (0...1000).contains(location.horizontalAccuracy),
              let base = UserDefaults.standard.string(forKey: "gatewayURL"), !SecureToken.read().isEmpty else { return }
        if let lastUploaded, location.timestamp.timeIntervalSince(lastUploaded.timestamp) < 30,
           location.distance(from: lastUploaded) < 100 { return }
        syncing = true; defer { syncing = false }
        let epoch = trackingEpoch
        var payload: [String: Any] = ["enabled": true, "latitude": location.coordinate.latitude,
            "longitude": location.coordinate.longitude, "accuracy_m": location.horizontalAccuracy,
            "recorded_at": location.timestamp.timeIntervalSince1970]
        if UserDefaults.standard.bool(forKey: "weatherCompanionEnabled") {
            do {
                if weather == nil || Date().timeIntervalSince(weather!.fetchedAt) > 3600 || location.distance(from: weather!.location) > 5000 {
                    let refreshed = try await LocalWeather.fetch(at: location)
                    guard epoch == trackingEpoch && UserDefaults.standard.bool(forKey: "locationAutoSync") else { return }
                    weather = refreshed
                }
                if let weather { payload["weather"] = weather.payload; weatherMessage = "当地天气已同步给 Loki · Open-Meteo" }
            } catch { weatherMessage = "位置可同步；天气等待下次更新：\(error.localizedDescription)" }
        }
        guard epoch == trackingEpoch && UserDefaults.standard.bool(forKey: "locationAutoSync") else { return }
        do {
            _ = try await MobileAPI(base: base, token: SecureToken.read()).data("/v1/location", payload, timeout: 8)
            lastUploaded = location
        } catch { message = "位置等待下次联网同步" }
    }
    nonisolated func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        let detail = error.localizedDescription
        let temporary = (error as? CLError)?.code == .locationUnknown
        Task { @MainActor [weak self] in
            self?.message = detail
            if !temporary { self?.finishAllLocations(.failure(LokiError.message("暂时无法定位：\(detail)"))) }
        }
    }
    private func beginFreshLocation() {
        switch manager.authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse:
            // Restart a paused/stationary stream to obtain a new initial fix.
            manager.stopUpdatingLocation()
            manager.distanceFilter = kCLDistanceFilterNone
            manager.pausesLocationUpdatesAutomatically = false
            manager.startUpdatingLocation()
        case .notDetermined: manager.requestWhenInUseAuthorization()
        default: finishAllLocations(.failure(LokiError.message("定位权限未开启，请在系统设置中允许 Loki 定位。")))
        }
    }
    private func finishLocation(_ id: UUID, _ result: Result<CLLocation, Error>) {
        guard let waiter = locationWaiters.removeValue(forKey: id) else { return }
        locationTimeouts.removeValue(forKey: id)?.cancel()
        waiter.resume(with: result)
        if locationWaiters.isEmpty {
            manager.distanceFilter = 50; manager.pausesLocationUpdatesAutomatically = true
            if UserDefaults.standard.bool(forKey: "locationAutoSync") { restoreAutomatic() }
            else { manager.stopUpdatingLocation() }
        }
    }
    private func finishAllLocations(_ result: Result<CLLocation, Error>) {
        for id in Array(locationWaiters.keys) { finishLocation(id, result) }
    }
    private func freshLocation() async throws -> CLLocation {
        guard manager.authorizationStatus != .denied && manager.authorizationStatus != .restricted else {
            throw LokiError.message("定位权限未开启，请在系统设置中允许 Loki 定位。")
        }
        if let position, LocationFreshness.usable(timestamp: position.timestamp, accuracy: position.horizontalAccuracy) { return position }
        let id = UUID()
        return try await withTaskCancellationHandler {
            try Task.checkCancellation()
            return try await withCheckedThrowingContinuation { continuation in
                locationWaiters[id] = continuation
                locationTimeouts[id] = Task { @MainActor [weak self] in
                    do { try await Task.sleep(for: .seconds(20)) } catch { return }
                    self?.finishLocation(id, .failure(LokiError.message("暂时无法取得当前位置，请稍后重试或检查定位服务。")))
                }
                if locationWaiters.count == 1 { beginFreshLocation() }
            }
        } onCancel: {
            Task { @MainActor [weak self] in self?.finishLocation(id, .failure(CancellationError())) }
        }
    }
    func refreshForNearbyPage() async {
        guard UserDefaults.standard.bool(forKey: "locationAutoSync") else { return }
        _ = try? await freshLocation()
    }
    func cancelNearbySearch() { activeSearch?.cancel() }
    func nearby(_ query: String) async throws {
        guard !searching else { return }
        let query = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { throw LokiError.message("请输入想找的地点。") }
        searching = true; places = []
        defer { searching = false; activeSearch = nil }
        nearbyMessage = "正在获取当前位置…"
        let position = try await freshLocation()
        try Task.checkCancellation()
        nearbyMessage = "正在查找附近的\(query)…"
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = query
        request.region = MKCoordinateRegion(center: position.coordinate, latitudinalMeters: 5000, longitudinalMeters: 5000)
        let search = MKLocalSearch(request: request); activeSearch = search
        let response = try await withTaskCancellationHandler { try await search.start() } onCancel: {
            Task { @MainActor in search.cancel() }
        }
        try Task.checkCancellation()
        places = response.mapItems
        nearbyMessage = places.isEmpty ? "附近暂未找到匹配地点" : "已找到 \(places.count) 个附近地点"
    }
}
