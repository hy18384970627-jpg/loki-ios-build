import Foundation
import Combine
import UIKit

@MainActor final class AppState: ObservableObject {
    @Published var messages: [ChatItem] = PrivateFiles.load("chat.json", fallback: [])
    @Published var tasks: [TaskCard] = PrivateFiles.load("tasks.json", fallback: [])
    @Published var commands: [MobileCommand] = []
    @Published var notice: String?
    @Published var busy = false
    @Published var checkingCare = false
    @Published var callActive = false
    @Published var voiceStage = ""
    @Published private(set) var voiceNeedsRepeat = false
    @Published var composing = false
    @Published var careStatus = ""
    @Published var carePushReady = false
    @Published var commandBusy = false
    @Published var unlocked = false
    @Published var status: GatewayStatus?
    @Published var selectedTab = 0
    var api: MobileAPI {
        MobileAPI(base: UserDefaults.standard.string(forKey: "gatewayURL") ?? "", token: SecureToken.read())
    }
    var paired: Bool { !SecureToken.read().isEmpty && UserDefaults.standard.string(forKey: "gatewayURL") != nil }
    var wallpaperName: String {
        let name = messages.last(where: { $0.wallpaperAsset != nil })?.wallpaperAsset ?? "ChatWallpaper"
        return UIImage(named: name) == nil ? "ChatWallpaper" : name
    }
    struct Receipt: Codable {
        let command: MobileCommand
        let state: String
        let detail: String
    }
    private var ledger: [String: Receipt] = PrivateFiles.load("tool-receipts.json", fallback: [:])
    private var receivedCare: [String] = PrivateFiles.load("companion-received.json", fallback: [])
    private var wallpaperReceipts: [String] = PrivateFiles.load("wallpaper-receipts.json", fallback: [])
    private var syncingWallpaper = false
    private var lastCareConfiguration = ""
    private var outbox: [String: OutgoingMessage] = PrivateFiles.load("outgoing.json", fallback: [:])
    private var deliveryQueue: [@MainActor () async -> Void] = []
    private var deliveryTask: Task<Void, Never>?
    private struct SpokenPacket {
        let item: ChatItem
        let batch: UUID
        let voice: VoiceService
        let finished: @MainActor () -> Void
    }
    private var spokenQueue = SentencePlaybackQueue<SpokenPacket>()
    private var spokenTask: Task<Void, Never>?
    private var pullingCompanion = false
    private var activeGeneratingRequestID: UUID?
    private var followupQueue: [@MainActor () async -> Void] = []
    private var followupTask: Task<Void, Never>?
    private func queueFollowup(_ operation: @escaping @MainActor () async -> Void) {
        followupQueue.append(operation)
        guard followupTask == nil else { return }
        followupTask = Task { [weak self] in
            guard let self else { return }
            defer { self.followupTask = nil }
            while !self.followupQueue.isEmpty, !Task.isCancelled {
                let next = self.followupQueue.removeFirst(); await next()
            }
        }
    }
    private func markSteered(_ id: UUID) throws {
        if var draft = outbox[id.uuidString] {
            draft.serverAccepted = true; outbox[id.uuidString] = draft; try saveOutbox()
        }
        if let index = messages.firstIndex(where: { $0.id == id }) { messages[index].acceptedByServer = true }
        try delivery(.sent, id: id)
        outbox.removeValue(forKey: id.uuidString); try? saveOutbox()
    }
    private func supplement(_ id: UUID, target: UUID, fallback: @escaping @MainActor () async -> Void) {
        guard var draft = outbox[id.uuidString] else { return }
        draft.steerTargetID = target; outbox[id.uuidString] = draft
        do { try saveOutbox(); try delivery(.steering, id: id) } catch { tell(error); return }
        queueFollowup { [weak self] in
            guard let self, self.outbox[id.uuidString] != nil else { return }
            do {
                let receipt: FollowupReceipt
                if self.activeGeneratingRequestID == target {
                    receipt = try await self.api.steer(id: id, target: target, message: draft.text)
                } else { receipt = FollowupReceipt(state: "not_applied") }
                switch receipt.state {
                case "accepted": try self.markSteered(id)
                case "not_applied":
                    if var value = self.outbox[id.uuidString] { value.steerTargetID = nil; self.outbox[id.uuidString] = value; try self.saveOutbox() }
                    try self.delivery(.queued, id: id); self.queueDelivery(fallback)
                default: throw LokiError.message("补充是否被纳入尚未确认，点重试会先核对接收状态。")
                }
            } catch {
                guard self.messages.first(where: { $0.id == id })?.delivery != .sent else { return }
                if let index = self.messages.firstIndex(where: { $0.id == id }) { self.messages[index].deliveryError = error.localizedDescription }
                try? self.delivery(.failed, id: id)
            }
        }
    }
    private func queueDelivery(_ operation: @escaping @MainActor () async -> Void) {
        deliveryQueue.append(operation)
        guard deliveryTask == nil else { return }
        deliveryTask = Task { [weak self] in
            guard let self else { return }
            defer { self.deliveryTask = nil }
            while !self.deliveryQueue.isEmpty, !Task.isCancelled {
                if self.busy || self.checkingCare {
                    do { try await Task.sleep(for: .milliseconds(100)) } catch { break }
                    continue
                }
                let next = self.deliveryQueue.removeFirst()
                await next()
            }
        }
    }
    init() {
        // Process suspension is not proof of a failed send. Reconcile original IDs.
        messages = OutgoingRecovery.restore(messages, drafts: Array(outbox.values))
        outbox = outbox.filter { key, _ in !messages.contains(where: { $0.id.uuidString == key && $0.delivery == .sent }) }
        try? saveOutbox()
        try? PrivateFiles.save(messages, "chat.json")
    }
    private func saveOutbox() throws { try PrivateFiles.save(outbox, "outgoing.json") }
    func reconcileOutgoing(health: HealthService, voice: VoiceService, alarms: AlarmService, focus: FocusService) async {
        guard paired, unlocked, !busy, !checkingCare, deliveryTask == nil, followupTask == nil,
              UIApplication.shared.applicationState == .active else { return }
        for draft in outbox.values.sorted(by: { $0.createdAt < $1.createdAt }) {
            guard !Task.isCancelled, UIApplication.shared.applicationState == .active else { return }
            guard outbox[draft.id.uuidString] != nil else { continue }
            let state = messages.first(where: { $0.id == draft.id })?.delivery
            // Old false failures with a durable acknowledgement are also recoverable.
            if state == .failed && draft.serverAccepted != true { continue }
            if let _ = draft.steerTargetID {
                do {
                    let receipt = try await api.followupStatus(id: draft.id)
                    if receipt.state == "accepted" { try markSteered(draft.id); continue }
                    guard receipt.state == "not_applied" else { continue }
                    outbox[draft.id.uuidString]?.steerTargetID = nil; try saveOutbox()
                } catch { return }
            }
            if draft.requestBody != nil {
                do {
                    let status = try await api.chatStatus(id: draft.id)
                    if status.state == "failed" { try delivery(.failed, id: draft.id); continue }
                    if status.state != "missing" {
                        outbox[draft.id.uuidString]?.serverAccepted = true; try saveOutbox()
                    }
                } catch { return } // A failed status read never becomes a failed message.
            }
            _ = await deliver(draft.id, healthService: health, voice: voice,
                autoVoice: UserDefaults.standard.object(forKey: "autoVoice") as? Bool ?? true, alarms: alarms, focus: focus)
        }
    }
    private func delivery(_ state: MessageDelivery, id: UUID) throws {
        if let index = messages.firstIndex(where: { $0.id == id }) {
            messages[index].delivery = state
            if state != .failed { messages[index].deliveryError = nil }
        }
        try PrivateFiles.save(messages, "chat.json")
    }

    func tell(_ error: Error) { notice = error.localizedDescription }
    func checkConnection() async {
        do { status = try await api.status(); notice = status?.chat_enabled == true ? "已连接私人接口" : "接口可用；现有 Loki 适配器尚未启用。" }
        catch { tell(error) }
    }
    func send(_ text: String, image: Data? = nil, health: [String: Any]? = nil,
              voice: VoiceService? = nil, autoVoice: Bool = false, alarms: AlarmService? = nil, focus: FocusService? = nil,
              healthService: HealthService? = nil) async {
        let text = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        guard paired else { notice = "请先在设置中配对私人接口。"; return }
        let draft = OutgoingMessage(id: UUID(), text: text, image: image)
        guard enqueue(draft) else { return }
        let transmit: @MainActor () async -> Void = { [weak self] in
            _ = await self?.deliver(draft.id, health: health, healthService: healthService, voice: voice,
                autoVoice: autoVoice, alarms: alarms, focus: focus)
        }
        // Native alarm requests retain their actual phone-action preparation.
        if image == nil, text.count <= 12000, let target = activeGeneratingRequestID, case .none = AlarmChatIntent.parse(text) {
            supplement(draft.id, target: target, fallback: transmit)
        } else { queueDelivery(transmit) }
    }
    private func enqueue(_ draft: OutgoingMessage) -> Bool {
        do {
            outbox[draft.id.uuidString] = draft
            try saveOutbox()
            var item = ChatItem(role: "user", text: draft.text + (draft.image == nil ? "" : "\n[附照片]"), id: draft.id)
            item.recordedVoice = draft.recording; item.delivery = .queued
            messages.append(item)
            try PrivateFiles.save(messages, "chat.json")
            return true
        } catch { tell(error); return false }
    }
    func sendVoice(_ clip: RecordedVoice, health: HealthService, voice: VoiceService, alarms: AlarmService,
                   inCall: Bool = false, autoVoice: Bool = true, focus: FocusService? = nil) async -> Bool {
        guard paired else { notice = "请先配对私人接口。"; return false }
        if inCall && (busy || checkingCare || !deliveryQueue.isEmpty) { return false }
        voiceNeedsRepeat = false
        guard enqueue(OutgoingMessage(id: clip.id, text: "", recording: clip, inCall: inCall)) else { return false }
        if inCall { return await deliver(clip.id, healthService: health, voice: voice, autoVoice: autoVoice, alarms: alarms, focus: focus) }
        queueDelivery { [weak self] in
            _ = await self?.deliver(clip.id, healthService: health, voice: voice, autoVoice: autoVoice, alarms: alarms, focus: focus)
        }
        return true
    }
    func retry(_ id: UUID, health: HealthService, voice: VoiceService, autoVoice: Bool, alarms: AlarmService, focus: FocusService) async {
        guard messages.first(where: { $0.id == id })?.delivery == .failed else { return }
        if outbox[id.uuidString]?.steerTargetID != nil {
            do {
                let receipt = try await api.followupStatus(id: id)
                if receipt.state == "accepted" { try markSteered(id); return }
                guard receipt.state == "not_applied" else { notice = "这条补充的接收状态仍未明确，没有重复发送。"; return }
                if var value = outbox[id.uuidString] { value.steerTargetID = nil; outbox[id.uuidString] = value; try saveOutbox() }
            } catch { tell(error); return }
        }
        if var draft = outbox[id.uuidString] { draft.retryRequested = true; outbox[id.uuidString] = draft; try? saveOutbox() }
        try? delivery(.queued, id: id)
        queueDelivery { [weak self] in
            _ = await self?.deliver(id, health: health.snapshotForChat, healthService: health, voice: voice,
                autoVoice: autoVoice, alarms: alarms, focus: focus)
        }
    }
    private func deliver(_ id: UUID, health: [String: Any]? = nil, healthService: HealthService? = nil,
                         voice: VoiceService?, autoVoice: Bool, alarms: AlarmService?, focus: FocusService?) async -> Bool {
        guard !busy, !checkingCare else { return false }
        guard paired else { notice = "请先连接私人接口，再点红色感叹号重试。"; return false }
        guard var draft = outbox[id.uuidString] else { notice = "未找到这条消息的待发送内容。"; return false }
        guard !messages.contains(where: { $0.replyingTo == id }) else {
            try? delivery(.sent, id: id); return true
        }
        busy = true; defer { busy = false; voiceStage = ""; activeGeneratingRequestID = nil }
        var background = UIBackgroundTaskIdentifier.invalid
        background = UIApplication.shared.beginBackgroundTask(withName: "LokiMessageUpload") {
            if background != .invalid { UIApplication.shared.endBackgroundTask(background); background = .invalid }
        }
        defer { if background != .invalid { UIApplication.shared.endBackgroundTask(background) } }
        do {
            try delivery(draft.serverAccepted == true ? .waitingReply : .queued, id: id)
            if draft.requestBody == nil {
                voiceStage = "Loki 正在处理你的请求…"
                var snapshot = health
                if draft.recording == nil, let healthService {
                    await healthService.refreshForChat(); snapshot = healthService.snapshotForChat
                }
                if let clip = draft.recording, draft.text.isEmpty {
                    voiceStage = "正在听懂你的语音…"
                    async let recognition = api.transcribe(clip, retry: draft.retryRequested == true)
                    await healthService?.refreshForChat()
                    draft.text = try await recognition
                    snapshot = healthService?.snapshotForChat ?? health
                    outbox[id.uuidString] = draft; try saveOutbox()
                }
                var context: [String: Any] = ["action": "alarm_capability", "state": "available"]
                if !draft.nativeActionStarted {
                    // Claim before any local action, so a restart/retry cannot execute it twice.
                    draft.nativeActionStarted = true
                    outbox[id.uuidString] = draft; try saveOutbox()
                    var confirmedDate: Date?
                    if case .confirm = AlarmChatIntent.parse(draft.text),
                       let current = messages.firstIndex(where: { $0.id == id }),
                       let previous = messages[..<current].last(where: { $0.role == "user" }) {
                        // A response may have arrived after the new message was queued.
                        let reply = messages.filter { $0.replyingTo == previous.id && $0.role == "assistant" && $0.wallpaperAsset == nil }
                        if let repliedAt = reply.first?.date {
                            confirmedDate = AlarmChatIntent.confirmedDate(
                                reply: reply.map(\.text).joined(separator: " "),
                                previousRequest: previous.text, repliedAt: repliedAt)
                        }
                    }
                    let action = await alarms?.handleChat(draft.text, requestID: id, api: api, health: snapshot,
                                                          confirmedDate: confirmedDate)
                    if let action {
                        context = action.payload
                        if let index = messages.firstIndex(where: { $0.id == id }) { messages[index].localActionNote = action.note }
                    }
                } else {
                    context["note"] = "Local action preparation was interrupted; no device action was repeated. Do not claim a new action succeeded."
                }
                if let alarms { context["actual_loki_alarms"] = alarms.chatSnapshot() }
                await MusicService.shared.prepareForChat()
                MusicService.shared.applyModeRequest(draft.text)
                draft.requestBody = try api.prepareChat(id: id, message: draft.text, image: draft.image, health: snapshot,
                    nativeActions: context, wallpaper: wallpaperName,
                    availableWallpapers: Self.wallpaperAssets.filter { UIImage(named: $0) != nil }.sorted(),
                    voiceRequestID: draft.recording == nil ? nil : id, inCall: draft.inCall, nativeFocus: focus?.chatContext,
                    nativeMusic: MusicService.shared.context, nativeShopping: ShoppingService.shared.context)
                outbox[id.uuidString] = draft; try saveOutbox()
                try PrivateFiles.save(messages, "chat.json")
            }
            try Task.checkCancellation()
            if draft.serverAccepted != true {
                try delivery(.sending, id: id)
                try await api.accept(prepared: draft.requestBody!)
                draft.serverAccepted = true
                outbox[id.uuidString] = draft; try saveOutbox()
            }
            if let index = messages.firstIndex(where: { $0.id == id }) { messages[index].acceptedByServer = true }
            try delivery(.waitingReply, id: id)
            voiceStage = "Loki 正在想…"
            activeGeneratingRequestID = id
            let reply = try await api.replyToAccepted(id: id, retry: draft.retryRequested == true)
            activeGeneratingRequestID = nil
            // Server has finished even if iOS suspends us. Device actions/audio wait for foreground.
            while UIApplication.shared.applicationState != .active {
                try await Task.sleep(for: .milliseconds(300))
            }
            for followup in reply.steered_ids ?? [] { try markSteered(followup) }
            try Task.checkCancellation()
            voiceStage = "Loki 正在说话"
            try await showReply(reply.speech_text ?? reply.text, voice: voice, autoVoice: autoVoice,
                wallpaper: reply.wallpaper_change, control: reply.app_control, focus: focus, replyingTo: id,
                waitForSpeech: draft.inCall && reply.music_action == nil)
            await handleServices(reply, requestID: id, voice: voice, autoVoice: autoVoice)
            outbox.removeValue(forKey: id.uuidString); try? saveOutbox()
            var inbox: [String: Data] = PrivateFiles.load("received-replies.json", fallback: [:])
            inbox.removeValue(forKey: id.uuidString); try? PrivateFiles.save(inbox, "received-replies.json")
            let receiptAPI = api
            Task { try? await receiptAPI.event(kind: "delivery", body: ["request_id": id.uuidString, "stage": "client_stored"]) }
            return true
        } catch {
            if messages.contains(where: { $0.replyingTo == id }) {
                try? delivery(.sent, id: id); return true
            }
            let generationFailed: Bool
            if case LokiError.replyGenerationFailed = error { generationFailed = true } else { generationFailed = false }
            if !generationFailed && (draft.serverAccepted == true ||
                ((error is URLError || error is CancellationError) && draft.requestBody != nil)) {
                // Lost ACK / interrupted poll: keep original body and ID, never duplicate the turn.
                try? delivery(draft.serverAccepted == true ? .waitingReply : .sending, id: id)
                return false
            }
            if let index = messages.firstIndex(where: { $0.id == id }) { messages[index].deliveryError = error.localizedDescription }
            try? delivery(.failed, id: id)
            if case LokiError.speechNotClear = error, draft.recording != nil {
                voiceNeedsRepeat = true
                if !draft.inCall, let voice { await askForRepeat(voice: voice, autoVoice: autoVoice) }
            }
            return false
        }
    }
    func askForRepeat(voice: VoiceService, autoVoice: Bool = true) async {
        let text = ["I didn't catch that. Say it again for me.", "You lost me for a moment. Once more?", "A little clearer, darling. I missed that last bit."].randomElement()!
        do { try await showReply(text, voice: voice, autoVoice: autoVoice, waitForSpeech: callActive) }
        catch { tell(error) }
    }
    private static func englishDialogue(_ text: String, fallback: String) -> String {
        // Ordinary dialogue is validated upstream. Tool comments and restored
        // replies also pass here before display and before speech is queued.
        text.range(of: #"\p{Han}"#, options: .regularExpression) == nil ? text : fallback
    }

    private func showReply(_ text: String, voice: VoiceService?, autoVoice: Bool, wallpaper: WallpaperChange? = nil,
                           control: AppControl? = nil, focus: FocusService? = nil, replyingTo: UUID? = nil,
                           interject: Bool = false, waitForSpeech: Bool = false, careEventID: String? = nil) async throws {
        let dialogue = Self.englishDialogue(text, fallback: "I couldn't say that clearly. Ask me once more.")
        var items = SentenceReplies.split(dialogue).map {
            ChatItem(role: "assistant", text: SentenceReplies.visible($0), speechText: $0)
        }
        if let careEventID, !items.isEmpty { items[0].careEventID = careEventID }
        if let change = wallpaper,
           UserDefaults.standard.object(forKey: "autoWallpaper") as? Bool ?? true,
           change.asset_id != wallpaperName,
           Self.wallpaperAssets.contains(change.asset_id), UIImage(named: change.asset_id) != nil,
           !change.comment.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
           !messages.contains(where: { $0.wallpaperChangeID == change.id.uuidString }) {
            let dialogue = Self.englishDialogue(change.comment, fallback: "I felt like a change of scenery. Do you like it?")
            var comment = ChatItem(role: "assistant", text: SentenceReplies.visible(dialogue), id: change.id, speechText: dialogue)
            comment.wallpaperAsset = change.asset_id; comment.wallpaperChangeID = change.id.uuidString
            items.append(comment)
        }
        if let control, let focus {
            let result = focus.apply(control)
            if result.completed {
                let dialogue = Self.englishDialogue(control.success_comment, fallback: "I've updated your app limits.")
                var comment = ChatItem(role: "assistant", text: SentenceReplies.visible(dialogue), id: control.id,
                    speechText: dialogue)
                comment.localActionNote = result.note
                items.append(comment)
            } else if !items.isEmpty { items[0].localActionNote = result.note }
        }
        // Commit every text bubble before playback; synthesis never gates reading.
        for index in items.indices { items[index].replyingTo = replyingTo }
        var updated = messages + items
        if let replyingTo, let index = updated.firstIndex(where: { $0.id == replyingTo }) {
            updated[index].delivery = .sent
        }
        // One durable write contains both the new background and its actual remark.
        try PrivateFiles.save(updated, "chat.json")
        messages = updated
        Task { await syncWallpaperReceipt() }
        if autoVoice, let voice {
            if waitForSpeech {
                await withCheckedContinuation { continuation in
                    enqueueSpeech(items, voice: voice, interject: interject) { continuation.resume() }
                }
            } else { enqueueSpeech(items, voice: voice, interject: interject) {} }
        }
    }
    private func enqueueSpeech(_ items: [ChatItem], voice: VoiceService, interject: Bool,
                               finished: @escaping @MainActor () -> Void) {
        guard !items.isEmpty else { finished(); return }
        let batch = UUID()
        let packets = items.enumerated().map { index, item in
            SpokenPacket(item: item, batch: batch, voice: voice, finished: index == items.count - 1 ? finished : {})
        }
        spokenQueue.insert(packets, interject: interject, preservePreparedNext: spokenTask != nil)
        guard spokenTask == nil else { return }
        spokenTask = Task { @MainActor [weak self] in
            guard let self else { return }
            defer { self.spokenTask = nil }
            while let first = self.spokenQueue.first {
                if first.voice.recording || first.voice.playing {
                    do { try await Task.sleep(for: .milliseconds(100)) } catch { break }
                    continue
                }
                guard let packet = self.spokenQueue.take() else { break }
                let next = self.spokenQueue.first?.item
                let played = await packet.voice.speakAndWait(packet.item.voiceText, api: self.api,
                    messageID: packet.item.id, next: next)
                packet.finished()
                if !played {
                    for removed in self.spokenQueue.remove(where: { $0.batch == packet.batch }) { removed.finished() }
                }
                packet.voice.releaseAudioSessionIfIdle()
            }
        }
    }
    static let wallpaperAssets = Set(["ChatWallpaper"] + (1...18).map { String(format: "Wallpaper%02d", $0) })
    private func handleServices(_ reply: MobileReply, requestID: UUID?, voice: VoiceService?, autoVoice: Bool) async {
        if let action = reply.music_action {
            let introducedPlayback = ["search_play", "play_known", "next", "resume"].contains(action.action)
                && !SentenceReplies.visible(reply.speech_text ?? reply.text).isEmpty
            if introducedPlayback { MusicService.shared.recordComment(reply.speech_text ?? reply.text) }
            let (completed, note) = await MusicService.shared.apply(action)
            if completed, !introducedPlayback, let comment = action.success_comment, !comment.isEmpty {
                let dialogue = Self.englishDialogue(comment, fallback: "It's done.")
                do { try await showReply(dialogue, voice: voice, autoVoice: autoVoice); MusicService.shared.recordComment(dialogue) }
                catch { tell(error) }
            } else if !completed && !MusicService.shared.playbackPending { MusicService.shared.error = note }
            let sourceTrace = await MusicService.shared.client.sourceTrace()
            Task { try? await api.event(kind: "delivery", body: ["stage": "music_action_result", "action_id": action.id.uuidString,
                "completed": completed, "buffering": MusicService.shared.playbackPending, "detail": note, "source_trace": sourceTrace]) }
        }
        if let action = reply.shopping_action, let requestID,
           let result = await ShoppingService.shared.apply(action) {
            do {
                let followup = try await api.shoppingResult(action: action.id, request: requestID, result: result)
                try await showReply(followup.speech_text ?? followup.text, voice: voice, autoVoice: autoVoice)
            } catch { ShoppingService.shared.reportPendingResult() }
        }
    }
    func refreshMusicCompanion(voice: VoiceService) async {
        let music = MusicService.shared
        guard unlocked, paired, !callActive, !busy, !checkingCare, !composing, !voice.playing, !voice.recording,
              let event = music.takeEvent() else { return }
        checkingCare = true; defer { checkingCare = false }
        let generation = music.epoch
        do {
            let reply = try await api.musicCompanion(event, context: music.context)
            guard music.connected, music.companion, music.epoch == generation else { return }
            let text = reply.speech_text ?? reply.text
            if !text.isEmpty { try await showReply(text, voice: voice, autoVoice: UserDefaults.standard.object(forKey: "autoVoice") as? Bool ?? true); music.recordComment(text) }
            await handleServices(reply, requestID: nil, voice: voice,
                autoVoice: UserDefaults.standard.object(forKey: "autoVoice") as? Bool ?? true)
        } catch { music.status = "一起听继续；本次聊天暂未取得回复" }
    }
    func syncWallpaperReceipt() async {
        guard paired, !syncingWallpaper else { return }
        guard let change = messages.last(where: { $0.wallpaperChangeID != nil }), let id = change.wallpaperChangeID,
              !wallpaperReceipts.contains(id), let asset = change.wallpaperAsset else { return }
        syncingWallpaper = true; defer { syncingWallpaper = false }
        if let data = try? await api.data("/v1/wallpaper/received", ["id": id, "asset_id": asset], timeout: 4),
           let body = try? JSONSerialization.jsonObject(with: data) as? [String: Any], body["stored"] as? Bool == true {
            wallpaperReceipts.append(id)
            try? PrivateFiles.save(wallpaperReceipts, "wallpaper-receipts.json")
        }
    }
    func refreshCompanion(voice: VoiceService) async {
        guard unlocked, paired, !callActive, !pullingCompanion else { return }
        pullingCompanion = true; defer { pullingCompanion = false }
        do {
            let hrv = UserDefaults.standard.object(forKey: "hrvCompanionEnabled") as? Bool ?? true
            let weather = UserDefaults.standard.bool(forKey: "weatherCompanionEnabled")
            let health = UserDefaults.standard.bool(forKey: "healthAutoSync")
            let offset = TimeZone.current.secondsFromGMT(for: Date())
            let configuration = "\(hrv && health):\(weather):\(offset)"
            if configuration != lastCareConfiguration {
                _ = try await api.data("/v1/care/settings", ["hrv_enabled": hrv && health, "weather_enabled": weather,
                    "utc_offset_seconds": offset], timeout: 10)
                lastCareConfiguration = configuration
            }
            guard (hrv && health) || weather else { return }
            struct Status: Decodable { let has_due_event: Bool; let push_active: Bool }
            let status = try JSONDecoder().decode(Status.self, from: await api.data("/v1/care/status", timeout: 8))
            carePushReady = status.push_active
            guard status.has_due_event else { return }
            let zone = TimeZone.current
            let data = try await api.data("/v1/care/next", ["device_clock": ["time_zone": zone.identifier,
                "utc_offset_seconds": zone.secondsFromGMT(for: Date())]], timeout: 90)
            struct CareItem: Decodable { let id: String; let text: String; let speech_text: String? }
            struct Envelope: Decodable { let item: CareItem? }
            guard let item = try JSONDecoder().decode(Envelope.self, from: data).item else { return }
            if !receivedCare.contains(item.id) && !messages.contains(where: { $0.careEventID == item.id }) {
                try await showReply(item.speech_text ?? item.text, voice: voice,
                    autoVoice: UserDefaults.standard.object(forKey: "autoVoice") as? Bool ?? true,
                    interject: true, waitForSpeech: false, careEventID: item.id)
            }
            if !receivedCare.contains(item.id) { receivedCare.append(item.id); try PrivateFiles.save(receivedCare, "companion-received.json") }
            _ = try await api.data("/v1/care/received", ["id": item.id], timeout: 8)
            careStatus = "已收到 Loki 的主动消息"
        } catch {
            careStatus = "主动关心等待联网或接口就绪"
            let reason = String(error.localizedDescription.prefix(180))
            Task { try? await api.event(kind: "delivery", body: ["stage": "care_fetch_failed", "error": reason]) }
        }
    }
    func refreshCommands() async {
        guard paired else { return }
        do {
            commands = try await api.commands().filter { $0.valid && ledger[$0.id] == nil }
            // Re-send only idempotent execution receipts, never execute a command twice.
            for receipt in ledger.values {
                try? await api.receipt(receipt.command, state: receipt.state, detail: receipt.detail)
            }
        } catch { tell(error) }
    }
    func decline(_ command: MobileCommand) async {
        do {
            ledger[command.id] = .init(command: command, state: "declined", detail: "用户拒绝")
            try PrivateFiles.save(ledger, "tool-receipts.json")
            commands.removeAll { $0.id == command.id }
            try await api.receipt(command, state: "declined", detail: "用户拒绝")
        } catch { tell(error) }
    }
    func execute(_ command: MobileCommand, health: HealthService, focus: FocusService,
                 notifications: NotificationService, alarms: AlarmService, device: DeviceTools) async {
        guard !commandBusy, ledger[command.id] == nil else { return }
        guard command.valid else { notice = "这条请求已过期。"; return }
        commandBusy = true; defer { commandBusy = false }
        var state = "failed", detail = "未执行"
        do {
            // Durable claim before any side effect. A crash leaves 'interrupted'; no replay.
            ledger[command.id] = .init(command: command, state: "interrupted", detail: "执行结果尚未确认，禁止自动重复")
            try PrivateFiles.save(ledger, "tool-receipts.json")
            switch command.name {
            case "health":
                try await health.authorize()
                detail = health.readings.isEmpty ? health.message : "已在手机读取 \(health.readings.count) 项；未自动上传"
            case "brightness":
                guard let value = command.arguments["value"]?.number, (0.05...1).contains(value) else { throw LokiError.message("亮度范围必须为 0.05–1。") }
                try device.setBrightness(value); detail = "已调整屏幕亮度"
            case "torch":
                guard case .bool(let on)? = command.arguments["on"] else { throw LokiError.message("缺少开关参数。") }
                try device.torch(on); detail = on ? "手电筒已打开" : "手电筒已关闭"
            case "app_limit":
                guard let minutes = command.arguments["minutes"]?.number, minutes.isFinite, minutes >= 15, minutes <= 120 else { throw LokiError.message("专注时长须为 15–120 分钟。") }
                try focus.start(minutes: Int(minutes)); detail = focus.status
            case "reminder", "alarm":
                guard let timestamp = command.arguments["at"]?.number, timestamp.isFinite,
                      timestamp > Date().timeIntervalSince1970, timestamp < Date().timeIntervalSince1970 + 366 * 86400 else { throw LokiError.message("提醒时间无效。") }
                let title = String((command.arguments["title"]?.string ?? "Loki 提醒").prefix(160))
                if command.name == "alarm" { try await alarms.schedule(title: title, at: Date(timeIntervalSince1970: timestamp)) }
                else { _ = try await notifications.schedule(title: "Loki", body: title, at: Date(timeIntervalSince1970: timestamp)) }
                detail = "系统已接受定时请求；实际响铃仍受系统和设备状态影响。"
            default: throw LokiError.message("这项工具当前不支持自动执行，请使用工具页。")
            }
            state = "completed"
        } catch { detail = error.localizedDescription }
        ledger[command.id] = .init(command: command, state: state, detail: detail)
        do { try PrivateFiles.save(ledger, "tool-receipts.json"); try await api.receipt(command, state: state, detail: detail) }
        catch { notice = "结果保留在本机，回执尚未同步。不会重复操作。" }
        commands.removeAll { $0.id == command.id }
        notice = detail
    }
    func persistTasks() {
        do { try PrivateFiles.save(tasks, "tasks.json") } catch { tell(error) }
    }
}
