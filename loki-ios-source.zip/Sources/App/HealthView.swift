import SwiftUI

struct HealthView: View {
    @EnvironmentObject private var health: HealthService
    @EnvironmentObject private var app: AppState
    @AppStorage("healthAutoSync") private var autoSync = false
    @State private var trends: [HealthMetric: [HealthDay]] = [:]
    private var trendRevision: [Date] { [Calendar.current.startOfDay(for: .now)] + health.readings.map(\.recordedAt) }

    var body: some View {
        NavigationStack {
            HealthDashboard(readings: health.readings, sleep: health.sleepDetails,
                            busy: health.busy, message: health.message, lastSynced: health.lastSyncedAt,
                            trends: trends.merging([.sleep: health.sleepTrend]) { _, sleep in sleep },
                            authorize: { Task { do { try await health.authorize() } catch { app.tell(error) } } }) { metric in
                if metric == .sleep {
                    if let details = health.sleepDetails { HealthSleepPage(details: details) }
                    else { ContentUnavailableView("暂无睡眠阶段", systemImage: "moon.zzz") }
                } else {
                    HealthTrendView(metric: metric, recent: trends[metric])
                }
            } settings: {
                HealthSharingView()
            }
            .refreshable {
                await health.refresh()
                await health.syncPending()
                await loadTrends()
            }
            .task(id: trendRevision) { await loadTrends() }
            .task {
                await health.refresh(upload: false)
                if autoSync { await health.syncPending() }
            }
        }.tint(LokiDesign.gold)
    }

    private func loadTrends() async {
        let revision = trendRevision
        async let steps = try? health.dailyTrend(.steps, days: 7)
        async let heart = try? health.dailyTrend(.heart, days: 7)
        async let hrv = try? health.dailyTrend(.hrv, days: 7)
        let result = await (steps, heart, hrv)
        guard !Task.isCancelled, revision == trendRevision else { return }
        trends = [.steps: result.0 ?? [], .heart: result.1 ?? [], .hrv: result.2 ?? []]
    }
}

/// Renders one snapshot. Live and preview screens use the same cards and layout.
struct HealthDashboard<Detail: View, Settings: View>: View {
    @Environment(\.dynamicTypeSize) private var typeSize
    let readings: [HealthReading]
    let sleep: SleepDetails?
    let busy: Bool
    let message: String
    let lastSynced: Date?
    let trends: [HealthMetric: [HealthDay]]
    let authorize: () -> Void
    @ViewBuilder let detail: (HealthMetric) -> Detail
    @ViewBuilder let settings: () -> Settings

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 19) {
                masthead
                HStack {
                    Text("今日概览").font(.title3.weight(.semibold))
                    Spacer()
                    if busy { ProgressView().controlSize(.small).accessibilityLabel("正在读取健康数据") }
                    else { Label("Apple 健康", systemImage: "heart.text.clipboard").font(.caption).foregroundStyle(LokiDesign.muted) }
                }
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10),
                                         count: typeSize.isAccessibilitySize ? 1 : 2), spacing: 10) {
                    ForEach(HealthMetric.allCases) { metric in
                        let reading = readings.first { $0.id == metric.rawValue }
                        if reading != nil || metric != .sleep {
                            NavigationLink { detail(metric) } label: {
                                HealthMetricCard(metric: metric, reading: reading, trend: trends[metric] ?? [], hasDetail: true)
                            }.buttonStyle(.plain).accessibilityIdentifier("health-card-\(metric.rawValue)")
                        } else {
                            HealthMetricCard(metric: metric, reading: nil, trend: [], hasDetail: false)
                        }
                    }
                }
                if readings.isEmpty && !busy {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("暂无可读取的健康记录", systemImage: "heart.slash").font(.headline)
                        Text(message).font(.footnote).foregroundStyle(LokiDesign.muted)
                        Button("读取 Apple 健康", action: authorize)
                            .buttonStyle(.bordered).tint(LokiDesign.gold)
                    }.padding(16).frame(maxWidth: .infinity, alignment: .leading).lokiPanel()
                }
                if let sleep {
                    VStack(alignment: .leading, spacing: 12) {
                        NavigationLink { detail(.sleep) } label: {
                            HStack {
                                Label("最近一晚", systemImage: "moon.stars").font(.headline)
                                Spacer()
                                Text("睡眠详情").font(.caption)
                                Image(systemName: "chevron.right").font(.caption2)
                            }
                        }.buttonStyle(.plain).foregroundStyle(LokiDesign.gold)
                            .accessibilityIdentifier("health-sleep-detail")
                        SleepStageTimelineView(details: sleep)
                    }.padding(16).lokiPanel()
                }
                NavigationLink(destination: settings) {
                    HStack(spacing: 12) {
                        Image(systemName: "lock.shield").foregroundStyle(LokiDesign.gold)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("数据与分享").font(.subheadline.weight(.semibold))
                            if let lastSynced {
                                Text("同步于 \(lastSynced.formatted(.dateTime.month().day().hour().minute()))")
                                    .font(.caption).foregroundStyle(LokiDesign.muted)
                            } else {
                                Text("本机授权、同步与 HRV 陪伴").font(.caption).foregroundStyle(LokiDesign.muted)
                            }
                        }
                        Spacer()
                        Image(systemName: "chevron.right").font(.caption).foregroundStyle(LokiDesign.gold)
                    }.padding(15).lokiPanel()
                }.buttonStyle(.plain)
            }.padding(LokiDesign.pageInset).padding(.bottom, 12)
        }
        .background { LokiBackdrop() }
        .foregroundStyle(LokiDesign.ink)
        .navigationTitle("健康")
        .navigationBarTitleDisplayMode(.inline)
    }

    private var masthead: some View {
        VStack(alignment: .leading, spacing: 7) {
            LokiEyebrow(title: "LOKI  /  HEALTH")
            Text("身体手记").font(.system(.largeTitle, design: .serif).weight(.semibold))
                .accessibilityAddTraits(.isHeader)
            Text(Date.now.formatted(.dateTime.month(.wide).day().weekday(.wide)))
                .font(.subheadline).foregroundStyle(LokiDesign.muted)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.vertical, 6)
    }
}

private struct HealthMetricCard: View {
    let metric: HealthMetric
    let reading: HealthReading?
    let trend: [HealthDay]
    let hasDetail: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Image(systemName: metric.icon).foregroundStyle(LokiDesign.gold).accessibilityHidden(true)
                Text(metric.title).fontWeight(.semibold)
                Spacer(minLength: 0)
                if hasDetail { Image(systemName: "chevron.right").font(.caption2).foregroundStyle(LokiDesign.muted) }
            }.font(.subheadline)
            ViewThatFits(in: .horizontal) {
                HStack(alignment: .firstTextBaseline, spacing: 5) { value; unit }
                VStack(alignment: .leading, spacing: 2) { value; unit }
            }
            if let reading {
                Text(reading.recordedAt.formatted(.dateTime.month().day().hour().minute()))
                    .font(.caption2.monospacedDigit()).foregroundStyle(LokiDesign.muted)
                if !Calendar.current.isDateInToday(reading.recordedAt) && metric != .sleep {
                    Text("较早的记录").font(.caption2).foregroundStyle(LokiDesign.gold)
                }
            } else {
                Text("暂无记录").font(.caption2).foregroundStyle(LokiDesign.muted)
            }
            HealthSparkline(days: trend)
            Text(metric == .sleep ? "近 7 晚 · 查看分期" : "近 7 天")
                .font(.caption2).foregroundStyle(LokiDesign.gold)
        }
        .frame(maxWidth: .infinity, minHeight: 126, alignment: .topLeading)
        .padding(13).lokiPanel()
        .accessibilityElement(children: .combine)
    }

    private var value: some View {
        let displayValue = reading.map { metric == .sleep && $0.unit == "分钟" ? $0.value / 60 : $0.value }
        return Text(displayValue?.formatted(.number.precision(.fractionLength(0...1))) ?? "—")
            .font(.custom("CormorantGaramond-SemiBold", size: 36, relativeTo: .title))
            .monospacedDigit().foregroundStyle(LokiDesign.ink)
    }

    private var unit: some View {
        let displayUnit = metric == .sleep && reading?.unit == "分钟" ? metric.unit : (reading?.unit ?? metric.unit)
        return Text(displayUnit).font(.caption).foregroundStyle(LokiDesign.muted)
    }
}


/// Keeps missing days in their positions and never draws across them.
private struct HealthSparkline: View {
    let days: [HealthDay]
    var body: some View {
        if days.contains(where: { $0.value != nil }) {
            Canvas { context, size in draw(context, size: size) }
                .frame(height: 21).accessibilityHidden(true)
        } else {
            Text("暂无趋势数据").font(.caption2).foregroundStyle(LokiDesign.muted)
        }
    }

    private func draw(_ context: GraphicsContext, size: CGSize) {
        let values = days.compactMap(\.value)
        guard let low = values.min(), let high = values.max() else { return }
        let spread = high - low
        let spacing = max(0, size.width - 4) / CGFloat(max(1, days.count - 1))
        let height = max(0, size.height - 4)
        var line = Path()
        var previous: CGPoint?
        for (index, day) in days.enumerated() {
            guard let value = day.value else { previous = nil; continue }
            let ratio = CGFloat(spread > 0 ? (value - low) / spread : 0.5)
            let point = CGPoint(x: 2 + CGFloat(index) * spacing, y: 2 + (1 - ratio) * height)
            if let previous {
                line.move(to: previous)
                line.addLine(to: point)
            }
            let dot = CGRect(x: point.x - 1.75, y: point.y - 1.75, width: 3.5, height: 3.5)
            context.fill(Path(ellipseIn: dot), with: .color(LokiDesign.gold))
            previous = point
        }
        context.stroke(line, with: .color(LokiDesign.gold), lineWidth: 1.4)
    }
}

struct HealthSleepPage: View {
    let details: SleepDetails
    var body: some View {
        ScrollView {
            SleepDetailsView(details: details)
                .padding(16).lokiPanel().padding(LokiDesign.pageInset)
        }.background { LokiBackdrop() }.navigationTitle("睡眠详情")
    }
}

private struct HealthSharingView: View {
    @EnvironmentObject private var health: HealthService
    @EnvironmentObject private var app: AppState
    @AppStorage("healthBackground") private var background = false
    @AppStorage("healthAutoSync") private var autoSync = false
    @AppStorage("hrvCompanionEnabled") private var hrvCompanion = true
    var body: some View {
        Form {
            Section("Apple 健康") {
                Button("读取已授权的数据", systemImage: "heart.text.clipboard") {
                    Task { do { try await health.authorize() } catch { app.tell(error) } }
                }.disabled(health.busy)
                Text(health.message).font(.caption).foregroundStyle(.secondary)
            }
            Section("更新与分享") {
                Toggle("自动同步已授权的数据给 Loki", isOn: Binding(get: { autoSync }, set: { value in
                    Task { do { try await health.setAutomaticSharing(value) } catch { app.tell(error) } }
                }))
                Toggle("允许系统后台更新健康卡片", isOn: Binding(get: { background }, set: { value in
                    Task { do { try await health.background(value); background = value } catch { background = false; app.tell(error) } }
                }))
                Text("后台更新由系统与手表同步决定。页面保留实际采样时间。")
                    .font(.caption).foregroundStyle(.secondary)
                Text(health.syncMessage).font(.caption).foregroundStyle(.secondary)
                if let synced = health.lastSyncedAt { Text("最近同步：\(synced.formatted())").font(.caption) }
                Button("现在刷新并同步") { Task { await health.refresh(); await health.syncPending() } }
                    .disabled(health.busy || !autoSync || !app.paired)
            }
            Section("HRV 陪伴互动") {
                Toggle("每条新 HRV 触发 Loki 的主动关心", isOn: $hrvCompanion)
                Text("沿用你设定的个人基线与陪伴规则。锁屏推送仍取决于系统和网络。")
                    .font(.caption).foregroundStyle(.secondary)
                if !app.careStatus.isEmpty { Text(app.careStatus).font(.caption) }
            }
        }
        .scrollContentBackground(.hidden)
        .background { LokiBackdrop() }
        .navigationTitle("数据与分享")
    }
}
