import Foundation
import Combine
import UserNotifications
import UIKit

@MainActor final class NotificationService: ObservableObject {
    @Published var pending: [UNNotificationRequest] = []
    func authorize() async throws {
        let granted = try await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge])
        guard granted else { throw LokiError.message("通知权限未开启，请到系统设置中允许通知。") }
        UIApplication.shared.registerForRemoteNotifications()
    }
    @discardableResult func schedule(title: String, body: String, at date: Date) async throws -> String {
        guard date > Date() else { throw LokiError.message("提醒时间需要晚于现在。") }
        try await authorize()
        let content = UNMutableNotificationContent()
        content.title = title; content.body = body; content.sound = .default
        content.threadIdentifier = "loki-personal"
        let id = UUID().uuidString
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: max(1, date.timeIntervalSinceNow), repeats: false)
        try await UNUserNotificationCenter.current().add(.init(identifier: id, content: content, trigger: trigger))
        await refresh()
        return id
    }
    func refresh() async { pending = await UNUserNotificationCenter.current().pendingNotificationRequests() }
    func register(api: MobileAPI) async throws {
        let started = Date()
        UserDefaults.standard.removeObject(forKey: "apnsRegistrationError")
        try await authorize()
        for _ in 0..<100 {
            if let registered = UserDefaults.standard.object(forKey: "apnsRegisteredAt") as? Date,
               registered >= started, let token = UserDefaults.standard.string(forKey: "apnsToken"),
               let topic = Bundle.main.bundleIdentifier {
                _ = try await api.data("/v1/device", ["token": token, "topic": topic], timeout: 10)
                return
            }
            if let error = UserDefaults.standard.string(forKey: "apnsRegistrationError") { throw LokiError.message(error) }
            try await Task.sleep(for: .milliseconds(100))
        }
        throw LokiError.message("系统推送令牌尚未返回，请稍后重试登记。")
    }
    func cancel(_ id: String) async {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [id])
        await refresh()
    }
}

final class AppDelegate: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any],
                     fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        guard let raw = userInfo["reply_id"] as? String, let id = UUID(uuidString: raw) else {
            completionHandler(.noData); return
        }
        Task { @MainActor in
            // Keep the existing private-file and keychain protection. A locked phone
            // may defer this fetch; foreground reconciliation is the durable fallback.
            let drafts: [String: OutgoingMessage] = PrivateFiles.load("outgoing.json", fallback: [:])
            guard drafts[id.uuidString] != nil else { completionHandler(.noData); return }
            let api = MobileAPI(base: UserDefaults.standard.string(forKey: "gatewayURL") ?? "", token: SecureToken.read())
            do {
                let data = try await api.chatStatusData(id: id)
                let status = try JSONDecoder().decode(ChatRequestStatus.self, from: data)
                guard status.state == "complete", status.reply != nil else { completionHandler(.noData); return }
                var inbox: [String: Data] = PrivateFiles.load("received-replies.json", fallback: [:])
                inbox = inbox.filter { drafts[$0.key] != nil }
                inbox[id.uuidString] = data
                try PrivateFiles.save(inbox, "received-replies.json")
                completionHandler(.newData)
            } catch { completionHandler(.failed) }
        }
    }
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        UNUserNotificationCenter.current().delegate = self
        HealthService.shared.restoreObserversOnLaunch()
        LocationService.shared.restoreAutomatic()
        return true
    }
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        let token = deviceToken.map { String(format: "%02x", $0) }.joined()
        // Device token remains private on this phone until explicit registration.
        UserDefaults.standard.set(token, forKey: "apnsToken")
        UserDefaults.standard.set(Date(), forKey: "apnsRegisteredAt")
    }
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        UserDefaults.standard.set("推送登记未完成，请检查签名权限和网络。", forKey: "apnsRegistrationError")
    }
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler(notification.request.content.userInfo["reply_id"] != nil ? [] : [.banner, .sound])
    }
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        NotificationCenter.default.post(name: .init("LokiOpenChat"), object: nil)
        completionHandler()
    }
}
