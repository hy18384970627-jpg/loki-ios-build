import Foundation

enum MusicPlaybackMode: String, CaseIterable, Codable {
    case order, repeatOne = "repeat_one", repeatAll = "repeat_all", shuffle
    var title: String {
        switch self { case .order: return "顺序播放"; case .repeatOne: return "单曲循环"; case .repeatAll: return "列表循环"; case .shuffle: return "随机播放" }
    }
    var symbol: String {
        switch self { case .order: return "list.bullet"; case .repeatOne: return "repeat.1"; case .repeatAll: return "repeat"; case .shuffle: return "shuffle" }
    }
    func nextIndex(count: Int, current: Int, ended: Bool, shuffled: Int?) -> Int? {
        guard count > 0, (0..<count).contains(current) else { return nil }
        if self == .repeatOne && ended { return current }
        if self == .shuffle {
            if count == 1 { return current }
            guard let shuffled, (0..<count).contains(shuffled), shuffled != current else { return nil }
            return shuffled
        }
        if current + 1 < count { return current + 1 }
        return self == .repeatAll || (self == .repeatOne && !ended) ? 0 : nil
    }
    static func requested(_ message: String) -> MusicPlaybackMode? {
        let text = message.lowercased()
        if ["区别", "什么意思", "介绍", "支持哪些", "有哪些", "what is", "difference"].contains(where: text.contains) { return nil }
        if ["不要", "别", "不用", "don't", "do not"].contains(where: text.contains) { return nil }
        if ["取消单曲循环", "关闭单曲循环", "取消随机播放", "关闭随机播放"].contains(where: text.contains) { return .order }
        let matches: [(MusicPlaybackMode, [String])] = [
            (.repeatOne, ["单曲循环", "循环这首", "这首循环", "repeat one", "repeat this song", "loop this song", "loop this track"]),
            (.repeatAll, ["列表循环", "歌单循环", "循环列表", "repeat all", "loop the playlist"]),
            (.shuffle, ["随机播放", "随机顺序", "打乱播放", "shuffle"]),
            (.order, ["顺序播放", "按顺序放", "按顺序播", "in order", "sequential"])]
        let selected = matches.filter { $0.1.contains(where: text.contains) }.map { $0.0 }
        return selected.count == 1 ? selected[0] : nil
    }
}
