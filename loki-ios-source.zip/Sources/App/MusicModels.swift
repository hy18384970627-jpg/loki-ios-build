import Foundation

struct MusicSong: Codable, Identifiable, Equatable {
    let id: String
    let title: String
    let artist: String
    let duration: Double
    static func parse(_ value: [String: Any]) -> MusicSong? {
        guard let id = identifier(value["id"]), let title = value["name"] as? String else { return nil }
        let artists = value["ar"] as? [[String: Any]] ?? value["artists"] as? [[String: Any]] ?? []
        let duration = (value["dt"] as? NSNumber ?? value["duration"] as? NSNumber)?.doubleValue ?? 0
        return .init(id: id, title: title, artist: artists.compactMap { $0["name"] as? String }.joined(separator: ", "), duration: duration / 1000)
    }
    static func identifier(_ value: Any?) -> String? {
        let text = (value as? String) ?? (value as? NSNumber)?.stringValue ?? ""
        guard !text.isEmpty, text.count <= 20, text.allSatisfy({ $0.isASCII && $0.isNumber }) else { return nil }
        return text
    }
}
struct MusicPlaylist: Identifiable {
    let id: String
    let name: String
    let count: Int
}
struct MusicAction: Decodable {
    let id: UUID
    let action: String
    let mode: String?
    let query: String?
    let song_id: String?
    let playlist_id: String?
    let name: String?
    let success_comment: String?
    let expires: Double
}
struct MusicEvent: Identifiable {
    let id: UUID
    let kind: String
    let epoch: UUID
    let song: MusicSong
}
enum MusicPolicy {
    static func opportunity(secondsSinceLast: Double, draw: Double) -> Bool {
        secondsSinceLast >= 75 && draw < 1 - exp(-secondsSinceLast / 240)
    }
    static func mediaURL(_ text: String) -> URL? {
        guard var parts = URLComponents(string: text), ["http", "https"].contains(parts.scheme ?? ""), let host = parts.host?.lowercased(),
              parts.user == nil, parts.password == nil,
              host.hasSuffix(".music.126.net") || host.hasSuffix(".music.163.com") else { return nil }
        parts.scheme = "https"
        return parts.url
    }
}
