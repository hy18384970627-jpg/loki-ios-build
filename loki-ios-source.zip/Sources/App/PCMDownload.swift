import Foundation

/// Receives native Data packets, not 48,000 asynchronous byte iterations/second.
/// Pauses only this request when the consumer falls behind; audio is never dropped.
final class PCMDownload: NSObject, URLSessionDataDelegate, @unchecked Sendable {
    private let lock = NSLock()
    private var continuation: AsyncThrowingStream<Data, Error>.Continuation?
    private var task: URLSessionDataTask?
    private let transport: PCMTransport
    init(transport: PCMTransport = .shared) { self.transport = transport; super.init() }
    private var buffered = 0
    private var received = 0
    private var paused = false
    private var finished = false
    func stream(for request: URLRequest) -> AsyncThrowingStream<Data, Error> {
        return AsyncThrowingStream { continuation in
            self.continuation = continuation
            continuation.onTermination = { [weak self] _ in self?.cancel() }
            let task = transport.makeTask(request, receiver: self)
            self.task = task; task.resume()
        }
    }
    func consumed(_ count: Int) {
        lock.lock(); defer { lock.unlock() }
        buffered = max(0, buffered - count)
        if paused && buffered < 48_000 && !finished {
            paused = false; task?.resume()
        }
    }
    func cancel() {
        lock.lock()
        guard !finished else { lock.unlock(); return }
        finished = true
        let continuation = self.continuation, task = self.task
        self.continuation = nil
        lock.unlock()
        task?.cancel(); continuation?.finish(throwing: CancellationError())
        if let task { transport.remove(task) }
    }
    private func finish(_ error: Error? = nil) {
        lock.lock()
        guard !finished else { lock.unlock(); return }
        finished = true
        let continuation = self.continuation, task = self.task
        self.continuation = nil
        lock.unlock()
        if let error { continuation?.finish(throwing: error) }
        else { continuation?.finish() }
        if let task { transport.remove(task) }
    }
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse,
                    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        guard let response = response as? HTTPURLResponse, response.statusCode == 200,
              response.mimeType == "audio/pcm", response.value(forHTTPHeaderField: "X-Audio-Sample-Rate") == "24000" else {
            finish(LokiError.message("流式原声暂不可用，未自动重试或切换声线。"))
            completionHandler(.cancel); return
        }
        completionHandler(.allow)
    }
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        lock.lock()
        guard !finished else { lock.unlock(); return }
        received += data.count; buffered += data.count
        guard received <= 24_000 * 2 * 120 && buffered <= 512_000 else {
            lock.unlock(); dataTask.cancel(); finish(LokiError.message("语音缓冲超过上限，请重新播放。")); return
        }
        if buffered >= 96_000 && !paused {
            paused = true; dataTask.suspend()
        }
        let continuation = self.continuation
        lock.unlock()
        continuation?.yield(data)
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        finish(error)
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}

/// One verified HTTPS connection pool for current and next-sentence downloads.
/// No custom trust handler: iOS certificate verification remains mandatory.
final class PCMTransport: NSObject, URLSessionDataDelegate, @unchecked Sendable {
    static let shared = PCMTransport()
    private let lock = NSLock()
    private var receivers: [Int: PCMDownload] = [:]
    private var session: URLSession!
    init(configuration: URLSessionConfiguration = .ephemeral) {
        super.init()
        let config = configuration
        config.waitsForConnectivity = false; config.urlCache = nil
        config.httpShouldSetCookies = false; config.httpMaximumConnectionsPerHost = 4
        let queue = OperationQueue(); queue.maxConcurrentOperationCount = 1
        queue.qualityOfService = .userInitiated
        session = URLSession(configuration: config, delegate: self, delegateQueue: queue)
    }
    func makeTask(_ request: URLRequest, receiver: PCMDownload) -> URLSessionDataTask {
        let task = session.dataTask(with: request)
        lock.lock(); receivers[task.taskIdentifier] = receiver; lock.unlock()
        return task
    }
    private func receiver(_ task: URLSessionTask) -> PCMDownload? {
        lock.lock(); defer { lock.unlock() }; return receivers[task.taskIdentifier]
    }
    func remove(_ task: URLSessionTask) { lock.lock(); receivers.removeValue(forKey: task.taskIdentifier); lock.unlock() }
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse,
                    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        guard let receiver = receiver(dataTask) else { completionHandler(.cancel); return }
        receiver.urlSession(session, dataTask: dataTask, didReceive: response, completionHandler: completionHandler)
    }
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        receiver(dataTask)?.urlSession(session, dataTask: dataTask, didReceive: data)
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        receiver(task)?.urlSession(session, task: task, didCompleteWithError: error)
        remove(task)
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}
