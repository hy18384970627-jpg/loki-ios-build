import Charts
import HealthKit
import SwiftUI

enum HealthMetric: String, CaseIterable, Identifiable {
    case steps, sleep, heart, hrv
    var id: Self { self }

    var title: String {
        switch self {
        case .steps: "今日步数"
        case .sleep: "最近睡眠"
        case .heart: "最近心率"
        case .hrv: "最近 HRV"
        }
    }

    var icon: String {
        switch self {
        case .steps: "figure.walk"
        case .sleep: "moon.stars"
        case .heart: "heart"
        case .hrv: "waveform.path.ecg"
        }
    }

    var unit: String {
        switch self {
        case .steps: "步"
        case .sleep: "小时"
        case .heart: "次/分"
        case .hrv: "毫秒"
        }
    }

    var trendTitle: String {
        switch self {
        case .steps: "每日步数"
        case .heart: "每日平均心率"
        case .hrv: "每日平均 HRV · SDNN"
        case .sleep: "睡眠详情"
        }
    }
}

struct HealthDay: Identifiable {
    let date: Date
    let value: Double?
    /// Each uninterrupted run of days gets its own line.
    let segment: Int
    var id: Date { date }
}

extension HealthService {
    /// Read-only display query. The existing snapshot and sharing format stay independent.
    func dailyTrend(_ metric: HealthMetric, days: Int) async throws -> [HealthDay] {
        let identifier: HKQuantityTypeIdentifier
        let unit: HKUnit
        let option: HKStatisticsOptions
        switch metric {
        case .steps:
            identifier = .stepCount; unit = .count(); option = .cumulativeSum
        case .heart:
            identifier = .heartRate; unit = HKUnit.count().unitDivided(by: .minute()); option = .discreteAverage
        case .hrv:
            identifier = .heartRateVariabilitySDNN; unit = .secondUnit(with: .milli); option = .discreteAverage
        case .sleep:
            return []
        }
        guard HKHealthStore.isHealthDataAvailable(),
              let type = HKQuantityType.quantityType(forIdentifier: identifier) else { return [] }

        let calendar = Calendar.current
        let now = Date()
        let today = calendar.startOfDay(for: now)
        guard let start = calendar.date(byAdding: .day, value: 1 - days, to: today) else { return [] }
        let predicate = HKQuery.predicateForSamples(withStart: start, end: now, options: .strictStartDate)
        return try await withCheckedThrowingContinuation { continuation in
            let query = HKStatisticsCollectionQuery(quantityType: type, quantitySamplePredicate: predicate,
                options: option, anchorDate: today, intervalComponents: DateComponents(day: 1))
            query.initialResultsHandler = { _, collection, error in
                if let error { continuation.resume(throwing: error); return }
                var entries: [HealthDay] = []
                var segment = 0
                for offset in 0..<days {
                    guard let date = calendar.date(byAdding: .day, value: offset, to: start) else { continue }
                    let statistics = collection?.statistics(for: date)
                    let quantity = option == .cumulativeSum ? statistics?.sumQuantity() : statistics?.averageQuantity()
                    let value = quantity?.doubleValue(for: unit)
                    entries.append(HealthDay(date: date, value: value, segment: segment))
                    if value == nil { segment += 1 }
                }
                continuation.resume(returning: entries)
            }
            store.execute(query)
        }
    }
}

struct HealthTrendView: View {
    @EnvironmentObject private var health: HealthService
    let metric: HealthMetric
    var recent: [HealthDay]? = nil
    var previewEntries: [HealthDay]? = nil
    @State private var days = 7
    @State private var entries: [HealthDay] = []
    @State private var selected: Date?
    @State private var loading = true
    @State private var error: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                LokiEyebrow(title: "LOKI  /  TRENDS")
                Text(metric.trendTitle).font(.system(.largeTitle, design: .serif).weight(.semibold))
                Picker("时间范围", selection: $days) {
                    Text("7 天").tag(7)
                    Text("14 天").tag(14)
                }.pickerStyle(.segmented)
                if loading {
                    ProgressView("读取趋势…").frame(maxWidth: .infinity, minHeight: 220)
                } else if let error {
                    ContentUnavailableView("暂时无法读取", systemImage: "exclamationmark.circle",
                                           description: Text(error))
                } else if entries.contains(where: { $0.value != nil }) {
                    HealthTrendChart(metric: metric, entries: entries, selected: $selected)
                } else {
                    ContentUnavailableView("这段时间暂无记录", systemImage: metric.icon,
                                           description: Text("Apple 健康没有返回这个指标的记录。"))
                }
                Text("按本地日期分组。今天的数据仍在累积，空白日期表示没有读到记录。")
                    .font(.footnote).foregroundStyle(LokiDesign.muted)
            }.padding(LokiDesign.pageInset)
        }
        .background { LokiBackdrop() }
        .foregroundStyle(LokiDesign.ink)
        .navigationTitle("健康趋势")
        .navigationBarTitleDisplayMode(.inline)
        .task(id: days) { await load(useSnapshot: true) }
        .refreshable { await load(useSnapshot: false) }
    }

    private func load(useSnapshot: Bool) async {
        loading = true
        error = nil
        selected = nil
        let range = days
        do {
            let result: [HealthDay]
            if let previewEntries {
                result = Array(previewEntries.suffix(range))
            } else if useSnapshot, range == 7, let recent, entries.isEmpty, !recent.isEmpty {
                result = recent
            } else {
                result = try await health.dailyTrend(metric, days: range)
            }
            guard !Task.isCancelled, range == days else { return }
            entries = result
        } catch {
            guard !Task.isCancelled, range == days else { return }
            self.error = error.localizedDescription
        }
        loading = false
    }
}

private struct HealthTrendChart: View {
    let metric: HealthMetric
    let entries: [HealthDay]
    @Binding var selected: Date?

    private var chosen: HealthDay? {
        guard let selected else { return entries.last(where: { $0.value != nil }) }
        return entries.first { Calendar.current.isDate($0.date, inSameDayAs: selected) }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 13) {
            if let chosen {
                Text(chosen.date, format: .dateTime.month().day()).font(.caption).foregroundStyle(LokiDesign.muted)
                    .accessibilityIdentifier("health-trend-date")
                Text(chosen.value.map { "\($0.formatted(.number.precision(.fractionLength(0...1)))) \(metric.unit)" } ?? "当天暂无记录")
                    .font(.title2.monospacedDigit()).foregroundStyle(LokiDesign.gold)
            }
            Chart {
                ForEach(entries) { day in
                    if let value = day.value {
                        if metric == .steps {
                            BarMark(x: .value("日期", day.date, unit: .day), y: .value(metric.unit, value))
                                .foregroundStyle(LokiDesign.gold)
                        } else {
                            LineMark(x: .value("日期", day.date), y: .value(metric.unit, value),
                                     series: .value("连续区间", day.segment))
                                .foregroundStyle(LokiDesign.gold)
                            PointMark(x: .value("日期", day.date), y: .value(metric.unit, value))
                                .foregroundStyle(LokiDesign.gold)
                        }
                    }
                }
                if selected != nil, let chosen {
                    RuleMark(x: .value("所选日期", chosen.date)).foregroundStyle(LokiDesign.muted.opacity(0.6))
                }
            }
            .chartXScale(domain: domain)
            .chartOverlay { proxy in
                GeometryReader { geometry in
                    Rectangle().fill(.clear).contentShape(Rectangle())
                        .gesture(SpatialTapGesture().onEnded { tap in
                            select(tap.location.x, proxy: proxy, geometry: geometry)
                        })
                        .simultaneousGesture(DragGesture(minimumDistance: 6).onChanged { drag in
                            guard abs(drag.translation.width) >= abs(drag.translation.height) else { return }
                            select(drag.location.x, proxy: proxy, geometry: geometry)
                        })
                }
            }
            .accessibilityIdentifier("health-trend-chart")
            .frame(height: 208)
            .accessibilityLabel(metric.trendTitle)
        }.padding(16).lokiPanel()
    }

    private var domain: ClosedRange<Date> {
        let start = entries.first?.date ?? Date()
        let last = entries.last?.date ?? start
        let end = Calendar.current.date(byAdding: .day, value: 1, to: last) ?? last
        return start...end
    }

    private func select(_ location: CGFloat, proxy: ChartProxy, geometry: GeometryProxy) {
        guard let anchor = proxy.plotFrame else { return }
        let frame = geometry[anchor]
        guard frame.width > 1 else { return }
        let x = min(max(0, location - frame.minX), frame.width - 0.5)
        if let date = proxy.value(atX: x, as: Date.self) {
            selected = Calendar.current.startOfDay(for: date)
        }
    }
}
