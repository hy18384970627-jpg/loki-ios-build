import Charts
import HealthKit
import SwiftUI

enum HealthMetric: String, CaseIterable, Identifiable {
    case steps, sleep, heart, hrv
    var id: Self { self }

    var title: String {
        switch self {
        case .steps: "今日步数"
        case .sleep: "最近睡眠"
        case .heart: "最近心率"
        case .hrv: "最近 HRV"
        }
    }

    var icon: String {
        switch self {
        case .steps: "figure.walk"
        case .sleep: "moon.stars"
        case .heart: "heart"
        case .hrv: "waveform.path.ecg"
        }
    }

    var unit: String {
        switch self {
        case .steps: "步"
        case .sleep: "小时"
        case .heart: "次/分"
        case .hrv: "毫秒"
        }
    }

    var trendTitle: String {
        switch self {
        case .steps: "每日步数"
        case .heart: "当天心率"
        case .hrv: "当天 HRV · SDNN"
        case .sleep: "睡眠详情"
        }
    }

    var usesIntradaySamples: Bool { self == .heart || self == .hrv }
}

struct HealthDay: Identifiable {
    let date: Date
    let value: Double?
    /// Each uninterrupted run of days gets its own line.
    let segment: Int
    var sampleID: UUID? = nil
    var id: ID { ID(date: date, sampleID: sampleID) }

    struct ID: Hashable {
        let date: Date
        let sampleID: UUID?
    }
}

extension HealthService {
    /// Read-only display query. The existing snapshot and sharing format stay independent.
    func intradayTrend(_ metric: HealthMetric, day: Date) async throws -> [HealthDay] {
        let identifier: HKQuantityTypeIdentifier
        let unit: HKUnit
        switch metric {
        case .heart:
            identifier = .heartRate; unit = HKUnit.count().unitDivided(by: .minute())
        case .hrv:
            identifier = .heartRateVariabilitySDNN; unit = .secondUnit(with: .milli)
        case .sleep, .steps: return []
        }
        guard HKHealthStore.isHealthDataAvailable(),
              let type = HKQuantityType.quantityType(forIdentifier: identifier),
              let interval = Calendar.current.dateInterval(of: .day, for: day) else { return [] }
        let predicate = HKQuery.predicateForSamples(withStart: interval.start, end: interval.end,
                                                   options: .strictStartDate)
        return try await withCheckedThrowingContinuation { continuation in
            let query = HKSampleQuery(sampleType: type, predicate: predicate, limit: HKObjectQueryNoLimit,
                                      sortDescriptors: [NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)]) { _, samples, error in
                if let error { continuation.resume(throwing: error); return }
                let points = (samples as? [HKQuantitySample] ?? []).compactMap { sample -> HealthDay? in
                    let value = sample.quantity.doubleValue(for: unit)
                    guard sample.startDate >= interval.start, sample.startDate < interval.end,
                          value.isFinite else { return nil }
                    return HealthDay(date: sample.startDate, value: value, segment: 0, sampleID: sample.uuid)
                }
                continuation.resume(returning: points)
            }
            store.execute(query)
        }
    }

    func dailySteps(days: Int) async throws -> [HealthDay] {
        guard HKHealthStore.isHealthDataAvailable(),
              let type = HKQuantityType.quantityType(forIdentifier: .stepCount) else { return [] }

        let calendar = Calendar.current
        let now = Date()
        let today = calendar.startOfDay(for: now)
        guard let start = calendar.date(byAdding: .day, value: 1 - days, to: today) else { return [] }
        let predicate = HKQuery.predicateForSamples(withStart: start, end: now, options: .strictStartDate)
        return try await withCheckedThrowingContinuation { continuation in
            let query = HKStatisticsCollectionQuery(quantityType: type, quantitySamplePredicate: predicate,
                options: .cumulativeSum, anchorDate: today, intervalComponents: DateComponents(day: 1))
            query.initialResultsHandler = { _, collection, error in
                if let error { continuation.resume(throwing: error); return }
                var entries: [HealthDay] = []
                var segment = 0
                for offset in 0..<days {
                    guard let date = calendar.date(byAdding: .day, value: offset, to: start) else { continue }
                    let statistics = collection?.statistics(for: date)
                    let value = statistics?.sumQuantity()?.doubleValue(for: .count())
                    entries.append(HealthDay(date: date, value: value, segment: segment))
                    if value == nil { segment += 1 }
                }
                continuation.resume(returning: entries)
            }
            store.execute(query)
        }
    }
}

struct HealthTrendView: View {
    @EnvironmentObject private var health: HealthService
    let metric: HealthMetric
    var recent: [HealthDay]? = nil
    var previewEntries: [HealthDay]? = nil
    @State private var days = 7
    @State private var day = Calendar.current.startOfDay(for: .now)
    @State private var entries: [HealthDay] = []
    @State private var selected: Date?
    @State private var loading = true
    @State private var error: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                LokiEyebrow(title: "LOKI  /  TRENDS")
                Text(metric.trendTitle).font(.system(.largeTitle, design: .serif).weight(.semibold))
                if metric.usesIntradaySamples {
                    DatePicker("查看日期", selection: $day, in: ...Date.now, displayedComponents: .date)
                } else {
                    Picker("时间范围", selection: $days) {
                        Text("7 天").tag(7)
                        Text("14 天").tag(14)
                    }.pickerStyle(.segmented)
                }
                if loading {
                    ProgressView("读取趋势…").frame(maxWidth: .infinity, minHeight: 220)
                } else if let error {
                    ContentUnavailableView("暂时无法读取", systemImage: "exclamationmark.circle",
                                           description: Text(error))
                } else if entries.contains(where: { $0.value != nil }) {
                    HealthTrendChart(metric: metric, entries: entries, day: day, selected: $selected)
                } else {
                    ContentUnavailableView("这段时间暂无记录", systemImage: metric.icon,
                                           description: Text("Apple 健康没有返回这个指标的记录。"))
                }
                Text(metric.usesIntradaySamples ? "每个点对应一次实测记录。点按或拖动查看采样时间。"
                     : "按本地日期分组。今天的数据仍在累积，空白日期表示没有读到记录。")
                    .font(.footnote).foregroundStyle(LokiDesign.muted)
            }.padding(LokiDesign.pageInset)
        }
        .background { LokiBackdrop() }
        .foregroundStyle(LokiDesign.ink)
        .navigationTitle("健康趋势")
        .navigationBarTitleDisplayMode(.inline)
        .task(id: days) { if !metric.usesIntradaySamples { await load(useSnapshot: true) } }
        .task(id: day) { if metric.usesIntradaySamples { await load(useSnapshot: false) } }
        .refreshable { await load(useSnapshot: false) }
    }

    private func load(useSnapshot: Bool) async {
        loading = true
        error = nil
        selected = nil
        let range = days
        let date = day
        do {
            let result: [HealthDay]
            if metric.usesIntradaySamples {
                if let previewEntries {
                    result = previewEntries.filter { Calendar.current.isDate($0.date, inSameDayAs: date) }
                } else {
                    result = try await health.intradayTrend(metric, day: date)
                }
            } else if let previewEntries {
                result = Array(previewEntries.suffix(range))
            } else if useSnapshot, range == 7, let recent, entries.isEmpty, !recent.isEmpty {
                result = recent
            } else {
                result = try await health.dailySteps(days: range)
            }
            guard !Task.isCancelled, range == days, date == day else { return }
            entries = result
        } catch {
            guard !Task.isCancelled, range == days, date == day else { return }
            self.error = error.localizedDescription
        }
        loading = false
    }
}

private struct HealthTrendChart: View {
    let metric: HealthMetric
    let entries: [HealthDay]
    let day: Date
    @Binding var selected: Date?

    private var chosen: HealthDay? {
        guard let selected else { return entries.last(where: { $0.value != nil }) }
        if metric.usesIntradaySamples {
            return entries.min { abs($0.date.timeIntervalSince(selected)) < abs($1.date.timeIntervalSince(selected)) }
        }
        return entries.first { Calendar.current.isDate($0.date, inSameDayAs: selected) }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 13) {
            if let chosen {
                Text(chosen.date, format: metric.usesIntradaySamples ? .dateTime.hour().minute() : .dateTime.month().day())
                    .font(.caption).foregroundStyle(LokiDesign.muted)
                    .accessibilityIdentifier("health-trend-date")
                Text(chosen.value.map { "\($0.formatted(.number.precision(.fractionLength(0...1)))) \(metric.unit)" } ?? "当天暂无记录")
                    .font(.title2.monospacedDigit()).foregroundStyle(LokiDesign.gold)
            }
            Chart {
                ForEach(entries) { day in
                    if let value = day.value {
                        if metric == .steps {
                            BarMark(x: .value("日期", day.date, unit: .day), y: .value(metric.unit, value))
                                .foregroundStyle(LokiDesign.gold)
                        } else {
                            LineMark(x: .value("采样时间", day.date), y: .value(metric.unit, value),
                                     series: .value("连续区间", day.segment))
                                .foregroundStyle(LokiDesign.gold)
                            PointMark(x: .value("采样时间", day.date), y: .value(metric.unit, value))
                                .foregroundStyle(LokiDesign.gold)
                        }
                    }
                }
                if selected != nil, let chosen {
                    RuleMark(x: .value("所选日期", chosen.date)).foregroundStyle(LokiDesign.muted.opacity(0.6))
                }
            }
            .chartXScale(domain: domain)
            .chartXAxis {
                if metric.usesIntradaySamples {
                    AxisMarks(values: .stride(by: .hour, count: 6)) { _ in
                        AxisGridLine()
                        AxisTick()
                        AxisValueLabel(format: .dateTime.hour())
                    }
                } else {
                    AxisMarks()
                }
            }
            .chartOverlay { proxy in
                GeometryReader { geometry in
                    Rectangle().fill(.clear).contentShape(Rectangle())
                        .gesture(SpatialTapGesture().onEnded { tap in
                            select(tap.location.x, proxy: proxy, geometry: geometry)
                        })
                        .simultaneousGesture(DragGesture(minimumDistance: 6).onChanged { drag in
                            guard abs(drag.translation.width) >= abs(drag.translation.height) else { return }
                            select(drag.location.x, proxy: proxy, geometry: geometry)
                        })
                }
            }
            .accessibilityIdentifier("health-trend-chart")
            .frame(height: 208)
            .accessibilityLabel(metric.trendTitle)
        }.padding(16).lokiPanel()
    }

    private var domain: ClosedRange<Date> {
        if metric.usesIntradaySamples, let interval = Calendar.current.dateInterval(of: .day, for: day) {
            return interval.start...interval.end
        }
        let start = entries.first?.date ?? Date()
        let last = entries.last?.date ?? start
        let end = Calendar.current.date(byAdding: .day, value: 1, to: last) ?? last
        return start...end
    }

    private func select(_ location: CGFloat, proxy: ChartProxy, geometry: GeometryProxy) {
        guard let anchor = proxy.plotFrame else { return }
        let frame = geometry[anchor]
        guard frame.width > 1 else { return }
        let x = min(max(0, location - frame.minX), frame.width - 0.5)
        if let date = proxy.value(atX: x, as: Date.self) {
            selected = metric.usesIntradaySamples ? date : Calendar.current.startOfDay(for: date)
        }
    }
}
