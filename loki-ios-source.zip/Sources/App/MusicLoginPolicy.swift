import Foundation

enum MusicLoginPolicy {
    // Official desktop home exposes window.login; the mobile landing page can
    // instead advertise the native app without displaying a web login control.
    static let desktopAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"
    static let openLoginScript = """
    (() => {
      if (location.protocol !== 'https:' || location.hostname !== 'music.163.com') return false;
      if (typeof window.login === 'function') { window.login(); return true; }
      const link = Array.from(document.querySelectorAll('a[data-action="login"]'))
        .find(element => element.getClientRects().length > 0);
      if (link) { link.click(); return true; }
      return false;
    })()
    """
    static func approvedCookies(_ cookies: [HTTPCookie]) -> [HTTPCookie] {
        cookies.filter {
            let domain = $0.domain.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "."))
            return (domain == "163.com" || domain == "music.163.com" || domain.hasSuffix(".music.163.com"))
                && ["MUSIC_U", "MUSIC_A", "__csrf", "NMTID"].contains($0.name)
                && !$0.value.contains("\r") && !$0.value.contains("\n")
                && ($0.expiresDate == nil || $0.expiresDate! > Date())
        }
    }
}
