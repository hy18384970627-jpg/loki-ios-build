import AVFoundation
import SwiftUI

/// The view owns only rendering state. Playback and interruption handling stay with VoiceService.
struct LokiVoiceNote: View {
    let clip: RecordedVoice
    let isPlaying: Bool
    let preview: Bool
    let playbackFraction: () -> Double?
    let replay: () -> Void
    @State private var waveform: [CGFloat] = []

    var body: some View {
        Button(action: replay) {
            HStack(spacing: 9) {
                Image(systemName: isPlaying ? "stop.fill" : "play.fill")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(LokiDesign.ground)
                    .frame(width: 26, height: 26)
                    .background(LokiDesign.gold, in: Circle())
                TimelineView(.animation(minimumInterval: 1.0 / 15, paused: !isPlaying)) { _ in
                    waveformView(fraction: isPlaying ? playbackFraction() ?? 0 : 0)
                }
                Text("\(Int(ceil(clip.duration)))″").font(.caption.monospacedDigit())
                    .foregroundStyle(LokiDesign.ink)
            }.frame(minHeight: 32).contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(isPlaying ? "停止播放" : "播放原始语音消息")
        .accessibilityValue("\(Int(ceil(clip.duration))) 秒")
        .task(id: clip.id) {
            if preview {
                waveform = [0.22, 0.38, 0.66, 0.88, 0.51, 0.36, 0.73, 0.95, 0.65, 0.39, 0.58,
                            0.83, 0.65, 0.42, 0.31, 0.76, 0.89, 0.60, 0.31, 0.49, 0.29, 0.22]
                return
            }
            waveform = []
            guard let url = try? clip.url else { return }
            let work = Task.detached(priority: .utility) { VoiceWaveform.read(url, count: 22) }
            let peaks = await withTaskCancellationHandler {
                await work.value
            } onCancel: {
                work.cancel()
            }
            guard !Task.isCancelled else { return }
            waveform = peaks
        }
    }

    private func waveformView(fraction: Double) -> some View {
        Canvas { context, size in
            if waveform.isEmpty {
                let track = CGRect(x: 0, y: size.height / 2 - 1, width: size.width, height: 2)
                context.fill(Path(roundedRect: track, cornerRadius: 1), with: .color(LokiDesign.muted))
                if fraction > 0 {
                    let progress = CGRect(x: track.minX, y: track.minY, width: track.width * fraction, height: track.height)
                    context.fill(Path(roundedRect: progress, cornerRadius: 1), with: .color(LokiDesign.gold))
                }
                return
            }
            let step = size.width / CGFloat(waveform.count)
            for (index, peak) in waveform.enumerated() {
                let height = max(3, peak * size.height)
                let rect = CGRect(x: CGFloat(index) * step, y: (size.height - height) / 2,
                                  width: step * 0.56, height: height)
                let played = Double(index + 1) / Double(waveform.count) <= fraction
                context.fill(Path(roundedRect: rect, cornerRadius: step * 0.28),
                             with: .color(played ? LokiDesign.gold : LokiDesign.muted))
            }
        }.frame(width: 80, height: 21).accessibilityHidden(true)
    }
}

private enum VoiceWaveform {
    static func read(_ url: URL, count: Int) -> [CGFloat] {
        guard let file = try? AVAudioFile(forReading: url),
              file.length > 0, file.processingFormat.sampleRate > 0,
              Double(file.length) <= file.processingFormat.sampleRate * 91,
              let buffer = AVAudioPCMBuffer(pcmFormat: file.processingFormat, frameCapacity: 8192) else { return [] }
        var peaks = Array(repeating: Float(0), count: count)
        do {
            while file.framePosition < file.length && !Task.isCancelled {
                let offset = file.framePosition
                try file.read(into: buffer)
                guard buffer.frameLength > 0, let channel = buffer.floatChannelData?[0] else { break }
                for index in 0..<Int(buffer.frameLength) {
                    let bin = min(count - 1, Int((offset + Int64(index)) * Int64(count) / file.length))
                    peaks[bin] = max(peaks[bin], abs(channel[index]))
                }
            }
        } catch { return [] }
        let maximum = peaks.max() ?? 0
        guard maximum > 0 else { return [] }
        return peaks.map { CGFloat(sqrt($0 / maximum)) }
    }
}
