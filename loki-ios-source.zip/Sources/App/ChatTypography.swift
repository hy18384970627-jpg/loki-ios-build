import SwiftUI

enum ChatTypography {
    static let owner = Font.custom("LXGWWenKaiGBLite-Regular", size: 18, relativeTo: .body)
    static func loki(_ text: String) -> AttributedString {
        var value = AttributedString(text)
        value.font = .custom("LXGWNeoZhiSong", size: 18, relativeTo: .body)
        var start: AttributedString.Index?
        var ranges: [Range<AttributedString.Index>] = []
        for index in value.characters.indices {
            let latin = value.characters[index].unicodeScalars.allSatisfy { (0x20...0x7e).contains($0.value) }
            if latin {
                if start == nil { start = index }
            } else if let lower = start { ranges.append(lower..<index); start = nil }
        }
        if let start { ranges.append(start..<value.endIndex) }
        for range in ranges { value[range].font = .custom("CormorantGaramond-SemiBold", size: 22, relativeTo: .body) }
        return value
    }
}
