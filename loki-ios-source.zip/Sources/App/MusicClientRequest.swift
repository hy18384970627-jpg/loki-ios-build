import Foundation

enum MusicClientRequest {
    static let apiPath = "/api/song/enhance/player/url/v1"
    static let endpoint = URL(string: "https://interface.music.163.com/eapi/song/enhance/player/url/v1")!
    static func header(cookie: String, requestID: String) -> [String: String] {
        let pairs = cookie.split(separator: ";").compactMap { part -> (String, String)? in
            let pair = part.trimmingCharacters(in: .whitespaces).split(separator: "=", maxSplits: 1)
            guard pair.count == 2 else { return nil }
            return (String(pair[0]), String(pair[1]))
        }
        let parsed = Dictionary(pairs, uniquingKeysWith: { _, value in value })
        var result = ["os": "iPhone OS", "appver": "9.0.90", "osver": "16.2", "versioncode": "140",
                      "channel": "distribution", "__csrf": parsed["__csrf"] ?? "", "requestId": requestID]
        for name in ["MUSIC_U", "MUSIC_A"] {
            if let value = parsed[name], !value.isEmpty { result[name] = value }
        }
        return result
    }
}
