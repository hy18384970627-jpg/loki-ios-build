import Foundation

struct HoldRecordingState {
    private(set) var token: UUID?
    private(set) var cancelling = false
    var active: Bool { token != nil }
    mutating func begin() -> UUID? {
        guard token == nil else { return nil }
        let value = UUID(); token = value; cancelling = false; return value
    }
    mutating func move(vertical: Double) { if active { cancelling = vertical <= -65 } }
    mutating func finish() -> Bool? {
        guard active else { return nil }
        let send = !cancelling; token = nil; cancelling = false; return send
    }
    mutating func cancel() { token = nil; cancelling = false }
}
