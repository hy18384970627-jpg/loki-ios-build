import SwiftUI

struct SleepDetailsView: View {
    let details: SleepDetails
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("睡眠阶段与清醒记录").font(.headline)
            Text("\(details.startAt.formatted()) — \(details.endAt.formatted())").font(.caption).foregroundStyle(.secondary)
            SleepStageTimelineView(details: details)
            ForEach(SleepDetails.stageOrder, id: \.self) { stage in
                let periods = details.periods.filter { $0.stage == stage }
                if !periods.isEmpty {
                    DisclosureGroup {
                        ForEach(periods) { period in
                            VStack(alignment: .leading, spacing: 3) {
                                Text("\(period.startAt.formatted(.dateTime.month().day().hour().minute())) — \(period.endAt.formatted(.dateTime.month().day().hour().minute()))")
                                Text(duration(period.duration)).foregroundStyle(.secondary)
                            }.font(.caption).padding(.vertical, 3)
                        }
                    } label: {
                        HStack {
                            Circle().fill(SleepStageTimelineView.color(stage)).frame(width: 9, height: 9)
                            Text("\(SleepDetails.title(stage)) · \(periods.count) 段")
                            Spacer(); Text(duration(periods.reduce(0) { $0 + $1.duration })).font(.caption).foregroundStyle(.secondary)
                        }.font(.subheadline)
                    }
                }
            }
            if let awake = details.followingAwake {
                Text("睡眠结束后的清醒记录：\(awake.startAt.formatted(.dateTime.hour().minute())) — \(awake.endAt.formatted(.dateTime.hour().minute()))")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Text("清醒次数只统计健康中明确记录的清醒段；空白和冲突不算清醒。阶段是设备记录，不能据此判断你现在是否醒着。").font(.caption2).foregroundStyle(.secondary)
        }.padding(.vertical, 4)
    }
    private func duration(_ seconds: TimeInterval) -> String {
        let formatter = DateComponentsFormatter(); formatter.allowedUnits = [.hour, .minute]; formatter.unitsStyle = .abbreviated
        return formatter.string(from: seconds) ?? "不足 1 分钟"
    }
}

struct SleepStageTimelineView: View {
    let details: SleepDetails
    @State private var selection: SleepStagePeriod?
    private let stages = ["awake", "rem", "core", "deep"]

    private var rows: [String] {
        details.periods.contains { !stages.contains($0.stage) } ? stages + ["other"] : stages
    }

    private var duration: TimeInterval { details.endAt.timeIntervalSince(details.startAt) }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 7) {
                VStack(alignment: .leading, spacing: 0) {
                    ForEach(rows, id: \.self) { stage in
                        Text(label(stage)).font(.caption2).foregroundStyle(LokiDesign.muted)
                            .frame(height: 24, alignment: .center)
                    }
                }.accessibilityHidden(true)
                GeometryReader { geometry in
                    Canvas { context, size in draw(context, size: size) }
                        .overlay {
                            Rectangle().fill(.clear).contentShape(Rectangle())
                                .gesture(SpatialTapGesture().onEnded { tap in
                                    select(tap.location.x, width: geometry.size.width)
                                })
                                .simultaneousGesture(DragGesture(minimumDistance: 6).onChanged { drag in
                                    guard abs(drag.translation.width) >= abs(drag.translation.height) else { return }
                                    select(drag.location.x, width: geometry.size.width)
                                })
                        }
                }
                .accessibilityElement(children: .ignore)
                .accessibilityIdentifier("sleep-stage-plot")
                .accessibilityLabel("睡眠分期时间轴")
                .accessibilityHint("点按或左右拖动查看记录")
                .accessibilityAdjustableAction { direction in
                    let periods = details.periods
                    guard !periods.isEmpty else { return }
                    let index = selection.flatMap { current in periods.firstIndex { $0.id == current.id } }
                    switch direction {
                    case .increment: selection = periods[min((index ?? -1) + 1, periods.count - 1)]
                    case .decrement: selection = periods[max((index ?? 1) - 1, 0)]
                    @unknown default: break
                    }
                }
            }.frame(height: CGFloat(rows.count) * 24)
            HStack {
                Text(details.startAt, style: .time)
                Spacer()
                Text(details.endAt, style: .time)
            }.font(.caption2.monospacedDigit()).foregroundStyle(LokiDesign.muted)
            Text(selection.map { "\(SleepDetails.title($0.stage))   \(timeRange($0))" }
                 ?? "点按或拖动时间轴查看每段的起止时间")
                .font(.footnote.monospacedDigit())
                .foregroundStyle(selection.map { Self.color($0.stage) } ?? LokiDesign.muted)
                .accessibilityIdentifier("sleep-stage-readout")
        }
        .onChange(of: details.startAt) { _, _ in selection = nil }
        .onChange(of: details.periods.map(\.id)) { _, ids in
            if let selection, !ids.contains(selection.id) { self.selection = nil }
        }
    }

    private func select(_ x: CGFloat, width: CGFloat) {
        guard width > 0, duration > 0 else { return }
        let fraction = min(max(0, Double(x / width)), 0.999999)
        let time = details.startAt.addingTimeInterval(fraction * duration)
        selection = details.periods.first { $0.startAt <= time && time < $0.endAt }
    }

    private func label(_ stage: String) -> String {
        ["awake": "清醒", "rem": "REM", "core": "核心", "deep": "深睡", "other": "其他"][stage] ?? stage
    }

    private func timeRange(_ period: SleepStagePeriod) -> String {
        let format = Date.FormatStyle.dateTime.hour().minute()
        return "\(period.startAt.formatted(format)) – \(period.endAt.formatted(format))"
    }

    private func draw(_ context: GraphicsContext, size: CGSize) {
        guard duration > 0 else { return }
        let rowHeight = size.height / CGFloat(rows.count)
        func x(_ date: Date) -> CGFloat {
            CGFloat(date.timeIntervalSince(details.startAt) / duration) * size.width
        }
        func lane(_ stage: String) -> Int { stages.firstIndex(of: stage) ?? stages.count }
        var guides = Path()
        for row in 0...rows.count {
            let y = min(size.height - 0.5, CGFloat(row) * rowHeight + 0.5)
            guides.move(to: CGPoint(x: 0, y: y)); guides.addLine(to: CGPoint(x: size.width, y: y))
        }
        context.stroke(guides, with: .color(LokiDesign.line), lineWidth: 1)
        var previous: SleepStagePeriod?
        for period in details.periods {
            let y = CGFloat(lane(period.stage)) * rowHeight
            if let previous, stages.contains(previous.stage), stages.contains(period.stage), previous.endAt == period.startAt {
                let connector = CGRect(x: x(period.startAt) - 1, y: min(y, CGFloat(lane(previous.stage)) * rowHeight) + rowHeight / 2,
                                       width: 2, height: abs(y - CGFloat(lane(previous.stage)) * rowHeight))
                context.fill(Path(connector), with: .color(LokiDesign.muted.opacity(0.36)))
            }
            let segment = CGRect(x: x(period.startAt), y: y + 4, width: max(1, x(period.endAt) - x(period.startAt)),
                                 height: max(1, rowHeight - 8))
            let path = Path(roundedRect: segment, cornerRadius: 4)
            let selected = selection?.id == period.id
            context.fill(path, with: .color(Self.color(period.stage).opacity(selection == nil || selected ? 1 : 0.44)))
            if selected {
                context.stroke(path, with: .color(LokiDesign.ink), lineWidth: 1.3)
                let cursor = segment.midX
                context.fill(Path(CGRect(x: cursor - 0.5, y: 0, width: 1, height: size.height)),
                             with: .color(LokiDesign.ink.opacity(0.45)))
            }
            previous = period
        }
    }

    static func color(_ stage: String) -> Color {
        switch stage {
        case "deep": Color(red: 0.21, green: 0.44, blue: 0.39)
        case "core": Color(red: 0.42, green: 0.66, blue: 0.55)
        case "rem": Color(red: 0.72, green: 0.79, blue: 0.67)
        case "awake": LokiDesign.gold
        case "unspecified": Color(red: 0.35, green: 0.50, blue: 0.45)
        case "conflicting": LokiDesign.danger
        default: LokiDesign.raised
        }
    }
}
