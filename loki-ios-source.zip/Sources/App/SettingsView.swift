import SwiftUI
import AVFoundation

struct SettingsView: View {
    @EnvironmentObject private var app: AppState
    @EnvironmentObject private var notifications: NotificationService
    @EnvironmentObject private var device: DeviceTools
    @AppStorage("gatewayURL") private var gatewayURL = ""
    @AppStorage("chatLock") private var chatLock = true
    @AppStorage("autoVoice") private var autoVoice = true
    @AppStorage("autoWallpaper") private var autoWallpaper = true
    @State private var token = ""
    @State private var showDisconnect = false
    @State private var scanning = false
    @State private var scannedCode: PairingCode?
    @State private var connecting = false
    var body: some View {
        NavigationStack {
            Form {
                Section("连接现有 Loki") {
                    Button("扫描电脑上的配对二维码", systemImage: "qrcode.viewfinder") {
                        Task {
                            if await AVCaptureDevice.requestAccess(for: .video) { scanning = true }
                            else { app.notice = "请在系统设置中允许 Loki 使用相机后再扫描。" }
                        }
                    }
                        .disabled(connecting)
                    TextField("https://你的私人入口", text: $gatewayURL)
                        .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                    SecureField("新配对令牌（不是模型 API Key）", text: $token)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    Button("保存配对并检查连接") {
                        Task {
                            do { if !token.isEmpty { try SecureToken.save(token); token = "" }; await app.checkConnection() }
                            catch { app.tell(error) }
                        }
                    }
                    if let status = app.status {
                        LabeledContent("聊天", value: status.chat_enabled ? "接口已启用" : "待接入")
                        LabeledContent("原记忆写回", value: status.canonical_writeback ? "已启用" : "未启用")
                        LabeledContent("模型主动调用手机工具", value: status.automatic_model_tools ? "已启用" : "待接入")
                        LabeledContent("服务器主动推送", value: status.remote_push_active ? "已启用" : "待配置")
                    }
                    Text("模型密钥留在电脑。手机只保存私人接口的配对令牌，存入本机钥匙串。入口必须使用有效证书的 HTTPS。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("提醒与隐私") {
                    Toggle("回复后自动播放 Loki 原声", isOn: $autoVoice)
                    Toggle("让 Loki 自己挑选聊天背景", isOn: $autoWallpaper)
                    Toggle("进入 App 时验证身份", isOn: Binding(get: { chatLock }, set: { value in
                        Task {
                            do { try await device.unlock(); chatLock = value; app.unlocked = true }
                            catch { app.tell(error) }
                        }
                    }))
                    Button("授权通知并登记此设备") {
                        Task {
                            do {
                                try await notifications.register(api: app.api)
                                await app.checkConnection()
                                app.notice = app.status?.remote_push_active == true ? "这台手机已登记，锁屏推送已配置。" : "这台手机已登记；等待服务器 APNs 密钥配置。"
                            } catch { app.tell(error) }
                        }
                    }
                    Text("本地定时提醒无需服务器。动态主动消息需要现有电脑后端在线、网络可达和 APNs 签名配置。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("开发版本") {
                    NavigationLink("手机聊天与任务记录") { RecordsView() }
                    LabeledContent("目标系统", value: "iOS 26+")
                    LabeledContent("安装方式", value: "开发签名 · 自用")
                    Text("个人开发版本。健康、提醒和应用限制需要分别授权；应用限制还需启用对应能力的开发签名。")
                        .font(.caption).foregroundStyle(.secondary)
                    Button("取消手机配对", role: .destructive) { showDisconnect = true }
                }
            }.navigationTitle("设置")
                .sheet(isPresented: $scanning) {
                    PairingScanView(found: { value in
                        do { scannedCode = try PairingCode.decode(value) }
                        catch { app.tell(error) }
                    }, failed: { app.notice = $0 })
                }
                .confirmationDialog("连接扫描到的 Loki？", isPresented: Binding(
                    get: { scannedCode != nil && !scanning },
                    set: { if !$0 { scannedCode = nil } })) {
                    if let code = scannedCode {
                        Button("确认连接") {
                            connecting = true
                            Task {
                                defer { connecting = false }
                                do {
                                    let status = try await MobileAPI(base: code.url, token: code.token).status()
                                    guard status.ready else { throw LokiError.message("接口尚未就绪。") }
                                    try SecureToken.save(code.token)
                                    gatewayURL = code.url; app.status = status
                                    app.notice = status.chat_enabled ? "已连接现有 Loki，可以开始聊天。" : "配对成功；聊天接口尚未启用。"
                                } catch { app.tell(error) }
                            }
                        }
                    }
                    Button("取消", role: .cancel) { scannedCode = nil }
                } message: {
                    Text(scannedCode?.url ?? "")
                }
                .confirmationDialog("取消手机与私人接口的配对？本机记录将保留。", isPresented: $showDisconnect) {
                    Button("取消配对", role: .destructive) {
                        do { try SecureToken.save(""); gatewayURL = ""; app.status = nil } catch { app.tell(error) }
                    }
                }
        }
    }
}

struct RecordsView: View {
    @EnvironmentObject private var app: AppState
    @State private var share = false
    var body: some View {
        NavigationStack {
            List {
                Section("手机记录与原有记忆") {
                    Text("这里是这台 iPhone 的聊天和任务记录。接入现有适配器后，回答可以读取 Loki 的既有记忆；手机新对话写回原记忆库尚未启用。")
                        .font(.caption).foregroundStyle(.secondary)
                    LabeledContent("本机消息", value: "\(app.messages.count)")
                    LabeledContent("本机任务", value: "\(app.tasks.count)")
                    Button("导出本机聊天文字", systemImage: "square.and.arrow.up") { share = true }.disabled(app.messages.isEmpty)
                }
                ForEach(app.messages.suffix(30)) { item in
                    VStack(alignment: .leading, spacing: 8) {
                        Text("\(item.role == "user" ? "你" : "Loki") · \(item.date.formatted())").font(.caption).foregroundStyle(.secondary)
                        Text(item.displayText).lineLimit(5)
                    }
                }
            }.navigationTitle("手机记录")
                .sheet(isPresented: $share) {
                    ShareSheet(items: [app.messages.map { "[\($0.date.formatted())] \($0.role)\n\($0.displayText)" }.joined(separator: "\n\n")])
                }
        }
    }
}

struct CapabilitiesView: View {
    var body: some View {
        List {
            Section("已编写原生实现 · 待真机验证") {
                Text("健康：心率、HRV、今日步数、最近睡眠片段")
                Text("提醒：本地通知、系统闹钟、到点计时")
                Text("应用限制：个人授权、手选应用、到期解除、随时手动解除")
                Text("使用时长：系统独立沙盒中的今日总时长报告，不上传模型")
                Text("生活：日历、提醒事项、任务文字与照片、前台定位、附近搜索")
                Text("设备：电池、存储、网络类型、亮度、系统音量控件、手电筒、震动、分享与粘贴")
                Text("聊天：文本和照片、按键语音输入、既有 Breeze 播放、Face ID／设备密码保护")
            }
            Section("还需要后台接入") {
                Text("动态主动推送、现有 HRV 事件关心、手机对话写回共享记忆")
                Text("模型自动发起手机工具请求：已有队列与逐次确认接口，现有模型尚未接入")
                Text("连续双向语音通话、锁屏实时倒计时")
            }
            Section("iOS 没有向普通 App 开放") {
                Text("读取其他 App 的所有通知、系统短信库、SIM 详细标识")
                Text("读取其他 App 的界面树、任意跨 App 点击或输入、静默截取其他 App")
                Text("长期保持任意后台运行、静默在后台开相机、强制永久锁住应用")
                Text("未经用户操作替换壁纸、从任意 App 扫描全部私有文件")
            }
        }.navigationTitle("功能边界")
    }
}
