import Foundation
import CoreLocation

struct LocalWeather {
    let fetchedAt: Date
    let location: CLLocation
    let payload: [String: Any]
    private struct Response: Decodable {
        struct Current: Decodable { let temperature_2m: Double?; let apparent_temperature: Double?; let weather_code: Int? }
        struct Daily: Decodable {
            let time: [Double]
            let temperature_2m_max: [Double?]
            let temperature_2m_min: [Double?]
            let precipitation_probability_max: [Double?]
        }
        let current: Current
        let daily: Daily
        let utc_offset_seconds: Int
    }
    private static let session = URLSession(configuration: .ephemeral, delegate: WeatherNoRedirect(), delegateQueue: nil)
    static func fetch(at location: CLLocation) async throws -> Self {
        // Weather needs a grid cell, not the owner's precise GPS position.
        let lat = (location.coordinate.latitude * 100).rounded() / 100
        let lon = (location.coordinate.longitude * 100).rounded() / 100
        var url = URLComponents(string: "https://api.open-meteo.com/v1/forecast")!
        url.queryItems = ["latitude": String(lat), "longitude": String(lon),
            "current": "temperature_2m,apparent_temperature,weather_code",
            "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max",
            "past_days": "1", "forecast_days": "2", "timezone": "auto", "timeformat": "unixtime"]
            .map { URLQueryItem(name: $0.key, value: $0.value) }
        let (data, response) = try await session.data(for: URLRequest(url: url.url!, timeoutInterval: 12))
        guard (response as? HTTPURLResponse)?.statusCode == 200, data.count < 500_000 else { throw LokiError.message("天气服务暂时不可用。") }
        let value = try JSONDecoder().decode(Response.self, from: data)
        let formatter = DateFormatter(); formatter.calendar = Calendar(identifier: .gregorian)
        formatter.locale = Locale(identifier: "en_US_POSIX"); formatter.timeZone = TimeZone(secondsFromGMT: value.utc_offset_seconds)
        formatter.dateFormat = "yyyy-MM-dd"
        let now = Date(), day = formatter.string(from: now)
        guard let today = value.daily.time.firstIndex(where: { formatter.string(from: Date(timeIntervalSince1970: $0)) == day }) else {
            throw LokiError.message("天气日期与当地日期不一致。")
        }
        var result: [String: Any] = ["provider": "Open-Meteo", "fetched_at": now.timeIntervalSince1970,
            "local_day": day, "source_kind": "weather_model_and_forecast", "location_precision": "approximately_1km_grid"]
        func add(_ key: String, _ number: Double?) { if let number, number.isFinite { result[key] = number } }
        add("current_c", value.current.temperature_2m); add("apparent_c", value.current.apparent_temperature)
        if let code = value.current.weather_code { result["weather_code"] = code }
        func at(_ list: [Double?], _ index: Int) -> Double? { list.indices.contains(index) ? list[index] : nil }
        add("high_c", at(value.daily.temperature_2m_max, today)); add("low_c", at(value.daily.temperature_2m_min, today))
        add("yesterday_high_c", at(value.daily.temperature_2m_max, today - 1)); add("yesterday_low_c", at(value.daily.temperature_2m_min, today - 1))
        add("rain_probability", at(value.daily.precipitation_probability_max, today))
        return .init(fetchedAt: now, location: location, payload: result)
    }
}
private final class WeatherNoRedirect: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}
