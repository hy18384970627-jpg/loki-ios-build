import Foundation

struct CallPresentation {
    private(set) var active = false
    private(set) var minimized = false
    private(set) var identifier: UUID?
    mutating func begin() { guard !active else { return }; active = true; minimized = false; identifier = UUID() }
    mutating func minimize() { if active { minimized = true } }
    mutating func restore() { if active { minimized = false } }
    mutating func end() { active = false; minimized = false; identifier = nil }
}
