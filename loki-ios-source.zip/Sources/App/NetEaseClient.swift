import Foundation
import Security

enum MusicCredential {
    private static let service = "dev.zcydrkv7yh.loki.music"
    static func read() -> String {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service, kSecAttrAccount as String: "netease",
            kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data else { return "" }
        return String(data: data, encoding: .utf8) ?? ""
    }
    static func save(_ cookie: String) throws {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service, kSecAttrAccount as String: "netease"]
        if cookie.isEmpty { SecItemDelete(query as CFDictionary); return }
        let value: [String: Any] = [kSecValueData as String: Data(cookie.utf8),
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]
        let status = SecItemUpdate(query as CFDictionary, value as CFDictionary)
        if status == errSecItemNotFound {
            guard SecItemAdd(query.merging(value) { _, b in b } as CFDictionary, nil) == errSecSuccess else {
                throw LokiError.message("无法保存音乐授权。")
            }
        } else if status != errSecSuccess { throw LokiError.message("无法更新音乐授权。") }
    }
}

/// Reuses Vael-KY's account endpoint/CSRF behavior on the phone, without its HTTP server.
actor NetEaseClient {
    private var sourceAttempts: [[String: String]] = []
    func sourceTrace() -> [[String: String]] { sourceAttempts }
    private let session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.httpShouldSetCookies = false; config.urlCache = nil
        return URLSession(configuration: config, delegate: MusicNoRedirect(), delegateQueue: nil)
    }()
    private func request(_ path: String, query: [String: String] = [:], payload: [String: Any]? = nil, audioClient: Bool = false) async throws -> [String: Any] {
        let cookie = MusicCredential.read()
        guard !cookie.isEmpty else { throw LokiError.message("请先连接网易云账号。") }
        let csrf = cookie.split(separator: ";").compactMap { part -> String? in
            let pair = part.trimmingCharacters(in: .whitespaces).split(separator: "=", maxSplits: 1)
            return pair.count == 2 && pair[0] == "__csrf" ? String(pair[1]) : nil
        }.first ?? ""
        if audioClient && path != MusicClientRequest.apiPath { throw LokiError.message("不支持的音乐音源路径。") }
        var url = URLComponents(string: audioClient ? MusicClientRequest.endpoint.absoluteString : "https://music.163.com" + path)!
        var parameters = query
        if payload != nil { parameters["csrf_token"] = csrf }
        url.queryItems = parameters.sorted(by: { $0.key < $1.key }).map { URLQueryItem(name: $0.key, value: $0.value) }
        var request = URLRequest(url: url.url!, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 25)
        request.setValue(cookie, forHTTPHeaderField: "Cookie")
        request.setValue("https://music.163.com/", forHTTPHeaderField: "Referer")
        request.setValue("https://music.163.com", forHTTPHeaderField: "Origin")
        request.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 26_0 like Mac OS X) AppleWebKit/605.1.15 Version/26.0 Mobile/15E148 Safari/604.1", forHTTPHeaderField: "User-Agent")
        if var payload {
            payload["csrf_token"] = csrf
            let fields: [String: String]
            if audioClient {
                let header = MusicClientRequest.header(cookie: cookie, requestID: String(Int64(Date().timeIntervalSince1970 * 1000)))
                payload["header"] = header; payload["e_r"] = false
                request.setValue("NeteaseMusic 9.0.90/5038 (iPhone; iOS 16.2; zh_CN)", forHTTPHeaderField: "User-Agent")
                request.setValue(header.sorted(by: { $0.key < $1.key }).map { key, value in
                    let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-._~"))
                    return "\(key)=\(value.addingPercentEncoding(withAllowedCharacters: allowed) ?? "")"
                }.joined(separator: "; "), forHTTPHeaderField: "Cookie")
                fields = try NetEaseCrypto.audioClient(payload, path: path)
            } else { fields = try NetEaseCrypto.encrypt(payload) }
            var form = URLComponents()
            form.queryItems = fields.map { URLQueryItem(name: $0.key, value: $0.value) }
            request.httpMethod = "POST"
            request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
            request.httpBody = form.percentEncodedQuery?.replacingOccurrences(of: "+", with: "%2B").data(using: .utf8)
        }
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw LokiError.message("网易云未返回 HTTP 响应。") }
        guard http.statusCode == 200 else { throw LokiError.message("网易云接口 HTTP \(http.statusCode)；未取得有效响应，不是会员状态判定。") }
        guard data.count < 8_000_000, let result = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw LokiError.message("网易云接口响应格式异常，未取得歌曲数据。")
        }
        guard (result["code"] as? NSNumber)?.intValue == 200 else {
            let code = (result["code"] as? NSNumber)?.intValue ?? -1
            throw LokiError.message("网易云未接受本次操作（\(code)）；请检查登录或歌曲权限。")
        }
        return result
    }
    func account() async throws -> (String, String) {
        let result = try await request("/weapi/nuser/account/get", payload: [:])
        guard let account = result["account"] as? [String: Any], let id = MusicSong.identifier(account["id"]) else {
            throw LokiError.message("网易云登录尚未完成。")
        }
        return (id, (result["profile"] as? [String: Any])?["nickname"] as? String ?? "网易云账号")
    }
    func search(_ keyword: String) async throws -> [MusicSong] {
        let result = try await request("/api/search/get", query: ["s": String(MusicPlaybackPolicy.searchQuery(keyword).prefix(200)), "type": "1", "limit": "20", "offset": "0"])
        return ((result["result"] as? [String: Any])?["songs"] as? [[String: Any]] ?? []).compactMap(MusicSong.parse)
    }
    func playlists(uid: String) async throws -> [MusicPlaylist] {
        let result = try await request("/api/user/playlist", query: ["uid": uid, "limit": "100", "offset": "0"])
        return (result["playlist"] as? [[String: Any]] ?? []).compactMap { value in
            guard let id = MusicSong.identifier(value["id"]), let name = value["name"] as? String else { return nil }
            return MusicPlaylist(id: id, name: name, count: (value["trackCount"] as? NSNumber)?.intValue ?? 0)
        }
    }
    func songs(playlist: String) async throws -> [MusicSong] {
        let result = try await request("/api/v6/playlist/detail", query: ["id": playlist])
        return ((result["playlist"] as? [String: Any])?["tracks"] as? [[String: Any]] ?? []).compactMap(MusicSong.parse)
    }
    func recommendations() async throws -> [MusicSong] {
        let result = try await request("/weapi/v3/discovery/recommend/songs", payload: [:])
        return ((result["data"] as? [String: Any])?["dailySongs"] as? [[String: Any]] ?? []).compactMap(MusicSong.parse)
    }
    func like(_ song: String) async throws {
        _ = try await request("/weapi/radio/like", payload: ["trackId": song, "like": true, "alg": "itembased", "time": 3])
    }
    func createPlaylist(_ name: String) async throws -> String {
        let result = try await request("/weapi/playlist/create", payload: ["name": String(name.prefix(60)), "privacy": "10", "type": "NORMAL"])
        guard let id = MusicSong.identifier(result["id"] ?? (result["playlist"] as? [String: Any])?["id"]) else {
            throw LokiError.message("歌单结果不完整，请在网易云检查；没有自动重复创建。")
        }
        return id
    }
    func add(_ song: String, playlist: String) async throws {
        _ = try await request("/weapi/playlist/manipulate/tracks", payload: ["op": "add", "pid": playlist, "trackIds": "[\(song)]", "imme": true])
    }
    func lyrics(_ song: String) async throws -> String {
        let result = try await request("/api/song/lyric", query: ["id": song, "lv": "1", "kv": "1", "tv": "-1"])
        return String(((result["lrc"] as? [String: Any])?["lyric"] as? String ?? "").prefix(12000))
    }
    func playable(_ song: String) async throws -> URL {
        sourceAttempts = []
        let result = try await request("/weapi/song/enhance/player/url", payload: ["ids": "[\(song)]", "br": 320000])
        do { return try inspectSource(result, song: song, route: "web_legacy") }
        catch is MusicLinkError {
            // Same account, same song, same 320k/exhigh tier; no alternate provider or trial bypass.
            let modern = try await request("/weapi/song/enhance/player/url/v1",
                                           payload: ["ids": "[\(song)]", "level": "exhigh", "encodeType": "flac"])
            do { return try inspectSource(modern, song: song, route: "web_v1") }
            catch is MusicLinkError {
                let native = try await request(MusicClientRequest.apiPath,
                    payload: ["ids": "[\(song)]", "level": "exhigh", "encodeType": "flac"], audioClient: true)
                return try inspectSource(native, song: song, route: "client_v1")
            }
        }
    }
    private func inspectSource(_ response: [String: Any], song: String, route: String) throws -> URL {
        let entry = (response["data"] as? [[String: Any]])?.first ?? [:]
        sourceAttempts.append(["route": route, "song_id": song,
            "entry_id": MusicSong.identifier(entry["id"]) ?? "missing",
            "entry_code": (entry["code"] as? NSNumber)?.stringValue ?? "missing",
            "has_url": String((entry["url"] as? String)?.isEmpty == false),
            "trial": String(entry["freeTrialInfo"] != nil && !(entry["freeTrialInfo"] is NSNull))])
        try? PrivateFiles.save(sourceAttempts, "music-source-diagnostics.json")
        return try MusicPlaybackPolicy.source(response, song: song)
    }
}

private final class MusicNoRedirect: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}
