import SwiftUI
import VisionKit

struct PairingCode: Decodable {
    let url: String
    let token: String
    static func decode(_ value: String) throws -> PairingCode {
        guard value.utf8.count < 4096 else { throw LokiError.message("配对码过长。") }
        let code = try JSONDecoder().decode(Self.self, from: Data(value.utf8))
        guard let parts = URLComponents(string: code.url), parts.scheme == "https",
              let host = parts.host, !host.isEmpty, parts.user == nil, parts.password == nil,
              parts.query == nil, parts.fragment == nil,
              parts.path.isEmpty || parts.path == "/", (32...256).contains(code.token.count),
              code.token.unicodeScalars.allSatisfy({ CharacterSet.alphanumerics.contains($0) || "-_".unicodeScalars.contains($0) })
        else { throw LokiError.message("这不是有效的 Loki HTTPS 配对码。") }
        return code
    }
}

struct PairingScanner: UIViewControllerRepresentable {
    let found: (String) -> Void
    let failed: (String) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(found: found, failed: failed) }
    func makeUIViewController(context: Context) -> DataScannerViewController {
        let scanner = DataScannerViewController(recognizedDataTypes: [.barcode(symbologies: [.qr])],
            qualityLevel: .balanced, recognizesMultipleItems: false,
            isHighFrameRateTrackingEnabled: false, isPinchToZoomEnabled: true,
            isGuidanceEnabled: true, isHighlightingEnabled: true)
        scanner.delegate = context.coordinator
        do { try scanner.startScanning() }
        catch { DispatchQueue.main.async { failed("相机扫描暂不可用，请检查相机权限。") } }
        return scanner
    }
    func updateUIViewController(_ controller: DataScannerViewController, context: Context) {}
    static func dismantleUIViewController(_ controller: DataScannerViewController, coordinator: Coordinator) {
        controller.stopScanning()
    }
    final class Coordinator: NSObject, DataScannerViewControllerDelegate {
        let found: (String) -> Void
        let failed: (String) -> Void
        private var finished = false
        init(found: @escaping (String) -> Void, failed: @escaping (String) -> Void) {
            self.found = found; self.failed = failed
        }
        func dataScanner(_ dataScanner: DataScannerViewController, didAdd addedItems: [RecognizedItem], allItems: [RecognizedItem]) {
            guard !finished else { return }
            for item in addedItems {
                if case .barcode(let code) = item, let value = code.payloadStringValue {
                    finished = true; dataScanner.stopScanning(); found(value); return
                }
            }
        }
        func dataScanner(_ dataScanner: DataScannerViewController, becameUnavailableWithError error: DataScannerViewController.ScanningUnavailable) {
            guard !finished else { return }; finished = true
            failed("扫描已中断，请检查相机权限后再试。")
        }
    }
}

struct PairingScanView: View {
    @Environment(\.dismiss) private var dismiss
    let found: (String) -> Void
    let failed: (String) -> Void
    var body: some View {
        NavigationStack {
            Group {
                if DataScannerViewController.isSupported && DataScannerViewController.isAvailable {
                    PairingScanner(found: { value in dismiss(); found(value) },
                                   failed: { value in dismiss(); failed(value) })
                } else {
                    ContentUnavailableView("扫描暂不可用", systemImage: "camera",
                        description: Text("请在系统设置中允许 Loki 使用相机，也可以使用手动配对。"))
                }
            }
            .navigationTitle("扫描电脑上的配对码").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } } }
        }
    }
}
