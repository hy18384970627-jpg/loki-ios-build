import SwiftUI
import FamilyControls
import DeviceActivity
import UIKit
import PhotosUI

struct ToolsView: View {
    var body: some View {
        NavigationStack {
            List {
                Section("生活与约定") {
                    NavigationLink { MusicView() } label: { Label("一起听", systemImage: "music.note") }
                    NavigationLink { ShoppingView() } label: { Label("淘宝", systemImage: "bag") }
                    NavigationLink { FocusView() } label: { Label("专注与应用限制", systemImage: "hourglass") }
                    NavigationLink { UsageView() } label: { Label("今日应用使用时长", systemImage: "chart.bar") }
                    NavigationLink { DailyLimitsView() } label: { Label("每日应用限额", systemImage: "timer") }
                    NavigationLink { ScheduleView() } label: { Label("提醒、闹钟和计时", systemImage: "bell.badge") }
                    NavigationLink { CalendarView() } label: { Label("日历与提醒事项", systemImage: "calendar") }
                    NavigationLink { TasksView() } label: { Label("任务与照片记录", systemImage: "checklist") }
                    NavigationLink { NearbyView() } label: { Label("位置与附近地点", systemImage: "location") }
                }
                Section("手机工具") {
                    NavigationLink { DeviceView() } label: { Label("设备、亮度、手电筒", systemImage: "iphone") }
                    NavigationLink { SearchView() } label: { Label("搜索与计算", systemImage: "magnifyingglass") }
                    NavigationLink { CapabilitiesView() } label: { Label("功能与 iOS 边界", systemImage: "list.bullet.rectangle") }
                }
            }.navigationTitle("生活")
        }
    }
}

struct UsageView: View {
    @EnvironmentObject private var focus: FocusService
    @EnvironmentObject private var app: AppState
    @State private var showReport = false
    var body: some View {
        VStack(spacing: 18) {
            Button(focus.authorized ? "查看今日使用报告" : "授权并查看今日使用报告") {
                Task { do { try await focus.authorize(); showReport = true } catch { app.tell(error) } }
            }.buttonStyle(.bordered)
            if showReport {
                DeviceActivityReport(.init("LokiDaily"), filter: .init(
                    segment: .daily(during: DateInterval(start: Calendar.current.startOfDay(for: Date()), end: Date())),
                    users: .all, devices: .init([.iPhone])))
            } else {
                Text("此报告在苹果提供的独立沙盒中生成，不能直接把所有应用使用数据交给模型。")
                    .font(.caption).foregroundStyle(.secondary)
                Spacer()
            }
        }.padding().navigationTitle("使用时长")
            .task { focus.refresh(); showReport = focus.authorized }
    }
}

struct FocusView: View {
    @EnvironmentObject private var focus: FocusService
    @EnvironmentObject private var app: AppState
    @State private var picker = false
    @State private var confirm = false
    @State private var minutes = 25
    @State private var nightStart = Calendar.current.date(from: DateComponents(hour: 0, minute: 0)) ?? Date()
    @State private var nightEnd = Calendar.current.date(from: DateComponents(hour: 8, minute: 0)) ?? Date()
    var body: some View {
        Form {
            Section {
                Text(focus.status)
                if focus.authorized { Label("屏幕使用时间已授权", systemImage: "checkmark.circle") }
                else { Button("授权屏幕使用时间") { Task { do { try await focus.authorize() } catch { app.tell(error) } } } }
                Button("编辑已保存的应用选择") { Task { do { try await focus.authorize(); picker = true } catch { app.tell(error) } } }
                Toggle("允许 Loki 直接锁定这些应用", isOn: $focus.autonomyEnabled)
                Text("应用选择会立即保存；聊天中无需逐次确认锁定。Loki 只能操作你在这里选定的范围。")
                    .font(.caption).foregroundStyle(.secondary)
                Text("应用选择以系统加密令牌保存在本机，不上传应用名单。请不要把 Loki 自己选入限制范围。")
                    .font(.caption).foregroundStyle(.secondary)
                Stepper("\(minutes) 分钟", value: $minutes, in: 15...120, step: 5)
                Button("开始专注") { confirm = true }
                Button("立即结束并解除限制", role: .destructive) { focus.stop() }
            }
            Section("夜间使用时自动锁定") {
                DatePicker("开始", selection: $nightStart, displayedComponents: .hourAndMinute)
                DatePicker("结束", selection: $nightEnd, displayedComponents: .hourAndMinute)
                Text("窗口内使用所选应用满1分钟后锁定，到结束时间解除；由系统扩展执行，Loki 不必保持前台。只表示检测到使用，不推断你是否入睡。")
                    .font(.caption).foregroundStyle(.secondary)
                Button("保存并启用夜间规则") {
                    do {
                        let c = Calendar.current
                        try focus.scheduleNight(start: c.component(.hour, from: nightStart) * 60 + c.component(.minute, from: nightStart),
                            end: c.component(.hour, from: nightEnd) * 60 + c.component(.minute, from: nightEnd))
                        app.notice = "夜间规则已保存。"
                    } catch { app.tell(error) }
                }
                Button("关闭夜间规则") { focus.stopNight() }
            }
            Section {
                Text("这是你授权的应用屏蔽，可以撤销授权或卸载 App 来退出。不会替你设屏幕使用时间密码。首次使用请先用一个不重要的应用验证到期解除。")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }.navigationTitle("专注")
            .task {
                focus.refresh()
                if let a = FocusState.defaults?.object(forKey: "nightStartMinute") as? Int,
                   let b = FocusState.defaults?.object(forKey: "nightEndMinute") as? Int {
                    nightStart = Calendar.current.date(from: DateComponents(hour: a / 60, minute: a % 60)) ?? nightStart
                    nightEnd = Calendar.current.date(from: DateComponents(hour: b / 60, minute: b % 60)) ?? nightEnd
                }
            }
            .familyActivityPicker(isPresented: $picker, selection: $focus.selection)
            .confirmationDialog("限制所选应用 \(minutes) 分钟？", isPresented: $confirm) {
                Button("确认开始") { do { try focus.start(minutes: minutes) } catch { app.tell(error) } }
            }
    }
}

struct ScheduleView: View {
    @EnvironmentObject private var app: AppState
    @EnvironmentObject private var notifications: NotificationService
    @EnvironmentObject private var alarms: AlarmService
    @State private var title = "该休息一下了。"
    @State private var date = Date().addingTimeInterval(3600)
    @State private var minutes = 10
    var body: some View {
        Form {
            Section("课表自动闹钟") {
                Text(alarms.courseStatus)
                Text("只在上午有课的日子设起床闹钟，按上午首节课提前40分钟，每天一个。下午和晚课不设闹钟；预排后离线也可响铃，打开App更新。临时调课需要先更新课表。")
                    .font(.caption).foregroundStyle(.secondary)
                Button("开启并按课表自动安排") { Task { await alarms.enableCourses(api: app.api) } }
                    .disabled(alarms.courseSyncing || !app.paired)
                Button("更新课表闹钟") { Task { do { try await alarms.syncCourses(api: app.api, force: true) } catch { app.tell(error) } } }
                    .disabled(alarms.courseSyncing || !alarms.courseEnabled)
                Button("关闭并取消课表闹钟", role: .destructive) { do { try alarms.stopCourseAlarms() } catch { app.tell(error) } }
            }
            Section("指定时间") {
                TextField("提醒内容", text: $title)
                DatePicker("时间", selection: $date, in: Date()...)
                Button("创建普通通知提醒") { Task { do {
                    _ = try await notifications.schedule(title: "Loki", body: title, at: date)
                    app.notice = "系统已接受通知计划。普通通知受专注模式和通知设置影响。"
                } catch { app.tell(error) } } }
                Button("创建系统闹钟 · AlarmKit") { Task { do {
                    try await alarms.schedule(title: title, at: date); app.notice = "已创建系统闹钟。"
                } catch { app.tell(error) } } }
            }
            Section("倒计时到点闹钟") {
                Stepper("\(minutes) 分钟后", value: $minutes, in: 1...180)
                Button("开始计时") { Task { do {
                    try await alarms.schedule(title: title, at: Date().addingTimeInterval(Double(minutes * 60)))
                    app.notice = "已设置 \(minutes) 分钟后的闹钟；当前版本没有锁屏实时倒计时。"
                } catch { app.tell(error) } } }
            }
            Section("已登记的系统闹钟") {
                ForEach(alarms.saved) { alarm in
                    HStack { VStack(alignment: .leading) { Text(alarm.title); Text(alarm.date.formatted()).font(.caption) }
                        Spacer(); Button("取消") { do { try alarms.cancel(alarm) } catch { app.tell(error) } }
                    }
                }
            }
            Section("待发的普通通知") {
                ForEach(notifications.pending, id: \.identifier) { item in
                    HStack { Text(item.content.body); Spacer(); Button("取消") { Task { await notifications.cancel(item.identifier) } } }
                }
            }
        }.navigationTitle("提醒与闹钟").task { alarms.refresh(); await notifications.refresh() }
    }
}

struct CalendarView: View {
    @EnvironmentObject private var app: AppState
    @EnvironmentObject private var device: DeviceTools
    @State private var title = ""
    @State private var date = Date().addingTimeInterval(3600)
    var body: some View {
        Form {
            Section("创建事项") {
                TextField("标题", text: $title)
                DatePicker("开始时间", selection: $date)
                Button("添加一小时日历日程") { Task { do { try await device.addCalendar(title: title, date: date); app.notice = "已保存到系统日历。" } catch { app.tell(error) } } }.disabled(title.isEmpty)
                Button("添加系统提醒事项") { Task { do { try await device.addReminder(title: title, date: date); app.notice = "已保存到系统提醒事项。" } catch { app.tell(error) } } }.disabled(title.isEmpty)
            }
            Section("未来七天") {
                Button("授权并查看日历") { Task { do { try await device.readCalendar() } catch { app.tell(error) } } }
                ForEach(device.calendarItems, id: \.eventIdentifier) { event in
                    VStack(alignment: .leading) { Text(event.title ?? "无标题"); Text(event.startDate.formatted()).font(.caption).foregroundStyle(.secondary) }
                }
            }
        }.navigationTitle("日历")
    }
}

struct TasksView: View {
    @EnvironmentObject private var app: AppState
    @State private var title = ""
    @State private var due = Date().addingTimeInterval(3600)
    var body: some View {
        List {
            Section("新约定") {
                TextField("要做什么", text: $title)
                DatePicker("截止时间", selection: $due, in: Date()...)
                Button("保存任务") {
                    app.tasks.append(.init(title: title, due: due)); app.persistTasks(); title = ""
                }.disabled(title.isEmpty)
            }
            ForEach($app.tasks) { $task in
                NavigationLink { TaskDetailView(task: $task) } label: {
                    VStack(alignment: .leading) {
                        Text(task.title)
                        Text(task.submittedAt == nil ? "截止 \(task.due.formatted())" : "已记录提交 · 尚未自动审阅")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
        }.navigationTitle("任务")
    }
}

struct TaskDetailView: View {
    @Binding var task: TaskCard
    @EnvironmentObject private var app: AppState
    @State private var photo: PhotosPickerItem?
    @State private var image: UIImage?
    @State private var camera = false
    private var filename: String { "task-\(task.id.uuidString).jpg" }
    var body: some View {
        Form {
            Section(task.title) {
                Text("截止：\(task.due.formatted())")
                TextField("完成情况", text: $task.submission, axis: .vertical).lineLimit(3...8)
                PhotosPicker("选择一张照片", selection: $photo, matching: .images)
                Button("拍照记录") {
                    if UIImagePickerController.isSourceTypeAvailable(.camera) { camera = true }
                    else { app.notice = "这台设备没有可用相机。" }
                }
                if let image { Image(uiImage: image).resizable().scaledToFit().frame(maxHeight: 250) }
                Button("保存提交记录") {
                    do {
                        if let data = image?.jpegData(compressionQuality: 0.65) {
                            try data.write(to: PrivateFiles.url(filename), options: [.atomic, .completeFileProtection])
                        }
                        task.submittedAt = Date(); app.persistTasks()
                        app.notice = "已保存在本机。照片尚未发送，未自动判断任务完成。"
                    } catch { app.tell(error) }
                }
                Button(image == nil ? "把说明发给 Loki 核对" : "把照片和说明发给 Loki 核对") {
                    // Send is explicit. No automatic verdict or automatic task-to-shield coupling.
                    let data = image?.jpegData(compressionQuality: 0.45)
                    if let data, data.count > 4_000_000 { app.notice = "照片过大，请选择较小的照片。"; return }
                    Task {
                        await app.send("请核对这项任务：\(task.title)。我提交的说明：\(task.submission)", image: data)
                        app.selectedTab = 0
                    }
                }.disabled(!app.paired || (task.submission.isEmpty && image == nil) || app.busy)
            }
        }.navigationTitle("任务记录")
            .sheet(isPresented: $camera) { CameraSheet { image = $0 } }
            .onChange(of: photo) { _, selection in
                Task { if let data = try? await selection?.loadTransferable(type: Data.self) { image = MobileImage.from(data) } }
            }
            .task { if let url = try? PrivateFiles.url(filename), let data = try? Data(contentsOf: url) { image = UIImage(data: data) } }
    }
}

struct NearbyView: View {
    @StateObject private var location = LocationService.shared
    @EnvironmentObject private var app: AppState
    @State private var query = "咖啡"
    @State private var searchTask: Task<Void, Never>?
    var body: some View {
        List {
            Section {
                Button("获取当前位置") { location.locate() }
                Button("开启定位天气 · Open-Meteo") { location.enableWeather() }
                Text("开启后会将约1公里精度的位置发给 Open-Meteo 查询当地天气，并把位置及天气同步给你的 Loki 私人接口。天气是模型与预报数据；Loki 会结合课程和上文自然关心，不固定播报。")
                    .font(.caption).foregroundStyle(.secondary)
                Text(location.weatherMessage).font(.caption)
                Button("申请始终允许位置更新") { location.requestAlways() }
                Text("首次可能先显示使用期间授权；之后请在系统设置里选择“始终”。系统可能暂停定位，不保证每秒更新；后台定位会增加耗电。")
                    .font(.caption).foregroundStyle(.secondary)
                Button("暂停自动位置与天气分享", role: .destructive) { location.stopAutomatic() }
                Text(location.message).font(.caption)
                if let position = location.position {
                    Text("\(position.coordinate.latitude), \(position.coordinate.longitude)").font(.caption).textSelection(.enabled)
                }
                TextField("查找附近", text: $query).submitLabel(.search).onSubmit { search() }
                Button(location.searching ? "正在查找…" : "搜索附近地点") { search() }
                    .disabled(location.searching || query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                if location.searching { ProgressView(location.nearbyMessage) }
                else if !location.nearbyMessage.isEmpty { Text(location.nearbyMessage).font(.caption) }
            }
            ForEach(location.places.indices, id: \.self) { index in
                let place = location.places[index]
                Button(place.name ?? "地图地点") { place.openInMaps() }
            }
        }.navigationTitle("位置与附近")
            .task { await location.refreshForNearbyPage() }
            .onDisappear { searchTask?.cancel(); location.cancelNearbySearch() }
    }
    private func search() {
        guard !location.searching else { return }
        let term = query
        searchTask = Task {
            do { try await location.nearby(term) }
            catch { if !Task.isCancelled { app.tell(error) } }
        }
    }
}

struct DeviceView: View {
    @EnvironmentObject private var device: DeviceTools
    @EnvironmentObject private var app: AppState
    @State private var brightness = 0.5
    @State private var share = false
    @State private var screenshot: UIImage?
    @State private var pasted = ""
    var body: some View {
        Form {
            Section("状态") {
                LabeledContent("电池", value: device.battery)
                LabeledContent("可用存储", value: device.storage)
                LabeledContent("网络类型", value: device.network)
                LabeledContent("当前时间", value: Date().formatted())
            }
            Section("屏幕与声音") {
                Slider(value: $brightness, in: 0.05...1) { Text("亮度") }.onChange(of: brightness) { _, value in
                    do { try device.setBrightness(value) } catch { app.tell(error) }
                }
                Text("音量（系统控件）").font(.caption)
                VolumeControl().frame(height: 30)
                Button("轻触震动") { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
            }
            Section("手电筒") {
                Button("打开") { do { try device.torch(true) } catch { app.tell(error) } }
                Button("关闭") { do { try device.torch(false) } catch { app.tell(error) } }
            }
            Section("由你主动操作") {
                Button("分享当前 Loki 页面截图") { do { screenshot = try device.screenshot(); share = true } catch { app.tell(error) } }
                PasteButton(payloadType: String.self) { values in pasted = values.first ?? "" }
                if !pasted.isEmpty { Text(pasted).textSelection(.enabled) }
                Text("只截图 Loki 自己。剪贴板只在你点击粘贴时读取。")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }.navigationTitle("设备工具").onAppear { brightness = device.currentBrightness ?? 0.5 }
            .sheet(isPresented: $share) { if let screenshot { ShareSheet(items: [screenshot]) } }
    }
}

struct SearchView: View {
    @EnvironmentObject private var device: DeviceTools
    @EnvironmentObject private var app: AppState
    @Environment(\.openURL) private var openURL
    @State private var query = ""
    @State private var expression = ""
    @State private var result = ""
    var body: some View {
        Form {
            Section("联网搜索") {
                TextField("搜索内容", text: $query)
                Button("在浏览器搜索") {
                    var url = URLComponents(string: "https://www.bing.com/search")!
                    url.queryItems = [.init(name: "q", value: query)]
                    if let url = url.url { openURL(url) }
                }.disabled(query.isEmpty)
            }
            Section("基础计算") {
                TextField("例如 (24+6)/2", text: $expression).keyboardType(.numbersAndPunctuation)
                Button("计算") { do { result = try device.calculate(expression) } catch { app.tell(error) } }
                if !result.isEmpty { Text(result).font(.title).textSelection(.enabled) }
                Text("仅开放基本算术，不执行任意脚本。网页搜索结果不会自动回传模型。")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }.navigationTitle("搜索与计算")
    }
}
