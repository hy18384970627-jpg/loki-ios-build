import Foundation
import Combine
import Security

struct ShoppingCredentials: Codable {
    let key: String
    let secret: String
    let adzone: String
    static func load() -> ShoppingCredentials? {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "dev.zcydrkv7yh.loki.shopping", kSecReturnData as String: true]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data else { return nil }
        return try? JSONDecoder().decode(Self.self, from: data)
    }
    static func save(_ value: ShoppingCredentials?) throws {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "dev.zcydrkv7yh.loki.shopping"]
        guard let value else { SecItemDelete(query as CFDictionary); return }
        let attributes: [String: Any] = [kSecValueData as String: try JSONEncoder().encode(value),
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly]
        let status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if status == errSecItemNotFound {
            guard SecItemAdd(query.merging(attributes) { _, b in b } as CFDictionary, nil) == errSecSuccess else { throw LokiError.message("无法保存淘宝授权。") }
        } else if status != errSecSuccess { throw LokiError.message("无法保存淘宝授权。") }
    }
}

actor ShoppingClient {
    private let session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.httpShouldSetCookies = false; config.urlCache = nil
        return URLSession(configuration: config, delegate: ShoppingNoRedirect(), delegateQueue: nil)
    }()
    func products(action: String, query: String) async throws -> [ShoppingProduct] {
        guard let credentials = ShoppingCredentials.load() else { throw LokiError.message("请先配置淘宝联盟授权。") }
        let detail = action == "detail"
        let formatter = DateFormatter(); formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(secondsFromGMT: 8 * 3600); formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        var fields = ["app_key": credentials.key, "method": detail ? "taobao.tbk.item.info.get" : "taobao.tbk.dg.material.optional.upgrade",
            "timestamp": formatter.string(from: Date()), "format": "json", "v": "2.0", "sign_method": "md5", "platform": "2"]
        if detail { fields["num_iids"] = String(query.prefix(200)) }
        else {
            fields.merge(["q": String(query.prefix(200)), "page_size": "12", "page_no": "1",
                "sort": "total_sales_des", "adzone_id": credentials.adzone]) { _, b in b }
        }
        fields["sign"] = ShoppingPolicy.sign(fields, secret: credentials.secret)
        var form = URLComponents(); form.queryItems = fields.map { URLQueryItem(name: $0.key, value: $0.value) }
        var request = URLRequest(url: URL(string: "https://eco.taobao.com/router/rest")!, timeoutInterval: 25)
        request.httpMethod = "POST"; request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.httpBody = form.percentEncodedQuery?.replacingOccurrences(of: "+", with: "%2B").data(using: .utf8)
        let (data, response) = try await session.data(for: request)
        guard (response as? HTTPURLResponse)?.statusCode == 200, data.count <= 4_000_000,
              let body = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { throw LokiError.message("淘宝接口暂不可用。") }
        if let error = body["error_response"] as? [String: Any] {
            let code = (error["code"] as? NSNumber)?.stringValue ?? "未知"
            throw LokiError.message("淘宝未接受查询（\(code)），请检查应用和接口权限；没有执行购买。")
        }
        let root = body[detail ? "tbk_item_info_get_response" : "tbk_dg_material_optional_upgrade_response"] as? [String: Any]
        guard let root else { throw LokiError.message("淘宝返回的商品格式暂不支持。") }
        let rows: [[String: Any]]
        if detail { rows = (root["results"] as? [String: Any])?["n_tbk_item"] as? [[String: Any]] ?? [] }
        else { rows = (root["result_list"] as? [String: Any])?["map_data"] as? [[String: Any]] ?? [] }
        return Array(rows.prefix(12)).compactMap(ShoppingProduct.parse)
    }
}

@MainActor final class ShoppingService: ObservableObject {
    static let shared = ShoppingService()
    let client = ShoppingClient()
    @Published private(set) var configured = ShoppingCredentials.load() != nil
    @Published var enabled = UserDefaults.standard.object(forKey: "shoppingEnabled") as? Bool ?? true {
        didSet { UserDefaults.standard.set(enabled, forKey: "shoppingEnabled") }
    }
    @Published private(set) var products: [ShoppingProduct] = []
    @Published private(set) var status = ""
    private var claims: [String] = PrivateFiles.load("shopping-claims.json", fallback: [])
    private init() {}
    var context: [String: Any] { ["configured": configured, "enabled": enabled] }
    func save(key: String, secret: String, adzone: String) throws {
        let key = key.trimmingCharacters(in: .whitespacesAndNewlines), secret = secret.trimmingCharacters(in: .whitespacesAndNewlines)
        let adzone = adzone.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty, !secret.isEmpty, !adzone.isEmpty, adzone.allSatisfy({ $0.isASCII && $0.isNumber }) else {
            throw LokiError.message("请填写 AppKey、AppSecret 和推广位最后一段 adzone_id。")
        }
        try ShoppingCredentials.save(.init(key: key, secret: secret, adzone: adzone))
        configured = true; status = "授权已保存，待首次查询验证"
    }
    func disconnect() { try? ShoppingCredentials.save(nil); configured = false; products = []; status = "已移除淘宝授权" }
    func reportPendingResult() { status = "商品结果已取得，Loki 的解读暂未送达；可在这里查看商品。" }
    func search(_ query: String) async throws {
        products = try await client.products(action: "search", query: query)
        status = products.isEmpty ? "本次没有查到商品" : "已取得 \(products.count) 件商品"
    }
    func apply(_ action: ShoppingAction) async -> [String: Any]? {
        guard configured, enabled, Date().timeIntervalSince1970 < action.expires,
              !claims.contains(action.id.uuidString), ["search", "detail"].contains(action.action),
              let query = action.action == "search" ? action.query : action.item_id, !query.isEmpty else { return nil }
        claims.append(action.id.uuidString)
        do { try PrivateFiles.save(claims, "shopping-claims.json") }
        catch { status = "未能保存查询记录，本次未查询"; return nil }
        do {
            products = try await client.products(action: action.action, query: query)
            status = products.isEmpty ? "本次没有查到商品" : "已取得 \(products.count) 件商品"
            return ["state": "completed", "query": query, "products": products.map(\.payload)]
        } catch {
            products = []; status = error.localizedDescription
            return ["state": "failed", "note": status, "products": []]
        }
    }
}
private final class ShoppingNoRedirect: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
        newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}
