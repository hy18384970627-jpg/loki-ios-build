import Foundation

struct MobileReply: Decodable {
    let text: String
    let speech_text: String?
    let wallpaper_change: WallpaperChange?
    let app_control: AppControl?
    let music_action: MusicAction?
    let shopping_action: ShoppingAction?
    let steered_ids: [UUID]?
}
struct FollowupReceipt: Decodable { let state: String }
struct ChatRequestStatus: Decodable {
    let state: String
    let reply: MobileReply?
    let error: String?
}
struct AppControl: Decodable {
    let id: UUID
    let action: String
    let minutes: Int?
    let start_minute: Int?
    let end_minute: Int?
    let success_comment: String
}

struct WallpaperChange: Decodable {
    let id: UUID
    let asset_id: String
    let comment: String
}

struct GatewayStatus: Decodable {
    let ready: Bool
    let chat_enabled: Bool
    let canonical_writeback: Bool
    let automatic_model_tools: Bool
    let remote_push_active: Bool
}

struct MobileAPI {
    let base: String
    let token: String
    private static let session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.waitsForConnectivity = false
        config.urlCache = nil
        config.httpMaximumConnectionsPerHost = 4
        return URLSession(configuration: config, delegate: NoRedirect(), delegateQueue: nil)
    }()
    private func request(_ path: String, _ body: [String: Any]?, timeout: Double = 245) throws -> URLRequest {
        guard let root = URLComponents(string: base.trimmingCharacters(in: .whitespacesAndNewlines)),
              root.scheme == "https", root.host != nil, root.user == nil, root.password == nil,
              root.query == nil, root.fragment == nil, root.path.isEmpty || root.path == "/",
              let url = URL(string: base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + path),
              token.count >= 32 else { throw LokiError.message("请填写有效的 HTTPS 私有入口和配对令牌。") }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: timeout)
        request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        if let body {
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
        }
        return request
    }
    func data(_ path: String, _ body: [String: Any]? = nil, timeout: Double = 245) async throws -> Data {
        let (data, response) = try await Self.session.data(for: request(path, body, timeout: timeout))
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let code = (try? JSONSerialization.jsonObject(with: data) as? [String: String])?["error"] ?? "network_error"
            if code == "speech_not_clear" { throw LokiError.speechNotClear }
            let reasons = ["previous_reply_still_finishing": "上一条回复还在处理，请稍后再点重试。",
                "request_pending_or_uncertain": "这条消息尚未取得回复，请点红色感叹号重试。",
                "upstream_failed_no_automatic_retry": "消息已接收，但回复未完成。点红色感叹号可重试。",
                "voice_not_understood_no_automatic_retry": "录音已收到，但识别未完成。点红色感叹号可重试原录音。"]
            throw LokiError.message(reasons[code] ?? "接口返回：\(code)。请求不会自动重发。")
        }
        return data
    }
    // Awaiting the consumer applies backpressure instead of retaining full audio.
    func speech(_ text: String, waitForSlot: Bool = false, consume: @MainActor (Data) async throws -> Void) async throws {
        let segments = PCMPlayback.sentences(text)
        guard !segments.isEmpty, segments.count <= 24, text.count <= 12000,
              segments.allSatisfy({ $0.count <= 2000 }) else { throw LokiError.message("本次语音过长，请分段播放。") }
        for attempt in 0...1 {
            var total = 0
            do {
                let download = PCMDownload(); defer { download.cancel() }
                let stream = download.stream(for: try request("/v1/speech/stream", ["text": text, "segments": segments, "wait_for_slot": waitForSlot]))
                var chunk = Data(); chunk.reserveCapacity(64_000)
                for try await packet in stream {
                    try Task.checkCancellation()
                    chunk.append(packet); total += packet.count
                    guard total <= 24_000 * 2 * 120 else { throw LokiError.message("音频超过本次播放上限。") }
                    while chunk.count >= 4800 {
                        try await consume(Data(chunk.prefix(4800)))
                        chunk.removeFirst(4800)
                    }
                    download.consumed(packet.count)
                }
                guard total > 0, chunk.count.isMultiple(of: 2) else { throw LokiError.message("音频为空或不完整。") }
                if !chunk.isEmpty { try await consume(chunk) }
                return
            } catch {
                guard SpeechTransportRetry.shouldRetry(error, attempt: attempt, receivedBytes: total) else { throw error }
                try await Task.sleep(for: .milliseconds(250))
            }
        }
    }
    func status() async throws -> GatewayStatus { try JSONDecoder().decode(GatewayStatus.self, from: await data("/v1/status", timeout: 10)) }
    func chat(id: UUID, message: String, image: Data? = nil, health: [String: Any]? = nil, nativeActions: [String: Any]? = nil,
              wallpaper: String = "ChatWallpaper", availableWallpapers: [String] = ["ChatWallpaper"],
              voiceRequestID: UUID? = nil, inCall: Bool = false, nativeFocus: [String: Any]? = nil) async throws -> MobileReply {
        try await chat(prepared: prepareChat(id: id, message: message, image: image, health: health,
            nativeActions: nativeActions, wallpaper: wallpaper, availableWallpapers: availableWallpapers,
            voiceRequestID: voiceRequestID, inCall: inCall, nativeFocus: nativeFocus))
    }
    func prepareChat(id: UUID, message: String, image: Data? = nil, health: [String: Any]? = nil,
                     nativeActions: [String: Any]? = nil, wallpaper: String = "ChatWallpaper",
                     availableWallpapers: [String] = ["ChatWallpaper"], voiceRequestID: UUID? = nil,
                     inCall: Bool = false, nativeFocus: [String: Any]? = nil,
                     nativeMusic: [String: Any]? = nil, nativeShopping: [String: Any]? = nil) throws -> Data {
        var body: [String: Any] = ["id": id.uuidString, "message": message]
        body["background_generation"] = true
        let zone = TimeZone.current
        body["device_clock"] = ["time_zone": zone.identifier, "utc_offset_seconds": zone.secondsFromGMT(for: Date())]
        if let voiceRequestID {
            body["voice_request_id"] = voiceRequestID.uuidString
            body["voice_mode"] = inCall ? "call" : "voice_message"
        }
        if let nativeFocus { body["native_focus"] = nativeFocus }
        if let nativeMusic { body["native_music"] = nativeMusic }
        if let nativeShopping { body["native_shopping"] = nativeShopping }
        body["wallpaper"] = ["enabled": UserDefaults.standard.object(forKey: "autoWallpaper") as? Bool ?? true,
                             "current_id": wallpaper, "available_ids": availableWallpapers]
        body["native_actions"] = nativeActions ?? ["action": "alarm_capability", "state": "available",
            "note": "This iPhone app supports AlarmKit. Explicit dated owner requests can create native alarms; verified course alarms can be enabled. Availability alone is not a creation receipt."]
        if let health { body["native_health"] = health }
        if let image {
            guard image.count <= 4_000_000 else { throw LokiError.message("图片过大，请选择较小的照片。") }
            body["image"] = image.base64EncodedString()
        }
        return try JSONSerialization.data(withJSONObject: body)
    }
    func chat(prepared: Data) async throws -> MobileReply {
        guard let body = try JSONSerialization.jsonObject(with: prepared) as? [String: Any] else {
            throw LokiError.message("未能读取待发送消息。")
        }
        return try JSONDecoder().decode(MobileReply.self, from: await data("/v1/chat", body))
    }
    func accept(prepared: Data) async throws {
        guard let body = try JSONSerialization.jsonObject(with: prepared) as? [String: Any] else {
            throw LokiError.message("未能读取待发送消息。")
        }
        struct Receipt: Decodable { let accepted: Bool; let id: String }
        let receipt = try JSONDecoder().decode(Receipt.self, from: await data("/v1/chat/accept", body, timeout: 15))
        guard receipt.accepted, receipt.id == body["id"] as? String else { throw LokiError.message("尚未确认消息送达。") }
    }
    func replyToAccepted(id: UUID, retry: Bool = false) async throws -> MobileReply {
        // Only explicit retry can repeat an uncertain generation. Polling is read-only.
        if retry {
            return try JSONDecoder().decode(MobileReply.self, from: await data("/v1/chat/run", ["id": id.uuidString, "retry": true]))
        }
        while true {
            try Task.checkCancellation()
            let inbox: [String: Data] = PrivateFiles.load("received-replies.json", fallback: [:])
            if let cached = inbox[id.uuidString],
               let status = try? JSONDecoder().decode(ChatRequestStatus.self, from: cached),
               status.state == "complete", let reply = status.reply { return reply }
            let status = try await chatStatus(id: id)
            if let reply = status.reply, status.state == "complete" { return reply }
            if status.state == "failed" { throw LokiError.replyGenerationFailed("消息已送达，但回复生成中断。点感叹号可重试。") }
            if status.state == "accepted" {
                // Compatibility with requests accepted before the async runner existed.
                return try JSONDecoder().decode(MobileReply.self, from: await data("/v1/chat/run", ["id": id.uuidString]))
            }
            if status.state == "missing" { throw LokiError.message("正在核对消息接收状态。") }
            try await Task.sleep(for: .seconds(1))
        }
    }
    func chatStatusData(id: UUID) async throws -> Data {
        try await data("/v1/chat/status", ["id": id.uuidString], timeout: 10)
    }
    func chatStatus(id: UUID) async throws -> ChatRequestStatus {
        try JSONDecoder().decode(ChatRequestStatus.self, from: await chatStatusData(id: id))
    }
    func steer(id: UUID, target: UUID, message: String) async throws -> FollowupReceipt {
        try JSONDecoder().decode(FollowupReceipt.self, from: await data("/v1/chat/steer", [
            "id": id.uuidString, "target_request_id": target.uuidString, "message": message], timeout: 30))
    }
    func followupStatus(id: UUID) async throws -> FollowupReceipt {
        try JSONDecoder().decode(FollowupReceipt.self, from: await data("/v1/chat/steer/status", ["id": id.uuidString], timeout: 10))
    }
    func coursePlan() async throws -> CoursePlan {
        try JSONDecoder().decode(CoursePlan.self, from: await data("/v1/courses", timeout: 12))
    }
    func musicCompanion(_ event: MusicEvent, context: [String: Any]) async throws -> MobileReply {
        let body: [String: Any] = ["id": event.id.uuidString,
            "event": ["kind": event.kind, "song": ["id": event.song.id, "title": event.song.title, "artist": event.song.artist]],
            "native_music": context, "device_clock": ["time_zone": TimeZone.current.identifier,
                "utc_offset_seconds": TimeZone.current.secondsFromGMT(for: Date())]]
        return try JSONDecoder().decode(MobileReply.self, from: await data("/v1/music/companion", body))
    }
    func shoppingResult(action: UUID, request: UUID, result: [String: Any]) async throws -> MobileReply {
        try JSONDecoder().decode(MobileReply.self, from: await data("/v1/tools/result", [
            "id": action.uuidString, "request_id": request.uuidString, "result": result,
            "device_clock": ["time_zone": TimeZone.current.identifier,
                "utc_offset_seconds": TimeZone.current.secondsFromGMT(for: Date())]]))
    }
    func transcribe(_ clip: RecordedVoice, retry: Bool = false) async throws -> String {
        struct Recognition: Decodable { let transcript: String }
        let body: [String: Any] = ["id": clip.id.uuidString, "audio": try clip.data().base64EncodedString(), "duration": clip.duration, "retry": retry]
        return try JSONDecoder().decode(Recognition.self, from: await data("/v1/voice", body, timeout: 130)).transcript
    }
    func wakePlan(id: UUID, message: String, health: [String: Any]?) async throws -> WakeAlarmPlan {
        let zone = TimeZone.current
        var body: [String: Any] = ["id": id.uuidString, "message": message,
            "device_clock": ["time_zone": zone.identifier, "utc_offset_seconds": zone.secondsFromGMT(for: Date())]]
        if let health { body["native_health"] = health }
        return try JSONDecoder().decode(WakeAlarmPlan.self, from: await data("/v1/alarms/plan", body))
    }
    func event(kind: String, body: [String: Any], id: UUID = UUID()) async throws {
        var payload = body; payload["kind"] = kind; payload["id"] = id.uuidString
        _ = try await data("/v1/events", payload, timeout: 8)
    }
    func commands() async throws -> [MobileCommand] {
        struct Envelope: Decodable { let items: [MobileCommand] }
        return try JSONDecoder().decode(Envelope.self, from: await data("/v1/commands")).items
    }
    func receipt(_ command: MobileCommand, state: String, detail: String) async throws {
        _ = try await data("/v1/receipts", ["id": command.id, "state": state, "detail": detail])
    }
}

struct WakeAlarmPlan: Decodable {
    let state: String
    let at: Double?
    let note: String
    let expected_sleep_start: Double?
    let target_hours: Double?
}

private final class NoRedirect: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil) // Pairing credentials never follow a redirect to another endpoint.
    }
}
