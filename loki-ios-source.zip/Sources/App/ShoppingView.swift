import SwiftUI

struct ShoppingView: View {
    @EnvironmentObject private var shopping: ShoppingService
    @State private var key = ""
    @State private var secret = ""
    @State private var adzone = ""
    @State private var query = ""
    @State private var loading = false
    @State private var error: String?
    var body: some View {
        List {
            Section {
                if shopping.configured {
                    Toggle("让 Loki 搜淘宝和挑商品", isOn: $shopping.enabled)
                    Text("授权只保存在这台手机，用于商品查询；商品链接可打开淘宝。价格和优惠以结算页面为准。")
                        .font(.caption).foregroundStyle(.secondary)
                } else {
                    TextField("AppKey", text: $key).textInputAutocapitalization(.never).autocorrectionDisabled()
                    SecureField("AppSecret", text: $secret)
                    TextField("推广位 adzone_id", text: $adzone).keyboardType(.numberPad)
                    Button("保存授权") {
                        do { try shopping.save(key: key, secret: secret, adzone: adzone); key = ""; secret = ""; adzone = "" }
                        catch { self.error = error.localizedDescription }
                    }
                    Link("申请淘宝联盟接口", destination: URL(string: "https://pub.alimama.com/")!)
                    Text("先注册淘宝客并完成媒体备案，再从“APPKEY 申请”创建应用。")
                        .font(.caption).foregroundStyle(.secondary)
                    Text("需要商品物料搜索权限。没有购物车、下单或支付权限。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                if !shopping.status.isEmpty { Text(shopping.status).font(.caption).foregroundStyle(.secondary) }
            }
            if shopping.configured {
                Section {
                    TextField("想找什么", text: $query).submitLabel(.search).onSubmit { search() }
                    Button("搜索淘宝") { search() }.disabled(loading || query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    if loading { ProgressView() }
                }
                Section {
                    ForEach(Array(shopping.products.enumerated()), id: \.offset) { _, product in
                        VStack(alignment: .leading, spacing: 6) {
                            Text(product.title)
                            if !product.shop.isEmpty { Text(product.shop).font(.caption).foregroundStyle(.secondary) }
                            if !product.price.isEmpty { Text("¥" + product.price) }
                            if let url = product.link { Link("查看商品", destination: url) }
                        }.padding(.vertical, 4)
                    }
                }
                Section { Button("移除淘宝授权", role: .destructive) { shopping.disconnect() } }
            }
        }.navigationTitle("淘宝")
            .alert("淘宝", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("知道了", role: .cancel) { error = nil }
            } message: { Text(error ?? "") }
    }
    private func search() {
        guard !loading, !query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        loading = true
        Task { defer { loading = false }; do { try await shopping.search(query) } catch { self.error = error.localizedDescription } }
    }
}
