import Foundation
import Combine
import AVFoundation
import MediaPlayer

@MainActor final class MusicService: ObservableObject {
    static let shared = MusicService()
    let client = NetEaseClient()
    @Published private(set) var connected = false
    @Published private(set) var nickname = ""
    private var uid = ""
    private var authorizationEpoch = UUID()
    private var restoreTask: Task<Void, Error>?
    private var knownPlaylists: [MusicPlaylist] = []
    @Published private(set) var current: MusicSong?
    @Published private(set) var queue: [MusicSong] = []
    @Published private(set) var playing = false
    @Published private(set) var mode = MusicPlaybackMode(rawValue: UserDefaults.standard.string(forKey: "musicPlaybackMode") ?? "order") ?? .order
    private var shuffleRemaining: [Int] = []
    @Published private(set) var playbackPending = false
    private var playbackFailure: String?
    @Published private(set) var elapsed: Double = 0
    @Published private(set) var duration: Double = 0
    @Published var status = "尚未连接网易云"
    @Published var error: String?
    @Published var autonomy = UserDefaults.standard.object(forKey: "musicAutonomy") as? Bool ?? true {
        didSet { UserDefaults.standard.set(autonomy, forKey: "musicAutonomy") }
    }
    @Published var companion = UserDefaults.standard.object(forKey: "musicCompanion") as? Bool ?? true {
        didSet { UserDefaults.standard.set(companion, forKey: "musicCompanion"); if !companion { events = [] } }
    }
    private let player = AVPlayer()
    private var observation: AnyCancellable?
    private var itemObservation: AnyCancellable?
    private var timeObserver: Any?
    private var endObserver: NSObjectProtocol?
    private var cursor = 0
    private(set) var epoch = UUID()
    private var announcedStart = false
    private var offerStartConversation = true
    private var milestone = 0
    private var speaking = false
    private var musicGain: Float = 0.85
    private var gainTask: Task<Void, Never>?
    private var callRestoreTask: Task<Void, Never>?
    private struct CallMusicSnapshot {
        let id: UUID
        var wasPlaying: Bool
        let route: [String]
        let outputVolume: Float
        let gain: Float
    }
    private var callMusic: CallMusicSnapshot?
    private var restoringCallMusic = false
    private var lyrics = ""
    private var events: [MusicEvent] = []
    private var lastOpportunity = Date.distantPast
    private var recentComments: [String] = []
    private var claims: [String] = PrivateFiles.load("music-action-claims.json", fallback: [])
    private(set) var lastReceipt = ""
    private var known: [String: MusicSong] = [:]
    private var remoteTargets: [(MPRemoteCommand, Any)] = []

    private init() {
        observation = player.publisher(for: \.timeControlStatus).receive(on: DispatchQueue.main).sink { [weak self] value in
            Task { @MainActor in self?.changed(value) }
        }
        timeObserver = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 1, preferredTimescale: 600), queue: .main) { [weak self] time in
            Task { @MainActor in self?.tick(time.seconds) }
        }
        let center = MPRemoteCommandCenter.shared()
        remoteTargets.append((center.playCommand, center.playCommand.addTarget { [weak self] _ in
            Task { @MainActor in await self?.resume() }; return .success
        }))
        remoteTargets.append((center.pauseCommand, center.pauseCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.pause() }; return .success
        }))
        remoteTargets.append((center.nextTrackCommand, center.nextTrackCommand.addTarget { [weak self] _ in
            Task { @MainActor in await self?.next() }; return .success
        }))
    }
    func connect(cookies: [HTTPCookie]) async throws {
        let approved = MusicLoginPolicy.approvedCookies(cookies)
        guard approved.contains(where: { $0.name == "MUSIC_U" && !$0.value.isEmpty }) else {
            throw LokiError.message("还未读到网易云网页登录，请在网页登录完成后再点“连接”。")
        }
        let before = MusicCredential.read()
        try MusicCredential.save(approved.map { "\($0.name)=\($0.value)" }.joined(separator: "; "))
        do { try await restore() }
        catch { try? MusicCredential.save(before); throw error }
    }
    func restore() async throws {
        guard !MusicCredential.read().isEmpty else { return }
        let generation = authorizationEpoch
        let account = try await client.account()
        guard generation == authorizationEpoch else { throw CancellationError() }
        uid = account.0; nickname = account.1; connected = true
        status = "已连接 · \(account.1)"
    }
    func prepareForChat() async {
        guard !connected, !MusicCredential.read().isEmpty else { return }
        if let restoreTask { _ = try? await restoreTask.value; return }
        let task = Task { @MainActor in try await self.restore() }
        restoreTask = task
        defer { restoreTask = nil }
        do { try await task.value }
        catch { status = "网易云连接暂未恢复，请到一起听查看授权与网络。" }
    }
    func disconnect() {
        authorizationEpoch = UUID()
        stop(); try? MusicCredential.save("")
        connected = false; uid = ""; nickname = ""; known = [:]; queue = []; events = []
        status = "已断开网易云"
    }
    func playlists() async throws -> [MusicPlaylist] {
        let values = try await client.playlists(uid: uid); knownPlaylists = values; return values
    }
    func remember(_ songs: [MusicSong]) {
        for song in songs { known[song.id] = song }
        if known.count > 300 { known = Dictionary(songs.map { ($0.id, $0) }, uniquingKeysWith: { _, b in b }) }
    }
    func playQueue(_ songs: [MusicSong], from index: Int = 0, offerStart: Bool = true) async {
        guard songs.indices.contains(index) else { return }
        queue = songs; cursor = index; remember(songs); shuffleRemaining = []
        await play(songs[index], offerStart: offerStart)
    }
    private func play(_ song: MusicSong, offerStart: Bool = true) async {
        let generation = UUID(); epoch = generation
        player.pause(); player.replaceCurrentItem(with: nil); playing = false; announcedStart = false; milestone = 0
        current = song; elapsed = 0; duration = song.duration; lyrics = ""
        offerStartConversation = offerStart
        playbackPending = true; playbackFailure = nil; error = nil
        status = "正在打开歌曲…"
        do {
            let url = try await client.playable(song.id)
            guard epoch == generation, connected else { return }
            try await PhoneAudioSession.shared.musicPlayback()
            guard epoch == generation else { return }
            let item = AVPlayerItem(url: url)
            if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
            endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main) { [weak self] _ in
                Task { @MainActor in
                    guard let self, self.epoch == generation else { return }
                    self.offer("ended", song: song); await self.advance(ended: true)
                }
            }
            itemObservation = item.publisher(for: \.status).receive(on: DispatchQueue.main).sink { [weak self] state in
                Task { @MainActor in
                    guard let self, self.epoch == generation else { return }
                    if state == .failed {
                        let note = MusicPlaybackPolicy.playerError(self.player.currentItem?.error as NSError?)
                        self.pause(); self.status = "歌曲播放失败"; self.playbackFailure = note; self.error = note
                    }
                }
            }
            player.replaceCurrentItem(with: item); player.volume = speaking ? min(musicGain, 0.18) : musicGain; player.play()
            Task { [weak self, client] in
                let value = try? await client.lyrics(song.id)
                guard let self, self.epoch == generation else { return }
                self.lyrics = value ?? ""
            }
        } catch {
            guard epoch == generation else { return }
            pause(); status = "未能播放这首歌"; playbackFailure = error.localizedDescription; self.error = error.localizedDescription
        }
    }
    func resume() async {
        guard current != nil else { return }
        do { try await PhoneAudioSession.shared.musicPlayback(); player.play() }
        catch { self.error = error.localizedDescription }
    }
    func pause() {
        callRestoreTask?.cancel(); callMusic?.wasPlaying = false
        player.pause(); playing = false; playbackPending = false
        PhoneAudioSession.shared.musicStopped()
        updateNowPlaying()
    }
    func stop() {
        epoch = UUID(); pause(); player.replaceCurrentItem(with: nil)
        current = nil; elapsed = 0; events = []
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
    }
    func next(offerStart: Bool = true) async {
        await advance(ended: false, offerStart: offerStart)
    }
    private func advance(ended: Bool, offerStart: Bool = true) async {
        if mode == .shuffle && shuffleRemaining.isEmpty {
            shuffleRemaining = queue.indices.filter { $0 != cursor }.shuffled()
        }
        let pick = mode == .shuffle ? shuffleRemaining.last : nil
        if let index = mode.nextIndex(count: queue.count, current: cursor, ended: ended, shuffled: pick) {
            if mode == .shuffle && !shuffleRemaining.isEmpty { shuffleRemaining.removeLast() }
            let repeatedSameSong = ended && index == cursor
            cursor = index; await play(queue[index], offerStart: offerStart && !repeatedSameSong)
        } else { pause(); status = "本次队列已播放完" }
    }
    func setMode(_ value: MusicPlaybackMode) {
        mode = value; shuffleRemaining = []
        UserDefaults.standard.set(value.rawValue, forKey: "musicPlaybackMode")
        lastReceipt = "手机已设置播放模式：\(value.title)"
    }
    func applyModeRequest(_ message: String) {
        guard connected, autonomy, let requested = MusicPlaybackMode.requested(message) else { return }
        setMode(requested)
    }
    func seek(_ seconds: Double) {
        guard seconds.isFinite, duration > 0 else { return }
        player.seek(to: CMTime(seconds: min(max(0, seconds), duration), preferredTimescale: 600))
    }
    func voiceSpeaking(_ value: Bool) {
        speaking = value
        guard callMusic == nil, !restoringCallMusic else { return }
        fadeGain(to: value ? min(musicGain, 0.18) : musicGain)
    }
    private func fadeGain(to target: Float) {
        gainTask?.cancel()
        let start = player.volume
        gainTask = Task { @MainActor [weak self] in
            for step in 1...16 {
                do { try await Task.sleep(for: .milliseconds(50)); try Task.checkCancellation() } catch { return }
                self?.player.volume = MusicCallRestorePolicy.gain(start: start, target: target, step: step)
            }
        }
    }
    private func routeSignature() -> [String] {
        AVAudioSession.sharedInstance().currentRoute.outputs.map { $0.portType.rawValue + ":" + $0.uid }
    }
    func callBegan() {
        callRestoreTask?.cancel(); gainTask?.cancel(); restoringCallMusic = false
        let shouldPause = playing || playbackPending
        let snapshot = CallMusicSnapshot(id: UUID(), wasPlaying: shouldPause, route: routeSignature(),
            outputVolume: AVAudioSession.sharedInstance().outputVolume, gain: musicGain)
        if shouldPause { pause(); status = "通话中，音乐已暂停" }
        callMusic = snapshot
    }
    func callEnded() {
        guard let snapshot = callMusic else { return }
        callMusic = nil
        guard snapshot.wasPlaying, current != nil else { return }
        restoringCallMusic = true
        callRestoreTask = Task { @MainActor [weak self] in
            guard let self else { return }
            defer { if self.callMusic == nil { self.restoringCallMusic = false } }
            do {
                try await PhoneAudioSession.shared.musicPlayback()
                try await Task.sleep(for: .milliseconds(250)); try Task.checkCancellation()
                guard self.callMusic == nil else { return }
                guard MusicCallRestorePolicy.canResume(wasPlaying: snapshot.wasPlaying, beforeRoute: snapshot.route,
                    afterRoute: self.routeSignature(), beforeVolume: snapshot.outputVolume,
                    afterVolume: AVAudioSession.sharedInstance().outputVolume) else {
                    self.pause(); self.status = "输出设备或音量已变化，音乐保持暂停；点继续播放。"; return
                }
                self.musicGain = snapshot.gain; self.player.volume = 0
                self.player.play(); self.fadeGain(to: self.speaking ? min(self.musicGain, 0.18) : self.musicGain)
            } catch {
                if !(error is CancellationError) { self.pause(); self.status = "音乐保持暂停；点继续播放。" }
            }
        }
    }
    private func changed(_ value: AVPlayer.TimeControlStatus) {
        guard value == player.timeControlStatus else { return }
        playing = value == .playing
        if playing {
            playbackPending = false; playbackFailure = nil; error = nil
            status = "正在播放"
            if !announcedStart, let song = current {
                announcedStart = true
                if offerStartConversation { offer("started", song: song) }
            }
        } else if value == .waitingToPlayAtSpecifiedRate { playbackPending = true; status = "正在缓冲歌曲…" }
        updateNowPlaying()
    }
    private func tick(_ seconds: Double) {
        guard current != nil, seconds.isFinite else { return }
        let position = max(0, seconds)
        if abs(elapsed - position) >= 0.2 { elapsed = position }
        if let time = player.currentItem?.duration.seconds, time.isFinite, time > 0, duration != time { duration = time }
        if playing, elapsed >= 30, Int(elapsed / 60) + 1 > milestone, let song = current {
            milestone = Int(elapsed / 60) + 1; offer("progress", song: song)
        }
        updateNowPlaying()
    }
    private func updateNowPlaying() {
        guard let song = current else { return }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [MPMediaItemPropertyTitle: song.title,
            MPMediaItemPropertyArtist: song.artist, MPMediaItemPropertyPlaybackDuration: duration,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: elapsed, MPNowPlayingInfoPropertyPlaybackRate: playing ? 1 : 0]
    }
    private func offer(_ kind: String, song: MusicSong) {
        guard companion, MusicPolicy.opportunity(secondsSinceLast: Date().timeIntervalSince(lastOpportunity), draw: Double.random(in: 0..<1)) else { return }
        lastOpportunity = Date()
        events.append(.init(id: UUID(), kind: kind, epoch: epoch, song: song))
        events = Array(events.suffix(2))
    }
    func takeEvent() -> MusicEvent? {
        // A delayed start/progress from a replaced song is not a new conversation.
        events.removeAll { $0.kind != "ended" && $0.epoch != epoch }
        guard connected, companion, !events.isEmpty else { return nil }
        return events.removeFirst()
    }
    func recordComment(_ text: String) { recentComments.append(String(text.prefix(700))); recentComments = Array(recentComments.suffix(4)) }
    var context: [String: Any] {
        var value: [String: Any] = ["connected": connected, "autonomy_enabled": autonomy, "companion_enabled": companion,
            "playing": playing, "elapsed_seconds": elapsed, "duration_seconds": duration,
            "playback_epoch": epoch.uuidString, "audio_analysis_available": false,
            "known_song_ids": Array(known.keys.prefix(60)), "recent_comments": recentComments,
            "last_receipt": lastReceipt, "playback_mode": mode.rawValue, "mode_control_available": true]
        if let song = current { value["current"] = ["id": song.id, "title": song.title, "artist": song.artist] }
        value["queue"] = queue.prefix(12).map { ["id": $0.id, "title": $0.title, "artist": $0.artist] }
        value["catalog"] = known.values.prefix(20).map { ["id": $0.id, "title": $0.title, "artist": $0.artist] }
        value["playlists"] = knownPlaylists.prefix(20).map { ["id": $0.id, "name": $0.name] }
        if !lyrics.isEmpty { value["lyrics_excerpt"] = String(lyrics.prefix(1800)) }
        return value
    }
    func apply(_ action: MusicAction) async -> (Bool, String) {
        guard connected, autonomy, Date().timeIntervalSince1970 < action.expires else { return (false, "音乐操作未执行：授权未开启或请求已过期。") }
        guard !claims.contains(action.id.uuidString) else { return (false, "这项音乐操作已处理，没有重复执行。") }
        claims.append(action.id.uuidString)
        do { try PrivateFiles.save(claims, "music-action-claims.json") }
        catch { return (false, "无法保存音乐操作记录，未执行。") }
        do {
            switch action.action {
            case "set_mode":
                guard let raw = action.mode, let value = MusicPlaybackMode(rawValue: raw) else { throw LokiError.message("不支持这个播放模式。") }
                setMode(value)
            case "search_play":
                let songs = try await client.search(action.query ?? "")
                let candidates = MusicPlaybackPolicy.candidates(songs)
                guard !candidates.isEmpty else { throw LokiError.message("没有找到这首歌曲；请补充歌名或歌手。") }
                for song in candidates {
                    await playQueue([song], offerStart: false)
                    if playbackFailure == nil { break }
                }
                if !(try await confirmPlayback()) { return (false, "歌曲仍在缓冲，开始播放后会自动更新。") }
            case "play_known":
                guard let id = action.song_id, let song = known[id] else { throw LokiError.message("这首歌不在本次已读取的音乐范围内。") }
                await playQueue([song], offerStart: false)
                if !(try await confirmPlayback()) { return (false, "歌曲仍在缓冲，开始播放后会自动更新。") }
            case "next":
                guard !queue.isEmpty else { throw LokiError.message("队列里没有歌曲。") }
                await next(offerStart: false)
                if !(try await confirmPlayback()) { return (false, "下一首仍在缓冲。") }
            case "pause": pause()
            case "resume":
                await resume()
                if !(try await confirmPlayback()) { return (false, "歌曲仍在缓冲。") }
            case "like":
                guard let id = action.song_id, known[id] != nil || current?.id == id else { throw LokiError.message("没有核实要收藏的歌曲。") }
                try await client.like(id)
            case "create_playlist":
                let name = action.name ?? "Loki"
                let id = try await client.createPlaylist(name)
                knownPlaylists.append(.init(id: id, name: name, count: 0))
            case "add_to_playlist":
                guard let song = action.song_id, known[song] != nil, let playlist = action.playlist_id,
                      (try await playlists()).contains(where: { $0.id == playlist }) else { throw LokiError.message("没有核实要添加的歌曲或歌单。") }
                try await client.add(song, playlist: playlist)
            default: throw LokiError.message("不支持这项音乐操作。")
            }
            lastReceipt = "音乐操作已由手机处理：\(action.action)"
            return (true, lastReceipt)
        } catch {
            lastReceipt = "未确认音乐操作成功：\(error.localizedDescription)"
            return (false, lastReceipt)
        }
    }
    private func waitForPlayback() async -> Bool {
        let generation = epoch
        for _ in 0..<100 {
            if playing { return true }
            if playbackFailure != nil { return false }
            guard epoch == generation, !Task.isCancelled else { return false }
            do { try await Task.sleep(for: .milliseconds(100)) } catch { return false }
        }
        return false
    }
    private func confirmPlayback() async throws -> Bool {
        if await waitForPlayback() { return true }
        if let playbackFailure { throw LokiError.message(playbackFailure) }
        if playbackPending { status = "正在缓冲歌曲…"; return false }
        throw LokiError.message("歌曲播放已停止，未确认开始播放。")
    }
}
