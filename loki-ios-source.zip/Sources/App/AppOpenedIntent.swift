import AppIntents
import Foundation
import SwiftUI
import UIKit

struct AppOpenedToLokiIntent: AppIntent {
    static var title: LocalizedStringResource = "告诉 Loki 我打开了应用"
    static var description = IntentDescription("由你设置的应用打开自动化触发；有未回复的 Loki 消息时请他联系你。")
    static var openAppWhenRun = false

    @Parameter(title: "应用备注")
    var appName: String

    static var parameterSummary: some ParameterSummary {
        Summary("告诉 Loki 我打开了 \(\.$appName)")
    }

    func perform() async throws -> some IntentResult {
        let name = appName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, name.count <= 80 else {
            throw LokiError.message("请填写应用备注，例如抖音。")
        }
        let api = MobileAPI(base: UserDefaults.standard.string(forKey: "gatewayURL") ?? "",
                            token: SecureToken.read())
        _ = try await api.data("/v1/apps/opened", ["id": UUID().uuidString, "app_name": name], timeout: 8)
        return .result()
    }
}

struct AppAttentionView: View {
    var body: some View {
        Form {
            Section("打开其他应用时联系你") {
                Text("你还没回复 Loki 时，打开指定应用可以请他发来一条消息。回复后，他会停止这次催促。")
                Text("1. 打开 iPhone 的“快捷指令 → 自动化”，新建“App”自动化。")
                Text("2. 选择抖音或其他应用，勾选“打开时”，选择“立即运行”。")
                Text("3. 添加 Loki 的“告诉 Loki 我打开了应用”操作，填写应用备注，例如抖音。")
                Text("4. 保存。其他应用可以分别设置同样的自动化。")
                Text("应用备注由你填写。自动化只告诉 Loki 这个应用被打开，不会读取该应用的画面或聊天内容。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("消息横幅") {
                Text("在系统设置中为 Loki 开启通知和横幅，将“显示预览”设为“始终”或“解锁时”。专注模式和通知摘要可能影响横幅出现的时间。")
                Button("打开 Loki 通知设置") {
                    if let url = URL(string: UIApplication.openNotificationSettingsURLString) {
                        UIApplication.shared.open(url)
                    }
                }
                Text("消息由现有 Loki 模型生成，通过私人接口和推送送达，耗时取决于模型和网络。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("打开应用时联系")
    }
}
