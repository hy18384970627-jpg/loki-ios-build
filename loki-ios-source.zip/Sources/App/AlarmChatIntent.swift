import Foundation

enum AlarmChatIntent {
    case specific(Date), course(day: Date?, lead: Int), wakePlan, confirm, stopCourse, needsTime, none
    static func parse(_ message: String, now: Date = Date(), zone: TimeZone = .current) -> Self {
        let text = message.lowercased()
        let course = text.range(of: "课表|课程|上课|课前|早课|首节课|第一堂课|第一节课|class|timetable", options: .regularExpression) != nil
        // Owner explicitly authorized wake-time questions to schedule, even without
        // the word 'alarm'. Negations/hypotheticals below still take precedence.
        let wakeChoice = text.range(of: "(?:明天|明早|后天).{0,35}(?:几点|什么时候).{0,12}(?:起床|叫醒)|(?:希望|想让|决定|安排|看着办).{0,20}(?:起床|叫醒)|(?:几点|什么时候).{0,12}叫我起床", options: .regularExpression) != nil
        let alarm = text.contains("闹钟") || text.contains("叫醒") || text.contains("alarm") || text.contains("wake me")
        let confirmation = matches(#"^(?:(?:对的|好的|确认这个时间)[，,。\s]*)?(?:帮我|给我|替我|为我)(?:把.{0,8})?(?:订好|定好|设好|设置好)[吧。！!\s]*$"#, in: text).count == 1
        guard alarm || wakeChoice || confirmation else { return .none }
        if course && text.range(of: "关闭|取消|停用|停止|turn off|disable", options: .regularExpression) != nil { return .stopCourse }
        if text.range(of: "取消|关闭|停用|删除|为什么|why", options: .regularExpression) != nil { return .none }
        guard wakeChoice || text.range(of: "帮我|给我|替我|为我|请|设置|设个|设一|设下|定个|订个|定一|订一|设闹钟|定闹钟|订闹钟|叫醒我|set .*alarm|wake me", options: .regularExpression) != nil else { return .none }
        if text.range(of: "不要|不用|别帮|别设|别定|别订|假如|如果|举例|他说|她说|don't|do not", options: .regularExpression) != nil { return .none }
        if text.range(of: "我已经|我刚|我自己|已经.{0,8}(?:设|定|订)|(?:设|定|订)好了|(?:定|订|设)好闹钟了吗", options: .regularExpression) != nil { return .none }
        if wakeChoice { return .wakePlan }
        if confirmation { return .confirm }
        var calendar = Calendar(identifier: .gregorian); calendar.timeZone = zone
        func day(_ offset: Int) -> Date { calendar.date(byAdding: .day, value: offset, to: calendar.startOfDay(for: now))! }
        func capture(_ pattern: String) -> [String]? {
            guard let regex = try? NSRegularExpression(pattern: pattern), let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)) else { return nil }
            return (1..<match.numberOfRanges).map { Range(match.range(at: $0), in: text).map { String(text[$0]) } ?? "" }
        }
        if course {
            let raw = capture("提前([0-9零〇一二两三四五六七八九十]{1,3})(?:分钟|分)")?.first
            let lead = raw.flatMap(number) ?? 40
            guard (5...180).contains(lead) else { return .needsTime }
            if text.contains("明天") { return .course(day: day(1), lead: lead) }
            if text.contains("后天") { return .course(day: day(2), lead: lead) }
            if text.contains("今天") { return .course(day: day(0), lead: lead) }
            return .course(day: nil, lead: lead)
        }
        if text.range(of: "[0-9]{4}[-/][0-9]|星期|周[一二三四五六日天]|下周|下个月|明年|每周|每天|每晚|刻|差.{0,6}点", options: .regularExpression) != nil { return .needsTime }
        let explicitDates = matches("(?<![0-9])(?:(?:([0-9]{4})年)?([0-9]{1,2})月)?([0-9]{1,2})[日号]", in: text)
        guard explicitDates.count <= 1 else { return .needsTime }
        let explicitDate = explicitDates.first
        if explicitDate == nil && text.range(of: "[0-9]+[年月日号]", options: .regularExpression) != nil { return .needsTime }
        if explicitDate == nil, let relative = capture("([0-9零〇一二两三四五六七八九十]{1,3})(分钟|小时|minutes?|hours?)后?"),
           text.contains("后") || text.contains("in "), let count = number(relative[0]) {
            let seconds = count * (relative[1].contains("小时") || relative[1].contains("hour") ? 3600 : 60)
            if (1...86400).contains(seconds) { return .specific(now.addingTimeInterval(Double(seconds))) }
        }
        guard let clock = capture("([0-9零〇一二两三四五六七八九十]{1,3})[点时:：](半|[0-9零〇一二两三四五六七八九十]{1,3})?(?:分)?") else {
            let hasDay = text.range(of: "明天|明早|后天|今天|今早|今晚", options: .regularExpression) != nil
            if explicitDate == nil && (!hasDay || text.contains("确认这个时间")) { return .confirm }
            return .needsTime
        }
        guard var hour = number(clock[0]), (0...23).contains(hour) else { return .needsTime }
        let minute = clock[1] == "半" ? 30 : (clock[1].isEmpty ? 0 : number(clock[1]) ?? -1)
        guard (0...59).contains(minute) else { return .needsTime }
        if text.range(of: "下午|晚上|今晚|傍晚|pm", options: .regularExpression) != nil && hour < 12 { hour += 12 }
        if hour == 12 && text.range(of: "凌晨|午夜|am", options: .regularExpression) != nil { hour = 0 }
        if hour == 12 && text.range(of: "晚上|今晚", options: .regularExpression) != nil { return .needsTime }
        let offset = text.contains("后天") ? 2 : (text.contains("明天") || text.contains("明早")) ? 1 : 0
        var components = calendar.dateComponents([.year, .month, .day], from: day(offset))
        if let explicitDate {
            let year = Int(explicitDate[0]) ?? components.year
            let month = Int(explicitDate[1]) ?? components.month
            let date = Int(explicitDate[2])
            if text.range(of: "明天|明早|后天|今天|今早|今晚", options: .regularExpression) != nil,
               (year != components.year || month != components.month || date != components.day) { return .needsTime }
            components.year = year; components.month = month; components.day = date
        }
        components.hour = hour; components.minute = minute
        guard var date = exactDate(components, calendar: calendar) else { return .needsTime }
        if date <= now {
            if explicitDate == nil && offset == 0 && !text.contains("今天") && !text.contains("今晚") && !text.contains("今早") { date = calendar.date(byAdding: .day, value: 1, to: date)! }
            else { return .needsTime }
        }
        return .specific(date)
    }

    /// A confirmation refers to the immediately preceding alarm reply. Resolve
    /// relative dates at the time of that reply and reject multiple clock times.
    static func confirmedDate(reply: String, previousRequest: String, repliedAt: Date,
                              now: Date = Date(), zone: TimeZone = .current) -> Date? {
        guard now.timeIntervalSince(repliedAt) >= 0, now.timeIntervalSince(repliedAt) <= 20 * 60 else { return nil }
        let previous = previousRequest.lowercased()
        guard previous.range(of: "闹钟|起床|叫醒|alarm|wake", options: .regularExpression) != nil
                || (previous.contains("今天早上") && previous.contains("明天早上")) else { return nil }
        let text = reply.lowercased().replacingOccurrences(of: "’", with: "'")
        var calendar = Calendar(identifier: .gregorian); calendar.timeZone = zone
        let clock = matches(#"\b(\d{1,2}):(\d{2})\s*(am|pm)?\b|\b(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)\s+o'clock\b"#, in: text)
        if clock.isEmpty {
            // Chinese proposals use the same exact calendar checks as direct commands.
            guard text.range(of: "今天|今早|今晚|明天|明早|后天|[0-9]{1,2}[日号]", options: .regularExpression) != nil,
                  matches("[0-9零〇一二两三四五六七八九十]{1,3}[点时:：]", in: text).count == 1,
                  case .specific(let date) = parse("帮我设闹钟 " + text, now: repliedAt, zone: zone),
                  date > now else { return nil }
            return date
        }
        guard clock.count == 1, let time = clock.first else { return nil }
        let hours = ["one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve"]
        guard var hour = Int(time[0]) ?? hours.firstIndex(of: time[3]).map({ $0 + 1 }) else { return nil }
        let minute = Int(time[1]) ?? 0
        let am = time[2] == "am" || text.contains("morning")
        let pm = time[2] == "pm" || text.contains("evening") || text.contains("afternoon")
        guard !(am && pm), (am || pm || hour > 12 || hour == 0), (0...23).contains(hour), (0...59).contains(minute) else { return nil }
        if pm && hour < 12 { hour += 12 }
        if am && hour == 12 { hour = 0 }
        let today = text.range(of: #"\btoday\b|\bthis morning\b"#, options: .regularExpression) != nil
        let tomorrow = text.range(of: #"\btomorrow\b"#, options: .regularExpression) != nil
        let midnightAlias = previous.contains("是今天早上") && previous.contains("称作明天早上")
        guard !(today && tomorrow && !midnightAlias) else { return nil }
        let months = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"]
        let dates = matches("\\b(" + months.joined(separator: "|") + ")\\s+(\\d{1,2})(?:st|nd|rd|th)?\\b", in: text)
        guard dates.count <= 1, today || tomorrow || !dates.isEmpty else { return nil }
        let offset = tomorrow && !midnightAlias ? 1 : 0
        let anchor = calendar.startOfDay(for: repliedAt)
        guard let day = calendar.date(byAdding: .day, value: offset, to: anchor) else { return nil }
        var components = calendar.dateComponents([.year, .month, .day], from: day)
        if let date = dates.first, let month = months.firstIndex(of: date[0]), let number = Int(date[1]) {
            if today || tomorrow {
                guard components.month == month + 1, components.day == number else { return nil }
            }
            components.month = month + 1; components.day = number
        }
        components.hour = hour; components.minute = minute
        guard let date = exactDate(components, calendar: calendar), date > now else { return nil }
        return date
    }

    private static func exactDate(_ components: DateComponents, calendar: Calendar) -> Date? {
        let fields: Set<Calendar.Component> = [.year, .month, .day, .hour, .minute]
        guard let date = calendar.date(from: components),
              fields.allSatisfy({ calendar.component($0, from: date) == components.value(for: $0) }) else { return nil }
        return date
    }

    private static func matches(_ pattern: String, in text: String) -> [[String]] {
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return [] }
        return regex.matches(in: text, range: NSRange(text.startIndex..., in: text)).map { match in
            (1..<match.numberOfRanges).map { Range(match.range(at: $0), in: text).map { String(text[$0]) } ?? "" }
        }
    }
    private static func number(_ text: String) -> Int? {
        if let value = Int(text) { return value }
        let digits: [Character: Int] = ["零":0,"〇":0,"一":1,"二":2,"两":2,"三":3,"四":4,"五":5,"六":6,"七":7,"八":8,"九":9]
        if text == "十" { return 10 }
        if let index = text.firstIndex(of: "十") {
            let first = String(text[..<index]), last = String(text[text.index(after: index)...])
            guard let tens = first.isEmpty ? 1 : first.first.flatMap({ digits[$0] }),
                  let ones = last.isEmpty ? 0 : last.first.flatMap({ digits[$0] }) else { return nil }
            return tens * 10 + ones
        }
        return text.count == 1 ? text.first.flatMap { digits[$0] } : nil
    }
}
