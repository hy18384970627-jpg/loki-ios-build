import Foundation

enum SleepIntervals {
    struct Interval { let start: Date; let end: Date }
    struct Session { let start: Date; let end: Date; let duration: TimeInterval }
    static func mainSession(_ input: [Interval]) -> Session? {
        let values = sessions(input)
        return values.last(where: { $0.duration >= 3 * 3600 }) ?? values.last
    }
    static func sessions(_ input: [Interval]) -> [Session] {
        let sorted = input.filter { $0.end > $0.start }.sorted { $0.start < $1.start }
        var merged: [Interval] = []
        for interval in sorted {
            if let last = merged.last, interval.start <= last.end {
                merged[merged.count - 1] = .init(start: last.start, end: max(last.end, interval.end))
            } else { merged.append(interval) }
        }
        var sessions: [Session] = []
        for interval in merged {
            if let last = sessions.last, interval.start.timeIntervalSince(last.end) <= 90 * 60 {
                sessions[sessions.count - 1] = .init(start: last.start, end: interval.end,
                    duration: last.duration + interval.end.timeIntervalSince(interval.start))
            } else {
                sessions.append(.init(start: interval.start, end: interval.end,
                    duration: interval.end.timeIntervalSince(interval.start)))
            }
        }
        return sessions
    }
}
