import Foundation

struct ChatItem: Identifiable, Codable {
    let id: UUID
    let role: String
    var text: String
    var speechText: String?
    var localActionNote: String? = nil
    var wallpaperAsset: String? = nil
    var wallpaperChangeID: String? = nil
    var recordedVoice: RecordedVoice? = nil
    var delivery: MessageDelivery? = nil
    var deliveryError: String? = nil
    var acceptedByServer: Bool? = nil
    var replyingTo: UUID? = nil
    var careEventID: String? = nil
    let date: Date
    init(role: String, text: String, id: UUID = UUID(), speechText: String? = nil) {
        self.id = id; self.role = role; self.text = text; self.date = Date()
        self.speechText = speechText
    }
    var displayText: String {
        guard role == "assistant" else { return text }
        return Self.visible(text)
    }
    private static func visible(_ text: String) -> String {
        text.replacingOccurrences(of: #"\((?:laugh|sigh)\)"#, with: "", options: .regularExpression)
            .replacingOccurrences(of: #"[ \t]{2,}"#, with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
    var voiceText: String {
        guard role == "assistant", let speechText else { return text }
        // Historical records must not read a hidden longer paragraph for one bubble.
        return Self.visible(speechText) == Self.visible(text) ? speechText : text
    }
}

struct TaskCard: Identifiable, Codable {
    let id: UUID
    var title: String
    var due: Date
    var submission: String
    var submittedAt: Date?
    init(title: String, due: Date) {
        id = UUID(); self.title = title; self.due = due; submission = ""
    }
}

struct MobileCommand: Codable, Identifiable {
    let id: String
    let name: String
    let arguments: [String: JSONValue]
    let expires: Double
    var valid: Bool { expires > Date().timeIntervalSince1970 }
    var summary: String {
        arguments.sorted { $0.key < $1.key }.map { "\($0.key): \($0.value.display)" }.joined(separator: "\n")
    }
}

enum JSONValue: Codable {
    case string(String), number(Double), bool(Bool), null
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if container.decodeNil() { self = .null }
        else if let value = try? container.decode(Bool.self) { self = .bool(value) }
        else if let value = try? container.decode(Double.self) { self = .number(value) }
        else { self = .string(try container.decode(String.self)) }
    }
    func encode(to encoder: Encoder) throws {
        var value = encoder.singleValueContainer()
        switch self {
        case .string(let s): try value.encode(s)
        case .number(let n): try value.encode(n)
        case .bool(let b): try value.encode(b)
        case .null: try value.encodeNil()
        }
    }
    var display: String {
        switch self {
        case .string(let s): return s
        case .number(let n): return String(n)
        case .bool(let b): return b ? "true" : "false"
        case .null: return "null"
        }
    }
    var number: Double? { if case .number(let n) = self { return n }; return nil }
    var string: String? { if case .string(let s) = self { return s }; return nil }
}

enum LokiError: LocalizedError {
    case message(String)
    case speechNotClear
    case replyGenerationFailed(String)
    var errorDescription: String? {
        if case .message(let s) = self { return s }
        if case .replyGenerationFailed(let s) = self { return s }
        return "没听清，请再说一遍。"
    }
}
