#if targetEnvironment(simulator)
import SwiftUI

/// Explicit simulator launch route for review screenshots. No paired account or fixtures on devices.
struct LokiDesignPreview: View {
    static var launchTab: Int? {
        let args = ProcessInfo.processInfo.arguments
        if args.contains("--loki-design-chat") { return 0 }
        if args.contains("--loki-design-health") { return 2 }
        if args.contains("--loki-design-desk") { return 3 }
        return nil
    }

    @State private var tab: Int
    @State private var messages: [ChatItem]
    private let sleep: SleepDetails
    private let readings: [HealthReading]
    private let history: [HealthMetric: [HealthDay]]

    init(tab: Int) {
        _tab = State(initialValue: tab)
        var recording = ChatItem(role: "user", text: "")
        recording.recordedVoice = RecordedVoice(id: UUID(), duration: 9)
        _messages = State(initialValue: [
            ChatItem(role: "user", text: "今天有点累，想在这里坐一会儿。"),
            ChatItem(role: "assistant", text: "Then sit with me a while. The world can wait."),
            ChatItem(role: "assistant", text: "Tell me what kind of evening you need."),
            recording,
            ChatItem(role: "assistant", text: "I hear you. Take your time.")
        ])

        let calendar = Calendar.current
        let day = calendar.startOfDay(for: .now)
        let start = day.addingTimeInterval(-35 * 60)
        let end = start.addingTimeInterval(8 * 3600)
        let stages: [(String, Double)] = [
            ("core", 0.16), ("deep", 0.17), ("core", 0.16), ("rem", 0.12),
            ("awake", 0.025), ("core", 0.17), ("rem", 0.13), ("core", 0.065)
        ]
        var cursor = start
        let periods = stages.map { name, share in
            let next = cursor.addingTimeInterval(8 * 3600 * share)
            defer { cursor = next }
            return SleepStagePeriod(stage: name, startAt: cursor, endAt: next)
        }
        sleep = SleepDetails(startAt: start, endAt: end, source: "预览样本", periods: periods, followingAwake: nil)
        let observed = day.addingTimeInterval(8 * 3600 + 35 * 60)
        readings = [
            .init(id: "steps", title: "今日步数", value: 2698, unit: "步", recordedAt: observed, source: "预览样本"),
            .init(id: "sleep", title: "最近睡眠", value: 468, unit: "分钟", recordedAt: end,
                  source: "预览样本", startAt: start, endAt: end),
            .init(id: "heart", title: "最近心率", value: 67, unit: "次/分", recordedAt: observed, source: "预览样本"),
            .init(id: "hrv", title: "最近 HRV", value: 42, unit: "毫秒", recordedAt: observed, source: "预览样本")
        ]

        let samples: [HealthMetric: [Double?]] = [
            .sleep: [6.6, 7.1, nil, 7.2, 7.7, 7.1, 8.1, 7.2, 6.9, 7.4, 7.1, 8.0, 7.2, 7.8],
            .steps: [4300, 3700, 6200, nil, 4812, 6081, 4503, 2883, 4286, nil, 4704, 3669, 5020, 2698],
            .heart: [72, 73, 70, 71, 69, 67, 71, 68, 75, nil, 70, 71, 68, 67],
            .hrv: [31, 35, 36, 28, 33, 41, 45, 37, 32, nil, 39, 44, 38, 42]
        ]
        history = samples.mapValues { values in
            var segment = 0
            return values.enumerated().map { index, value in
                defer { if value == nil { segment += 1 } }
                return HealthDay(date: calendar.date(byAdding: .day, value: index - values.count + 1, to: day)!,
                                 value: value, segment: segment)
            }
        }
    }

    var body: some View {
        TabView(selection: $tab) {
            ChatView(previewMessages: messages)
                .tabItem { Label("Loki", systemImage: "bubble.left.and.bubble.right") }.tag(0)
            Color.clear.tabItem { Label("生活", systemImage: "sparkles") }.tag(1)
            NavigationStack {
                HealthDashboard(readings: readings, sleep: sleep, busy: false, message: "预览样本",
                                lastSynced: nil, trends: history.mapValues { Array($0.suffix(7)) }, authorize: {}) { metric in
                    if metric == .sleep {
                        HealthSleepPage(details: sleep)
                    } else {
                        HealthTrendView(metric: metric, previewEntries: history[metric] ?? [])
                    }
                } settings: { Text("预览样本") }
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Text("预览").font(.caption).foregroundStyle(LokiDesign.gold) } }
            }.tabItem { Label("健康", systemImage: "heart") }.tag(2)
            NavigationStack {
                DeskRoom(envelope: Self.deskSample, error: nil, refreshing: false, sceneActive: tab == 3, refresh: {})
            }.tabItem { Label("书房", systemImage: "books.vertical") }.tag(3)
            Color.clear.tabItem { Label("设置", systemImage: "gearshape") }.tag(4)
        }
        .preferredColorScheme(.dark)
        .tint(LokiDesign.gold)
    }

    private static var deskSample: DeskEnvelope {
        let now = Date().timeIntervalSince1970
        let desk = DeskData(
            schema: "loki_desk_v1",
            interests: [.init(id: "maps", title: "Maps of Imaginary Cities",
                              reason: "A good map should leave room for the streets nobody admits exist.",
                              status: "active", updated: now)],
            projects: [.init(id: "window", title: "Notes by the North Window", interest_id: "maps",
                             status: "active", updated: now)],
            revisions: [.init(id: 1, project_id: "window", created: now, kind: "original",
                              body: "The moon is late. I have left the lamp on anyway.\n\nBelow the window, the hills have all but disappeared. A small light remains on the other side of the valley. I wonder who is keeping watch.",
                              source_ids: [])],
            sessions: [.init(action: "revise", note: "I kept the last line and struck out the rest. It can wait until morning.",
                             started: now - 720, finished: now, next_at: 0)],
            next_at: 0
        )
        return DeskEnvelope(data: desk, revision: "preview", synced_at: now, source_updated_at: now)
    }
}
#endif
