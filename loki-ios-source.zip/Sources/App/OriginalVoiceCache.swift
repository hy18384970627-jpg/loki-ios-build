import Foundation

enum PCMVoiceFile {
    // Wrap the exact streamed samples; no resynthesis, resampling or voice change.
    static func wave(_ pcm: Data) -> Data? {
        guard !pcm.isEmpty, pcm.count.isMultiple(of: 2), pcm.count <= 24_000 * 2 * 120 else { return nil }
        var data = Data()
        func word(_ value: UInt16) {
            var little = value.littleEndian
            withUnsafeBytes(of: &little) { data.append(contentsOf: $0) }
        }
        func dword(_ value: UInt32) {
            var little = value.littleEndian
            withUnsafeBytes(of: &little) { data.append(contentsOf: $0) }
        }
        data.append(contentsOf: "RIFF".utf8); dword(UInt32(36 + pcm.count))
        data.append(contentsOf: "WAVEfmt ".utf8); dword(16)
        word(1); word(1); dword(24_000); dword(48_000); word(2); word(16)
        data.append(contentsOf: "data".utf8); dword(UInt32(pcm.count)); data.append(pcm)
        return data
    }
}

#if os(iOS)
import CryptoKit

enum OriginalVoiceCache {
    private static let maximumBytes = 64 * 1024 * 1024
    private static func folder() throws -> URL {
        // Keep old erroneous audio untouched; use only new verbatim-route audio.
        let folder = try PrivateFiles.url("original-voice-cache-verbatim-v3")
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true,
                                               attributes: [.protectionKey: FileProtectionType.complete])
        return folder
    }
    private static func file(_ id: UUID, text: String) throws -> URL {
        let hash = SHA256.hash(data: Data(text.utf8)).map { String(format: "%02x", $0) }.joined()
        return try folder().appendingPathComponent(id.uuidString + "-" + hash + ".wav")
    }
    static func read(_ id: UUID, text: String) -> Data? {
        guard let file = try? file(id, text: text),
              let size = try? file.resourceValues(forKeys: [.fileSizeKey]).fileSize,
              size > 44, size <= 24_000 * 2 * 120 + 44,
              let data = try? Data(contentsOf: file), data.prefix(4) == Data("RIFF".utf8) else { return nil }
        return data
    }
    static func save(_ pcm: Data, messageID: UUID, text: String) throws {
        guard let wave = PCMVoiceFile.wave(pcm) else { return }
        let output = try file(messageID, text: text)
        try wave.write(to: output, options: [.atomic, .completeFileProtection])
        // Evict only this bounded audio cache. Chat records and all other files stay untouched.
        let root = output.deletingLastPathComponent().standardizedFileURL
        let urls = try FileManager.default.contentsOfDirectory(at: root,
            includingPropertiesForKeys: [.isRegularFileKey, .fileSizeKey, .contentModificationDateKey])
        var entries: [(URL, Int, Date)] = []
        for url in urls where url.pathExtension == "wav" && url.standardizedFileURL.deletingLastPathComponent() == root {
            let values = try url.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey, .contentModificationDateKey])
            if values.isRegularFile == true { entries.append((url, values.fileSize ?? 0, values.contentModificationDate ?? .distantPast)) }
        }
        var total = entries.reduce(0) { $0 + $1.1 }
        for entry in entries.sorted(by: { $0.2 < $1.2 }) where total > maximumBytes {
            guard entry.0 != output else { continue }
            try FileManager.default.removeItem(at: entry.0); total -= entry.1
        }
    }
}
#endif
