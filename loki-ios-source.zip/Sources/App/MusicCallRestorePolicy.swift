import Foundation

enum MusicCallRestorePolicy {
    static func gain(start: Float, target: Float, step: Int, total: Int = 16) -> Float {
        guard start.isFinite, target.isFinite, total > 0 else { return 0 }
        let fraction = Float(min(max(step, 0), total)) / Float(total)
        return min(1, max(0, start + (target - start) * fraction))
    }
    static func canResume(wasPlaying: Bool, beforeRoute: [String], afterRoute: [String],
                          beforeVolume: Float, afterVolume: Float) -> Bool {
        wasPlaying && !beforeRoute.isEmpty && beforeRoute == afterRoute
            && beforeVolume.isFinite && afterVolume.isFinite
            && (0...1).contains(beforeVolume) && (0...1).contains(afterVolume)
            && afterVolume <= beforeVolume + 0.03
    }
}
