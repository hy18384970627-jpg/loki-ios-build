import SwiftUI
import WebKit

struct MusicView: View {
    @EnvironmentObject private var music: MusicService
    @State private var login = false
    @State private var query = ""
    @State private var songs: [MusicSong] = []
    @State private var playlists: [MusicPlaylist] = []
    @State private var loading = false
    @State private var seek: Double = 0
    var body: some View {
        List {
            Section {
                if music.connected {
                    Label(music.nickname, systemImage: "person.crop.circle.badge.checkmark")
                    Toggle("让 Loki 选歌、切歌和收藏", isOn: $music.autonomy)
                    Toggle("让 Loki 自己决定何时聊音乐", isOn: $music.companion)
                    Text("不要求每首都点评。他说话时音乐会轻一点，说完恢复。收藏会加入当前网易云账号。")
                        .font(.caption).foregroundStyle(.secondary)
                } else {
                    Text("在手机上连接网易云，一起选歌、听歌和聊天。")
                    Button("连接网易云") { login = true }
                    Text("登录态只保存在这台手机。连接后可允许 Loki 操作歌曲和歌单，随时可以关闭或断开。")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            if let song = music.current {
                Section {
                    VStack(alignment: .leading, spacing: 12) {
                        Text(song.title).font(.headline)
                        Text(song.artist).font(.subheadline).foregroundStyle(.secondary)
                        Text(music.status).font(.caption).foregroundStyle(.secondary)
                        if music.duration > 0 {
                            Slider(value: $seek, in: 0...max(1, music.duration), onEditingChanged: { editing in if !editing { music.seek(seek) } })
                            HStack { Text(clock(music.elapsed)); Spacer(); Text(clock(music.duration)) }.font(.caption).monospacedDigit()
                        }
                        HStack(spacing: 28) {
                            Menu {
                                ForEach(MusicPlaybackMode.allCases, id: \.self) { mode in
                                    Button { music.setMode(mode) } label: {
                                        Label(mode.title, systemImage: music.mode == mode ? "checkmark" : mode.symbol)
                                    }
                                }
                            } label: { Image(systemName: music.mode.symbol) }
                                .accessibilityLabel("播放模式：\(music.mode.title)")
                            Button { Task { if music.playing { music.pause() } else { await music.resume() } } } label: {
                                Image(systemName: music.playing ? "pause.fill" : "play.fill")
                            }.accessibilityLabel(music.playing ? "暂停歌曲" : "继续播放")
                            Button { Task { await music.next() } } label: { Image(systemName: "forward.end.fill") }.accessibilityLabel("下一首")
                            Button {
                                Task { do { try await music.client.like(song.id); music.status = "已加入喜欢的音乐" } catch { music.error = error.localizedDescription } }
                            } label: { Image(systemName: "heart") }.accessibilityLabel("喜欢这首歌")
                            Spacer()
                            Link(destination: URL(string: "https://music.163.com/#/song?id=\(song.id)")!) { Image(systemName: "arrow.up.right.square") }
                        }.buttonStyle(.borderless).font(.title3)
                        Text(music.mode.title).font(.caption).foregroundStyle(.secondary)
                    }.padding(.vertical, 6)
                }
            }
            if music.connected {
                Section {
                    HStack {
                        TextField("歌名或歌手", text: $query).submitLabel(.search).onSubmit { search() }
                        Button("搜索") { search() }.disabled(loading || query.trimmingCharacters(in: .whitespaces).isEmpty)
                    }
                    Button("每日推荐") {
                        load { songs = try await music.client.recommendations(); music.remember(songs) }
                    }.disabled(loading)
                    Button("我的歌单") { load { playlists = try await music.playlists() } }.disabled(loading)
                    if loading { ProgressView() }
                    ForEach(playlists) { playlist in
                        Button {
                            load { songs = try await music.client.songs(playlist: playlist.id); music.remember(songs) }
                        } label: { HStack { Text(playlist.name); Spacer(); Text("\(playlist.count)").foregroundStyle(.secondary) } }
                    }
                }
                if !songs.isEmpty {
                    Section("歌曲") {
                        ForEach(Array(songs.enumerated()), id: \.offset) { index, song in
                            Button { Task { await music.playQueue(songs, from: index) } } label: {
                                VStack(alignment: .leading, spacing: 3) { Text(song.title); Text(song.artist).font(.caption).foregroundStyle(.secondary) }
                            }
                        }
                    }
                }
                Section { Button("断开网易云", role: .destructive) { music.disconnect(); songs = []; playlists = [] } }
            }
        }.navigationTitle("一起听")
            .sheet(isPresented: $login) { MusicLoginView() }
            .onChange(of: music.elapsed) { _, value in seek = value }
            .alert("音乐", isPresented: Binding(get: { music.error != nil }, set: { if !$0 { music.error = nil } })) {
                Button("知道了", role: .cancel) { music.error = nil }
            } message: { Text(music.error ?? "") }
            .task { if !music.connected { do { try await music.restore() } catch { music.status = "需要重新登录网易云" } } }
    }
    private func search() { load { songs = try await music.client.search(query); music.remember(songs) } }
    private func load(_ operation: @escaping @MainActor () async throws -> Void) {
        loading = true
        Task { defer { loading = false }; do { try await operation() } catch { music.error = error.localizedDescription } }
    }
    private func clock(_ value: Double) -> String { let s = Int(max(0, value)); return String(format: "%d:%02d", s / 60, s % 60) }
}

private struct MusicLoginView: View {
    @EnvironmentObject private var music: MusicService
    @Environment(\.dismiss) private var dismiss
    @State private var browser = WKWebView(frame: .zero, configuration: {
        let value = WKWebViewConfiguration()
        value.websiteDataStore = .nonPersistent()
        value.defaultWebpagePreferences.preferredContentMode = .desktop
        return value
    }())
    @State private var connecting = false
    @State private var message = "点“打开登录”，在网易云官方窗口选择手机号或邮箱登录；完成后再点右上角“连接”。"
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Text(message).font(.caption).padding(12)
                HStack {
                    Button("打开登录", systemImage: "person.crop.circle") {
                        Task {
                            do {
                                let result = try await browser.evaluateJavaScript(MusicLoginPolicy.openLoginScript)
                                if result as? Bool != true { message = "网易云页面尚未加载完成，请稍等后再点“打开登录”。" }
                                else { message = "请在弹出的官方窗口选择手机号或邮箱登录。看见二维码时，可选择其他登录方式。" }
                            } catch { message = "登录窗口暂未打开，请刷新后重试。" }
                        }
                    }
                    Spacer()
                    Button("刷新", systemImage: "arrow.clockwise") { browser.reload() }
                }.padding(.horizontal, 16).padding(.bottom, 10)
                OfficialMusicBrowser(web: browser)
            }.navigationTitle("网易云登录").navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                    ToolbarItem(placement: .confirmationAction) {
                        Button(connecting ? "连接中…" : "连接") {
                            connecting = true
                            Task {
                                defer { connecting = false }
                                do {
                                    let cookies = await browser.configuration.websiteDataStore.httpCookieStore.allCookies()
                                    try await music.connect(cookies: cookies); dismiss()
                                } catch { message = error.localizedDescription }
                            }
                        }.disabled(connecting)
                    }
                }
        }
    }
}
private struct OfficialMusicBrowser: UIViewRepresentable {
    let web: WKWebView
    func makeCoordinator() -> Coordinator { Coordinator() }
    func makeUIView(context: Context) -> WKWebView {
        web.navigationDelegate = context.coordinator
        web.customUserAgent = MusicLoginPolicy.desktopAgent
        web.load(URLRequest(url: URL(string: "https://music.163.com/")!))
        return web
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
    final class Coordinator: NSObject, WKNavigationDelegate {
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            // Only ask the official page to display its login UI. Never read
            // password fields, submit credentials or request SMS in injected JS.
            guard webView.url?.host == "music.163.com" else { return }
            webView.evaluateJavaScript(MusicLoginPolicy.openLoginScript, completionHandler: nil)
        }
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard navigationAction.targetFrame?.isMainFrame != false else { decisionHandler(.allow); return }
            guard let url = navigationAction.request.url, url.scheme == "https", let host = url.host,
                  host == "163.com" || host.hasSuffix(".163.com") else { decisionHandler(.cancel); return }
            decisionHandler(.allow)
        }
    }
}
private extension WKHTTPCookieStore {
    func allCookies() async -> [HTTPCookie] {
        await withCheckedContinuation { continuation in getAllCookies { continuation.resume(returning: $0) } }
    }
}
