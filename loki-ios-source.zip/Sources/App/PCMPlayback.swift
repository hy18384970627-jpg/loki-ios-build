import Foundation
import AVFoundation
import NaturalLanguage

/// Owns only this phone's playback, independent of the recording engine.
@MainActor final class PCMPlayback {
    private let engine = AVAudioEngine()
    private let node = AVAudioPlayerNode()
    private var queued = 0
    private var epoch = UUID()
    private var active = false
    private var interrupted = false
    private let format = AVAudioFormat(standardFormatWithSampleRate: 24_000, channels: 1)!
    var firstScheduled: (() -> Void)?
    private var didSchedule = false
    private var prebufferFrames = 14_400 // 600 ms; adapts only after a real underrun.
    private var inputFinished = false
    private(set) var underrunCount = 0
    var rebuffering: (() -> Void)?
    init() { engine.attach(node); engine.connect(node, to: engine.mainMixerNode, format: format) }
    func start() throws {
        stop()
        try engine.start()
        active = true; didSchedule = false
        inputFinished = false; underrunCount = 0; prebufferFrames = 14_400
    }
    func append(_ data: Data) async throws {
        try Task.checkCancellation()
        let generation = epoch
        // Bounded ahead-of-playback audio; a stopped stream cannot resume it.
        while queued >= 144_000 {
            try await Task.sleep(for: .milliseconds(10))
            guard active && epoch == generation else { throw CancellationError() }
        }
        guard active, data.count.isMultiple(of: 2), !data.isEmpty else { throw CancellationError() }
        let count = data.count / 2
        guard let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(count)),
              let channel = buffer.floatChannelData?[0] else { throw LokiError.message("无法建立播放缓冲区。") }
        buffer.frameLength = AVAudioFrameCount(count)
        data.withUnsafeBytes { (raw: UnsafeRawBufferPointer) in
            for i in 0..<count {
                let value = UInt16(raw[i * 2]) | UInt16(raw[i * 2 + 1]) << 8
                channel[i] = Float(Int16(bitPattern: value)) / 32768
            }
        }
        queued += count
        node.scheduleBuffer(buffer, completionCallbackType: .dataPlayedBack) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, self.epoch == generation else { return }
                self.queued = max(0, self.queued - count)
                if self.queued == 0 {
                    self.node.pause()
                    if !self.inputFinished {
                        self.underrunCount += 1
                        self.prebufferFrames = min(24_000, self.prebufferFrames + 4800)
                        self.rebuffering?()
                    }
                }
            }
        }
        if !interrupted && !node.isPlaying && queued >= prebufferFrames { beginPlayback() }
    }
    func drain() async throws {
        let generation = epoch
        inputFinished = true
        // Flush a final short utterance even if it never fills the prebuffer.
        if !interrupted && queued > 0 && !node.isPlaying { beginPlayback() }
        while queued > 0 || interrupted {
            try await Task.sleep(for: .milliseconds(20))
            guard active && epoch == generation else { throw CancellationError() }
        }
    }
    private func beginPlayback() {
        node.play()
        if !didSchedule { didSchedule = true; firstScheduled?() }
    }
    func pauseForInterruption() {
        interrupted = true
        node.pause(); engine.pause()
    }
    func resumeAfterInterruption() throws {
        guard active else { interrupted = false; return }
        try engine.start()
        interrupted = false
        if queued > 0 && (inputFinished || queued >= prebufferFrames) { beginPlayback() }
    }
    func stop() {
        active = false; interrupted = false; epoch = UUID(); node.stop(); engine.stop(); queued = 0
    }
    nonisolated static func sentences(_ text: String) -> [String] {
        let tokenizer = NLTokenizer(unit: .sentence); tokenizer.string = text
        var result: [String] = [], pending = ""
        tokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { range, _ in
            let next = String(text[range]).trimmingCharacters(in: .whitespacesAndNewlines)
            if pending.count >= 70 || pending.count + next.count > 500 {
                if !pending.isEmpty { result.append(pending); pending = "" }
            }
            pending += (pending.isEmpty ? "" : " ") + next
            return true
        }
        if !pending.isEmpty { result.append(pending) }
        // Very long sentences keep word boundaries; never silently truncate.
        return result.flatMap { sentence -> [String] in
            guard sentence.count > 1800 else { return [sentence] }
            var chunks: [String] = [], part = ""
            for word in sentence.split(separator: " ", omittingEmptySubsequences: false) {
                if part.count + word.count + 1 > 1800 && !part.isEmpty { chunks.append(part); part = "" }
                part += (part.isEmpty ? "" : " ") + word
            }
            if !part.isEmpty { chunks.append(part) }
            return chunks
        }
    }
}
