import Foundation
import HealthKit
import UIKit

extension HealthReading {
    var payload: [String: Any] {
        let formatter = ISO8601DateFormatter()
        var value: [String: Any] = ["id": id, "value": self.value, "unit": unit,
            "recorded_at": formatter.string(from: recordedAt), "source": String(source.prefix(160))]
        if let startAt { value["start_at"] = formatter.string(from: startAt) }
        if let endAt { value["end_at"] = formatter.string(from: endAt) }
        return value
    }
}

struct NativeHealthSnapshot: Codable {
    let enabled: Bool
    let collectedAt: Date
    let readings: [HealthReading]
    var sleepDetails: SleepDetails? = nil
    var payload: [String: Any] {
        var value: [String: Any] = ["enabled": enabled, "collected_at": ISO8601DateFormatter().string(from: collectedAt),
         "samples": readings.map(\.payload)]
        if let sleepDetails { value["sleep_details"] = sleepDetails.payload }
        return value
    }
    var contentData: Data? {
        var value = payload; value.removeValue(forKey: "collected_at")
        return try? JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
    }
}

extension HealthService {
    var snapshotForChat: [String: Any] {
        let enabled = UserDefaults.standard.bool(forKey: "healthAutoSync")
        var value = NativeHealthSnapshot(enabled: enabled, collectedAt: Date(), readings: enabled ? readings : [],
            sleepDetails: enabled ? sleepDetails : nil).payload
        if enabled { value["recent_sleep"] = recentSleep }
        return value
    }
    func queueSnapshot(enabled: Bool) {
        pendingSnapshot = .init(enabled: enabled, collectedAt: Date(), readings: enabled ? readings : [],
            sleepDetails: enabled ? sleepDetails : nil)
        try? PrivateFiles.save(pendingSnapshot, "health-pending.json")
    }
    func setAutomaticSharing(_ enabled: Bool) async throws {
        if enabled { try await authorize() }
        UserDefaults.standard.set(enabled, forKey: "healthAutoSync")
        queueSnapshot(enabled: enabled)
        if enabled {
            do { try await background(true) }
            catch { syncMessage = "前台可同步；后台更新尚未启用：\(error.localizedDescription)" }
        }
        await syncPending()
    }
    func refreshForChat() async {
        if UserDefaults.standard.bool(forKey: "healthAutoSync") { await refresh(upload: false) }
    }
    func syncPending() async {
        guard !syncing, let snapshot = pendingSnapshot else { return }
        guard let base = UserDefaults.standard.string(forKey: "gatewayURL"), !SecureToken.read().isEmpty else {
            syncMessage = "等手机配对并解锁后自动同步"; return
        }
        let encoded = snapshot.contentData
        if snapshot.enabled && encoded == lastSyncedSamples {
            pendingSnapshot = nil; try? PrivateFiles.save(pendingSnapshot, "health-pending.json"); return
        }
        syncing = true; defer { syncing = false }
        let background = UIApplication.shared.beginBackgroundTask(withName: "LokiHealthSync", expirationHandler: nil)
        defer { if background != .invalid { UIApplication.shared.endBackgroundTask(background) } }
        do {
            _ = try await MobileAPI(base: base, token: SecureToken.read()).data("/v1/health", snapshot.payload, timeout: 8)
            lastSyncedSamples = snapshot.enabled ? encoded : nil
            lastSyncedAt = Date(); UserDefaults.standard.set(lastSyncedAt, forKey: "healthLastSync")
            syncMessage = snapshot.enabled ? "已自动同步给 Loki；使用原始采样时间" : "已暂停向 Loki 分享健康数据"
            if pendingSnapshot?.collectedAt == snapshot.collectedAt {
                pendingSnapshot = nil; try? PrivateFiles.save(pendingSnapshot, "health-pending.json")
            } else { Task { await syncPending() } }
        } catch {
            syncMessage = "等待下次联网同步：\(error.localizedDescription)"
        }
    }
    func sleepSummary() async throws -> HealthReading? {
        if let updated = sleepCacheUpdatedAt, Date().timeIntervalSince(updated) < 300 { return cachedSleepReading }
        let type = HKCategoryType.categoryType(forIdentifier: .sleepAnalysis)!
        let raw: [HKCategorySample] = try await withCheckedThrowingContinuation { continuation in
            let predicate = HKQuery.predicateForSamples(withStart: Date().addingTimeInterval(-7 * 86400), end: Date(), options: .strictEndDate)
            let query = HKSampleQuery(sampleType: type, predicate: predicate, limit: HKObjectQueryNoLimit,
                sortDescriptors: [NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)]) { _, samples, error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: (samples ?? []).compactMap { $0 as? HKCategorySample }) }
            }
            store.execute(query)
        }
        let asleep: Set<Int> = [HKCategoryValueSleepAnalysis.asleepUnspecified.rawValue,
            HKCategoryValueSleepAnalysis.asleepCore.rawValue, HKCategoryValueSleepAnalysis.asleepDeep.rawValue,
            HKCategoryValueSleepAnalysis.asleepREM.rawValue]
        let all = raw.filter { asleep.contains($0.value) && $0.endDate > $0.startDate }
        let watch = all.filter { ($0.sourceRevision.productType ?? "").hasPrefix("Watch") || ($0.device?.model ?? "").localizedCaseInsensitiveContains("watch") }
        let samples = watch.isEmpty ? all : watch
        let intervals = samples.map { SleepIntervals.Interval(start: $0.startDate, end: $0.endDate) }
        let format = ISO8601DateFormatter()
        let daily = Dictionary(grouping: SleepIntervals.sessions(intervals), by: { Calendar.current.startOfDay(for: $0.end) })
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: .now)
        var segment = 0
        sleepTrend = (-6...0).compactMap { offset in
            guard let date = calendar.date(byAdding: .day, value: offset, to: today) else { return nil }
            let value = daily[date]?.max(by: { $0.duration < $1.duration }).map { $0.duration / 3600 }
            defer { if value == nil { segment += 1 } }
            return HealthDay(date: date, value: value, segment: segment)
        }
        recentSleep = daily.keys.sorted().suffix(7).compactMap { day -> [String: Any]? in
            guard let value = daily[day]?.max(by: { $0.duration < $1.duration }), value.duration >= 3 * 3600 else { return nil }
            return ["start_at": format.string(from: value.start), "end_at": format.string(from: value.end),
                    "minutes": value.duration / 60]
        }
        guard let session = SleepIntervals.mainSession(intervals) else {
            sleepDetails = nil; cachedSleepReading = nil; sleepCacheUpdatedAt = Date(); return nil
        }
        let sources = Array(Set(samples.filter { $0.endDate >= session.start && $0.startDate <= session.end }
            .map { $0.sourceRevision.source.name })).sorted().joined(separator: "、")
        let allWatch = raw.filter { ($0.sourceRevision.productType ?? "").hasPrefix("Watch") || ($0.device?.model ?? "").localizedCaseInsensitiveContains("watch") }
        let detailSource = watch.isEmpty ? raw : allWatch
        let names = [HKCategoryValueSleepAnalysis.asleepDeep.rawValue: "deep", HKCategoryValueSleepAnalysis.asleepCore.rawValue: "core",
            HKCategoryValueSleepAnalysis.asleepREM.rawValue: "rem", HKCategoryValueSleepAnalysis.awake.rawValue: "awake",
            HKCategoryValueSleepAnalysis.asleepUnspecified.rawValue: "unspecified"]
        let details = detailSource.compactMap { sample -> SleepStagePeriod? in
            guard let stage = names[sample.value], sample.endDate > sample.startDate else { return nil }
            return .init(stage: stage, startAt: sample.startDate, endAt: sample.endDate)
        }
        sleepDetails = SleepStageTimeline.build(details, session: session, source: String(sources.prefix(160)))
        let reading = HealthReading(id: "sleep", title: "最近主要睡眠（已记录时长）", value: session.duration / 60, unit: "分钟",
            recordedAt: session.end, source: String(sources.prefix(160)), startAt: session.start, endAt: session.end)
        cachedSleepReading = reading; sleepCacheUpdatedAt = Date()
        return reading
    }
}
