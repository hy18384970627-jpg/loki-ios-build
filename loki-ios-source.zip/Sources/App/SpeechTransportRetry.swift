import Foundation

enum SpeechTransportRetry {
    static func shouldRetry(_ error: Error, attempt: Int, receivedBytes: Int) -> Bool {
        let value = error as NSError
        return attempt == 0 && receivedBytes == 0 && value.domain == NSURLErrorDomain && [
            URLError.networkConnectionLost.rawValue, URLError.timedOut.rawValue,
            URLError.cannotConnectToHost.rawValue, URLError.secureConnectionFailed.rawValue
        ].contains(value.code)
    }
}
