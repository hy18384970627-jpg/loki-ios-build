import Foundation
import CommonCrypto
import Security

/// Native adaptation of Vael-KY's MIT weapi implementation; see Music-Notices.txt.
enum NetEaseCrypto {
    static func audioClient(_ payload: [String: Any], path: String) throws -> [String: String] {
        guard path == "/api/song/enhance/player/url/v1" else { throw LokiError.message("不支持的音乐客户端请求。") }
        let json = try JSONSerialization.data(withJSONObject: payload, options: [.sortedKeys, .withoutEscapingSlashes])
        let text = String(decoding: json, as: UTF8.self)
        let digestInput = Data("nobody\(path)use\(text)md5forencrypt".utf8)
        var digest = [UInt8](repeating: 0, count: Int(CC_MD5_DIGEST_LENGTH))
        _ = digestInput.withUnsafeBytes { CC_MD5($0.baseAddress, CC_LONG(digestInput.count), &digest) }
        let md5 = digest.map { String(format: "%02x", $0) }.joined()
        let body = Data("\(path)-36cd479b6b5-\(text)-36cd479b6b5-\(md5)".utf8)
        let key = Data("e82ckenh8dichen8".utf8)
        var output = Data(count: body.count + kCCBlockSizeAES128), written = 0
        let capacity = output.count
        let status = output.withUnsafeMutableBytes { destination in
            body.withUnsafeBytes { input in
                key.withUnsafeBytes { key in
                    CCCrypt(CCOperation(kCCEncrypt), CCAlgorithm(kCCAlgorithmAES),
                        CCOptions(kCCOptionPKCS7Padding | kCCOptionECBMode), key.baseAddress, kCCKeySizeAES128,
                        nil, input.baseAddress, body.count, destination.baseAddress, capacity, &written)
                }
            }
        }
        guard status == kCCSuccess else { throw LokiError.message("音乐客户端请求编码失败。") }
        return ["params": output.prefix(written).map { String(format: "%02X", $0) }.joined()]
    }
    private static let modulus = "00e0b509f6259df8642dbc35662901477df22677ec152b5ff68ace615bb7b725152b3ab17a876aea8a5aa76d2e417629ec4ee341f56135fccf695280104e0312ecbda92557c93870114af6c9d05c4f7f0c3685b7a46bee255932575cce10b424d813cfe4875d3e82047b97ddef52741d546b8e289dc6935b3ece0462db0a22b8e7"
    static func encrypt(_ payload: [String: Any], secret: Data? = nil) throws -> [String: String] {
        let alphabet = Array("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".utf8)
        let secret = secret ?? Data((0..<16).map { _ in alphabet.randomElement()! })
        guard secret.count == 16 else { throw LokiError.message("音乐请求密钥长度无效。") }
        let json = try JSONSerialization.data(withJSONObject: payload, options: [.sortedKeys, .withoutEscapingSlashes])
        let first = try aes(json, key: Data("0CoJUm6Qyw8W8jud".utf8)).base64EncodedData()
        let params = try aes(first, key: secret).base64EncodedString()
        return ["params": params, "encSecKey": try rsa(secret)]
    }
    private static func aes(_ data: Data, key: Data) throws -> Data {
        let capacity = data.count + kCCBlockSizeAES128
        var output = Data(count: capacity), written = 0
        let iv = Data("0102030405060708".utf8)
        let status = output.withUnsafeMutableBytes { destination in
            data.withUnsafeBytes { input in
                key.withUnsafeBytes { key in
                    iv.withUnsafeBytes { iv in
                        CCCrypt(CCOperation(kCCEncrypt), CCAlgorithm(kCCAlgorithmAES), CCOptions(kCCOptionPKCS7Padding),
                                key.baseAddress, kCCKeySizeAES128, iv.baseAddress, input.baseAddress, data.count,
                                destination.baseAddress, capacity, &written)
                    }
                }
            }
        }
        guard status == kCCSuccess else { throw LokiError.message("音乐请求加密失败。") }
        return output.prefix(written)
    }
    private static func der(_ tag: UInt8, _ bytes: Data) -> Data {
        let length = bytes.count < 128 ? Data([UInt8(bytes.count)]) : Data([0x81, UInt8(bytes.count)])
        return Data([tag]) + length + bytes
    }
    private static func rsa(_ secret: Data) throws -> String {
        var bytes = Data()
        var index = modulus.startIndex
        while index < modulus.endIndex {
            let end = modulus.index(index, offsetBy: 2)
            bytes.append(UInt8(modulus[index..<end], radix: 16)!)
            index = end
        }
        let keyData = der(0x30, der(0x02, bytes) + der(0x02, Data([1, 0, 1])))
        let attributes: [String: Any] = [kSecAttrKeyType as String: kSecAttrKeyTypeRSA,
            kSecAttrKeyClass as String: kSecAttrKeyClassPublic, kSecAttrKeySizeInBits as String: 1024]
        var error: Unmanaged<CFError>?
        guard let key = SecKeyCreateWithData(keyData as CFData, attributes as CFDictionary, &error) else {
            throw LokiError.message("无法建立音乐请求公钥。")
        }
        let message = Data(repeating: 0, count: 128 - secret.count) + Data(secret.reversed())
        guard let output = SecKeyCreateEncryptedData(key, .rsaEncryptionRaw, message as CFData, &error) else {
            throw LokiError.message("音乐请求签名失败。")
        }
        return (output as Data).map { String(format: "%02x", $0) }.joined()
    }
}
