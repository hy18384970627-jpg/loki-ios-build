import Foundation
import CommonCrypto

struct ShoppingAction: Decodable {
    let id: UUID
    let action: String
    let query: String?
    let item_id: String?
    let expires: Double
}
struct ShoppingProduct: Identifiable, Codable {
    let id: String
    let title: String
    let shop: String
    let price: String
    let url: String
    var link: URL? { ShoppingPolicy.link(url) }
    var payload: [String: String] { ["id": id, "title": title, "shop": shop, "price": price, "url": url] }
    static func parse(_ row: [String: Any]) -> ShoppingProduct? {
        let basic = row["item_basic_info"] as? [String: Any] ?? row
        let price = row["price_promotion_info"] as? [String: Any] ?? row
        let publish = row["publish_info"] as? [String: Any] ?? row
        let identifier = row["item_id"] ?? row["num_iid"]
        let id = identifier as? String ?? (identifier as? NSNumber)?.stringValue ?? ""
        guard !id.isEmpty, let title = basic["title"] as? String, !title.isEmpty else { return nil }
        let amount = price["final_promotion_price"] ?? price["zk_final_price"]
        let amountText = amount as? String ?? (amount as? NSNumber)?.stringValue ?? ""
        let raw = publish["coupon_share_url"] as? String ?? publish["click_url"] as? String ?? basic["item_url"] as? String ?? ""
        return .init(id: String(id.prefix(200)), title: String(title.prefix(300)),
            shop: String((basic["shop_title"] as? String ?? basic["nick"] as? String ?? "").prefix(200)),
            price: String(amountText.prefix(60)), url: ShoppingPolicy.link(raw)?.absoluteString ?? "")
    }
}
enum ShoppingPolicy {
    static func link(_ raw: String) -> URL? {
        let text = raw.hasPrefix("//") ? "https:" + raw : raw
        guard var parts = URLComponents(string: text), ["http", "https"].contains(parts.scheme ?? ""),
              let host = parts.host?.lowercased(), parts.user == nil, parts.password == nil,
              parts.port == nil || parts.port == 443,
              ["taobao.com", "tmall.com", "tb.cn"].contains(where: { host == $0 || host.hasSuffix("." + $0) }) else { return nil }
        parts.scheme = "https"; return parts.url
    }
    // TOP's published secret + lexically sorted key/value pairs + secret signature.
    static func sign(_ values: [String: String], secret: String) -> String {
        let text = secret + values.keys.sorted().map { $0 + values[$0]! }.joined() + secret
        let bytes = Data(text.utf8)
        var digest = [UInt8](repeating: 0, count: Int(CC_MD5_DIGEST_LENGTH))
        _ = bytes.withUnsafeBytes { CC_MD5($0.baseAddress, CC_LONG(bytes.count), &digest) }
        return digest.map { String(format: "%02X", $0) }.joined()
    }
}
