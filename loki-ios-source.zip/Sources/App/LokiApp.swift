import SwiftUI

@main struct LokiApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var delegate
    @StateObject private var app = AppState()
    @StateObject private var health = HealthService.shared
    @StateObject private var notifications = NotificationService()
    @StateObject private var focus = FocusService()
    @StateObject private var alarms = AlarmService()
    @StateObject private var device = DeviceTools()
    @StateObject private var voice = VoiceService()
    @StateObject private var call = CallSession()
    @StateObject private var music = MusicService.shared
    @StateObject private var shopping = ShoppingService.shared
    @Environment(\.scenePhase) private var phase
    @AppStorage("chatLock") private var chatLock = true
    var body: some Scene {
        WindowGroup {
            #if targetEnvironment(simulator)
            if let tab = LokiDesignPreview.launchTab {
                LokiDesignPreview(tab: tab)
                    .environmentObject(app).environmentObject(health).environmentObject(notifications)
                    .environmentObject(focus).environmentObject(alarms).environmentObject(device)
                    .environmentObject(voice).environmentObject(call)
            } else {
                liveContent
            }
            #else
            liveContent
            #endif
        }
    }

    private var liveContent: some View {
        RootView()
            .environmentObject(app).environmentObject(health).environmentObject(notifications)
            .environmentObject(focus).environmentObject(alarms).environmentObject(device).environmentObject(voice)
            .environmentObject(music).environmentObject(shopping).environmentObject(call)
            .sheet(isPresented: Binding(get: { call.active && !call.minimized && app.unlocked },
                set: { if !$0 { call.minimize() } })) { CallView().environmentObject(app).environmentObject(voice).environmentObject(call) }
            .overlay {
                if call.active && call.minimized && app.unlocked && phase == .active {
                    MiniCallView().environmentObject(app).environmentObject(call)
                }
            }
            .tint(Color(red: 0.78, green: 0.68, blue: 0.43))
            .preferredColorScheme(.dark)
            .alert("Loki", isPresented: Binding(get: { app.notice != nil }, set: { if !$0 { app.notice = nil } })) {
                Button("知道了", role: .cancel) { app.notice = nil }
            } message: { Text(app.notice ?? "") }
            .onChange(of: phase) { _, value in
                call.setForeground(value == .active)
                if value == .active {
                    LocationService.shared.restoreAutomatic()
                    focus.refresh(); alarms.refresh()
                    Task {
                        await notifications.refresh()
                        if UserDefaults.standard.bool(forKey: "healthBackground") { try? await health.background(true) }
                        if UserDefaults.standard.bool(forKey: "healthAutoSync") { await health.refresh() }
                        await health.syncPending()
                        if app.unlocked { await alarms.autoSyncCourses(api: app.api) }
                    }
                } else if value == .background {
                    if chatLock { app.unlocked = false }
                    if !call.active { voice.stopRecording(keep: true) }
                    try? device.torch(false)
                }
            }
            .onChange(of: app.unlocked) { _, value in
                if value { Task { await alarms.autoSyncCourses(api: app.api); await app.syncWallpaperReceipt(); await app.refreshCompanion(voice: voice) } }
            }
            .onChange(of: voice.playing || voice.recording) { _, value in music.voiceSpeaking(value) }
            .task(id: app.unlocked && phase == .active) {
                guard app.unlocked && phase == .active else { return }
                while !Task.isCancelled {
                    await app.refreshCompanion(voice: voice)
                    do { try await Task.sleep(for: .seconds(5)) } catch { break }
                }
            }
            .onReceive(NotificationCenter.default.publisher(for: .init("LokiOpenChat"))) { _ in app.selectedTab = 0; Task { await app.refreshCompanion(voice: voice) } }
            .task(id: app.unlocked && phase == .active) {
                guard app.unlocked && phase == .active else { return }
                while !Task.isCancelled {
                    await app.reconcileOutgoing(health: health, voice: voice, alarms: alarms, focus: focus)
                    do { try await Task.sleep(for: .seconds(3)) } catch { break }
                }
            }
            .task(id: app.unlocked && phase == .active) {
                guard app.unlocked && phase == .active else { return }
                if !music.connected { try? await music.restore() }
                while !Task.isCancelled {
                    await app.refreshMusicCompanion(voice: voice)
                    do { try await Task.sleep(for: .seconds(5)) } catch { break }
                }
            }
            .task {
                focus.refresh(); alarms.refresh(); await notifications.refresh()
                if UserDefaults.standard.bool(forKey: "healthBackground") { try? await health.background(true) }
                if UserDefaults.standard.bool(forKey: "healthAutoSync") { await health.refresh() }
                await health.syncPending()
            }
            .task(id: app.unlocked && app.paired && phase == .active && app.selectedTab != 3) {
                guard app.unlocked && app.paired && phase == .active && app.selectedTab != 3 else { return }
                while !Task.isCancelled {
                    try? await DeskSync.shared.refresh(api: app.api)
                    do { try await Task.sleep(for: .seconds(60)) } catch { break }
                }
            }
    }
}

struct RootView: View {
    @EnvironmentObject private var app: AppState
    @EnvironmentObject private var device: DeviceTools
    @AppStorage("chatLock") private var chatLock = true
    var body: some View {
        Group {
            if chatLock && !app.unlocked {
                VStack(spacing: 24) {
                    Image(systemName: "moon.stars.fill").font(.system(size: 64)).foregroundStyle(.tint)
                    Text("L O K I").font(.largeTitle).tracking(8)
                    Text("你的私人空间").foregroundStyle(.secondary)
                    Button("验证身份并进入", systemImage: "faceid") {
                        Task { do { try await device.unlock(); app.unlocked = true } catch { app.tell(error) } }
                    }.buttonStyle(.borderedProminent)
                }.frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(red: 0.025, green: 0.08, blue: 0.075))
            } else {
                TabView(selection: $app.selectedTab) {
                    ChatView().tabItem { Label("Loki", systemImage: "bubble.left.and.bubble.right") }.tag(0)
                    ToolsView().tabItem { Label("生活", systemImage: "sparkles") }.tag(1)
                    HealthView().tabItem { Label("健康", systemImage: "heart") }.tag(2)
                    DeskView().tabItem { Label("书桌", systemImage: "books.vertical") }.tag(3)
                    SettingsView().tabItem { Label("设置", systemImage: "gearshape") }.tag(4)
                }
            }
        }
        .task { if !chatLock { app.unlocked = true } }
        .onChange(of: chatLock) { _, enabled in if !enabled { app.unlocked = true } }
        .overlay {
            // Hide the private scene in the app switcher when backgrounded.
            PrivacyCover()
        }
    }
}

private struct PrivacyCover: View {
    @Environment(\.scenePhase) private var phase
    var body: some View {
        if phase != .active {
            Color(red: 0.025, green: 0.08, blue: 0.075).ignoresSafeArea().overlay {
                Label("Loki · 私人空间", systemImage: "lock.fill").font(.title2)
            }
        }
    }
}
