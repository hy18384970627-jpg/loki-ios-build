import AVFoundation

@MainActor final class PhoneAudioSession {
    static let shared = PhoneAudioSession()
    private var active = false
    private var interrupted = false
    private var musicActive = false
    private var speechActive = false
    func interruptionBegan() { interrupted = true; active = false }
    func interruptionEnded() { interrupted = false }
    func reset() { active = false; interrupted = false }
    func playback() async throws {
        try await activate(.playback, mode: .spokenAudio, options: [])
        speechActive = true
    }
    func musicPlayback() async throws {
        musicActive = true
        do { if !speechActive { try await activate(.playback, mode: .default, options: []) } }
        catch { musicActive = false; throw error }
    }
    func musicStopped() { musicActive = false; if !speechActive { release() } }
    func recording(forCall: Bool) async throws {
        try await activate(.playAndRecord, mode: forCall ? .voiceChat : .default,
                           options: [.defaultToSpeaker, .allowBluetooth])
        speechActive = true
    }
    private func activate(_ category: AVAudioSession.Category, mode: AVAudioSession.Mode,
                          options: AVAudioSession.CategoryOptions) async throws {
        let session = AVAudioSession.sharedInstance()
        while interrupted {
            try await Task.sleep(for: .milliseconds(100))
        }
        try await AudioActivationRetry.run(shouldRetry: { error in
            let value = error as NSError
            return value.domain == NSOSStatusErrorDomain && [
                AVAudioSession.ErrorCode.insufficientPriority.rawValue,
                AVAudioSession.ErrorCode.cannotInterruptOthers.rawValue,
                AVAudioSession.ErrorCode.cannotStartPlaying.rawValue
            ].contains(value.code)
        }, activate: {
            guard !self.interrupted else { throw CancellationError() }
            if session.category != category || session.mode != mode || session.categoryOptions != options {
                try session.setCategory(category, mode: mode, options: options)
                self.active = false
            }
            if !self.active { try session.setActive(true); self.active = true }
        })
    }
    func release() {
        speechActive = false
        if musicActive {
            // Recording/voice-chat processing must not remain attached to resumed music.
            do {
                let session = AVAudioSession.sharedInstance()
                if session.category != .playback || session.mode != .default || !session.categoryOptions.isEmpty {
                    try session.setCategory(.playback, mode: .default, options: [])
                }
                try session.setActive(true); active = true
            } catch { active = false }
            return
        }
        guard active else { return }
        // The owner stops players/engines before releasing the session.
        if (try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)) != nil {
            active = false
        }
    }
}
