import Foundation
import UIKit
import AVFoundation
import EventKit
import LocalAuthentication
import Network
import JavaScriptCore
import MediaPlayer
import SwiftUI
import ImageIO

enum MobileImage {
    static func from(_ data: Data) -> UIImage? {
        guard data.count <= 20_000_000, let source = CGImageSourceCreateWithData(data as CFData, nil),
              let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceThumbnailMaxPixelSize: 2048] as CFDictionary) else { return nil }
        return UIImage(cgImage: image)
    }
    static func scaled(_ image: UIImage) -> UIImage {
        let ratio = min(1, 2048 / max(image.size.width, image.size.height))
        let size = CGSize(width: image.size.width * ratio, height: image.size.height * ratio)
        let format = UIGraphicsImageRendererFormat(); format.scale = 1
        return UIGraphicsImageRenderer(size: size, format: format).image { _ in
            image.draw(in: CGRect(origin: .zero, size: size))
        }
    }
}

@MainActor final class DeviceTools: ObservableObject {
    @Published var network = "检测中"
    @Published var calendarItems: [EKEvent] = []
    private let eventStore = EKEventStore()
    private let monitor = NWPathMonitor()
    init() {
        UIDevice.current.isBatteryMonitoringEnabled = true
        monitor.pathUpdateHandler = { [weak self] path in
            let value = path.status != .satisfied ? "离线" : path.usesInterfaceType(.wifi) ? "Wi-Fi" : path.usesInterfaceType(.cellular) ? "蜂窝网络" : "其他网络"
            Task { @MainActor [weak self] in self?.network = value }
        }
        monitor.start(queue: DispatchQueue(label: "loki.network"))
    }
    deinit { monitor.cancel() }
    private var activeScreen: UIScreen? {
        UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
            .first { $0.activationState == .foregroundActive }?.screen
    }
    var currentBrightness: Double? { activeScreen.map { Double($0.brightness) } }
    func setBrightness(_ value: Double) throws {
        guard (0.05...1).contains(value), let screen = activeScreen else {
            throw LokiError.message("当前没有可调整亮度的前台屏幕。")
        }
        screen.brightness = CGFloat(value)
    }
    var battery: String {
        let value = UIDevice.current.batteryLevel
        return value < 0 ? "不可读" : "\(Int(value * 100))% · \(UIDevice.current.batteryState == .charging ? "充电中" : "当前电量")"
    }
    var storage: String {
        guard let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first,
              let values = try? url.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey]),
              let bytes = values.volumeAvailableCapacityForImportantUsage else { return "不可读" }
        return ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file) + " 可用"
    }
    func torch(_ on: Bool) throws {
        guard let device = AVCaptureDevice.default(for: .video), device.hasTorch else {
            throw LokiError.message("没有可用的手电筒。")
        }
        try device.lockForConfiguration()
        defer { device.unlockForConfiguration() }
        if on { try device.setTorchModeOn(level: 0.3) } else { device.torchMode = .off }
    }
    func unlock() async throws {
        let context = LAContext()
        let success = try await context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "打开 Loki 私人聊天")
        guard success else { throw LokiError.message("未完成身份验证。") }
    }
    func addCalendar(title: String, date: Date) async throws {
        guard try await eventStore.requestFullAccessToEvents() else { throw LokiError.message("日历权限未开启。") }
        guard let calendar = eventStore.defaultCalendarForNewEvents else { throw LokiError.message("系统没有可写入的默认日历。") }
        let event = EKEvent(eventStore: eventStore)
        event.title = title; event.startDate = date; event.endDate = date.addingTimeInterval(3600)
        event.calendar = calendar
        try eventStore.save(event, span: .thisEvent)
    }
    func readCalendar() async throws {
        guard try await eventStore.requestFullAccessToEvents() else { throw LokiError.message("日历权限未开启。") }
        calendarItems = eventStore.events(matching: eventStore.predicateForEvents(withStart: Date(),
            end: Date().addingTimeInterval(7 * 86400), calendars: nil)).sorted { $0.startDate < $1.startDate }
    }
    func addReminder(title: String, date: Date) async throws {
        guard try await eventStore.requestFullAccessToReminders() else { throw LokiError.message("提醒事项权限未开启。") }
        guard let calendar = eventStore.defaultCalendarForNewReminders() else { throw LokiError.message("没有可写入的提醒事项列表。") }
        let reminder = EKReminder(eventStore: eventStore)
        reminder.title = title; reminder.calendar = calendar
        reminder.dueDateComponents = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: date)
        reminder.addAlarm(EKAlarm(absoluteDate: date))
        try eventStore.save(reminder, commit: true)
    }
    func calculate(_ expression: String) throws -> String {
        guard !expression.isEmpty, expression.count <= 120,
              expression.range(of: #"^[0-9.()+*/%\s\-]+$"#, options: .regularExpression) != nil,
              !expression.contains("**"), !expression.contains("//"), !expression.contains("/*") else {
            throw LokiError.message("计算器仅接受数字、括号和基本运算符。")
        }
        guard let context = JSContext(), let result = context.evaluateScript("(\(expression))"),
              context.exception == nil, let number = result.toNumber(), number.doubleValue.isFinite else {
            throw LokiError.message("表达式无效或结果不是有限数值。")
        }
        return number.stringValue
    }
    func screenshot() throws -> UIImage {
        guard let scene = UIApplication.shared.connectedScenes.first(where: { $0.activationState == .foregroundActive }) as? UIWindowScene,
              let window = scene.windows.first(where: \.isKeyWindow) else { throw LokiError.message("当前没有可截图的 Loki 窗口。") }
        return UIGraphicsImageRenderer(bounds: window.bounds).image { _ in window.drawHierarchy(in: window.bounds, afterScreenUpdates: true) }
    }
}

struct VolumeControl: UIViewRepresentable {
    func makeUIView(context: Context) -> MPVolumeView { MPVolumeView(frame: .zero) }
    func updateUIView(_ view: MPVolumeView, context: Context) {}
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: items, applicationActivities: nil) }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}

struct CameraSheet: UIViewControllerRepresentable {
    var onImage: (UIImage) -> Void
    @Environment(\.dismiss) private var dismiss
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = .camera; picker.delegate = context.coordinator
        return picker
    }
    func updateUIViewController(_ controller: UIImagePickerController, context: Context) {}
    final class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: CameraSheet
        init(_ parent: CameraSheet) { self.parent = parent }
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) { parent.dismiss() }
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            if let image = info[.originalImage] as? UIImage { parent.onImage(MobileImage.scaled(image)) }
            parent.dismiss()
        }
    }
}
