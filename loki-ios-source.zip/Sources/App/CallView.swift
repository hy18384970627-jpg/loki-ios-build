import SwiftUI

struct CallView: View {
    @EnvironmentObject private var app: AppState
    @EnvironmentObject private var voice: VoiceService
    @EnvironmentObject private var call: CallSession
    var body: some View {
        VStack(spacing: 28) {
            HStack {
                Button { call.minimize() } label: { Image(systemName: "arrow.down.right.and.arrow.up.left").frame(width: 44, height: 44) }
                    .accessibilityLabel("收起通话")
                Spacer()
            }

            Spacer()
            LokiPortrait(size: 126)
            Text("Loki").font(.largeTitle)
            Text(app.voiceStage.isEmpty ? call.status : app.voiceStage).foregroundStyle(.secondary)
            Text(call.startedAt, style: .timer).monospacedDigit().foregroundStyle(.secondary)
            Spacer()
            HStack(spacing: 32) {
                Button {
                    call.toggleMute()
                } label: { callControl(call.muted ? "取消静音" : "静音", symbol: call.muted ? "mic.slash.fill" : "mic.fill") }
                    .disabled(!call.active)
                Button { call.interrupt() } label: { callControl("我来说", symbol: "hand.raised.fill") }
                    .disabled(!voice.playing || !call.active)
            }.buttonStyle(.plain)
            Button {
                call.end()
            } label: {
                VStack(spacing: 10) {
                    Image(systemName: "phone.down.fill").font(.system(size: 27)).frame(width: 68, height: 68).background(.red, in: Circle())
                    Text(call.active ? "挂断" : "关闭").font(.caption)
                }.foregroundStyle(.white)
            }.buttonStyle(.plain).padding(.bottom, 36)
        }.padding(28)
    }
    private func callControl(_ title: String, symbol: String) -> some View {
        VStack(spacing: 10) {
            Image(systemName: symbol).font(.system(size: 25)).frame(width: 64, height: 64)
                .background(.white.opacity(0.13), in: Circle())
            Text(title).font(.caption)
        }.foregroundStyle(.white)
    }
}
