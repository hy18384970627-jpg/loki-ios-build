import Foundation
import Combine
import AVFoundation
import UIKit

@MainActor final class VoiceService: NSObject, ObservableObject, AVAudioPlayerDelegate {
    @Published var recording = false
    @Published var playing = false
    @Published private(set) var playingMessageID: UUID?
    @Published private(set) var finishedReplyID: UUID?
    private var currentReplyID: UUID?
    @Published var draftRecording: RecordedVoice?
    @Published var recordingSeconds: Double = 0
    @Published var errorMessage: String?
    @Published var streamStatus = ""
    private var pcm = PCMPlayback()
    private let audioSession = PhoneAudioSession.shared
    private var interruptionRecovery: Task<Void, Never>?
    private var idleRelease: Task<Void, Never>?
    private var streamTask: Task<Void, Never>?
    private var streamID = UUID()
    private var playbackCompletion: CheckedContinuation<Bool, Never>?
    private var player: AVAudioPlayer?
    private var recorder: AVAudioRecorder?
    private var recordingID: UUID?
    private var recordingForCall = false
    private var recordingTimer: Task<Void, Never>?
    private var lookahead: (id: UUID, stream: VoiceLookahead)?
    private var consumingLookahead: VoiceLookahead?
    private let synthesizer = AVSpeechSynthesizer()
    override init() {
        super.init()
        NotificationCenter.default.addObserver(self, selector: #selector(audioInterrupted),
            name: AVAudioSession.interruptionNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(mediaServicesReset),
            name: AVAudioSession.mediaServicesWereResetNotification, object: nil)
    }
    @objc private func audioInterrupted(_ notification: Notification) {
        guard let raw = notification.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
              let type = AVAudioSession.InterruptionType(rawValue: raw) else { return }
        if type == .began {
            interruptionRecovery?.cancel(); interruptionRecovery = nil
            audioSession.interruptionBegan()
            pcm.pauseForInterruption(); player?.pause()
            stopRecording(keep: !recordingForCall)
            if playing { streamStatus = "语音暂被系统中断，等待恢复…" }
        } else {
            let rawOptions = notification.userInfo?[AVAudioSessionInterruptionOptionKey] as? UInt ?? 0
            guard AVAudioSession.InterruptionOptions(rawValue: rawOptions).contains(.shouldResume) else {
                stopPlayback(); audioSession.interruptionEnded(); return
            }
            audioSession.interruptionEnded()
            guard playing else { return }
            let id = streamID
            interruptionRecovery = Task { @MainActor [weak self] in
                guard let self else { return }
                do {
                    try await self.audioSession.playback()
                    try Task.checkCancellation()
                    guard self.streamID == id else { return }
                    try self.pcm.resumeAfterInterruption()
                    if let player = self.player, !player.play() { throw LokiError.message("语音未能恢复播放，请长按消息重播。") }
                    self.streamStatus = "Loki 正在说话"
                } catch {
                    guard self.streamID == id else { return }
                    self.stopPlayback()
                    if !(error is CancellationError) { self.errorMessage = self.playbackError(error) }
                }
            }
        }
    }
    @objc private func mediaServicesReset(_ notification: Notification) {
        let wasPlaying = playing
        stopPlayback(); stopRecording(keep: !recordingForCall)
        audioSession.reset(); pcm = PCMPlayback()
        if wasPlaying { errorMessage = "iPhone 音频服务已重置，长按消息即可重播；后续回复仍会自动播放。" }
    }
    private func playbackError(_ error: Error) -> String {
        let value = error as NSError
        if value.domain == NSURLErrorDomain {
            return "语音连接暂时失败，文字已保留。稍后长按这条消息即可重播。"
        }
        guard value.domain == NSOSStatusErrorDomain || value.domain == AVFoundationErrorDomain else {
            return error.localizedDescription
        }
        return "暂时无法启动语音播放，请结束其他通话或录音后长按消息重播。后续回复仍会自动播放。（\(value.domain) · \(value.code)）"
    }
    private func scheduleIdleRelease() {
        idleRelease?.cancel()
        idleRelease = Task { @MainActor [weak self] in
            do { try await Task.sleep(for: .seconds(2)) } catch { return }
            self?.releaseAudioSessionIfIdle()
        }
    }
    func releaseAudioSessionIfIdle() {
        if !playing && !recording { audioSession.release() }
    }
    func play(_ audio: Data) async throws {
        stopRecording()
        try await audioSession.playback()
        try Task.checkCancellation()
        player = try AVAudioPlayer(data: audio)
        player?.delegate = self
        guard player?.play() == true else { throw LokiError.message("音频未能开始播放。") }
        playing = true
    }
    func stopPlayback(releaseSession: Bool = true) {
        idleRelease?.cancel(); idleRelease = nil
        interruptionRecovery?.cancel(); interruptionRecovery = nil
        lookahead?.stream.cancel(); lookahead = nil
        consumingLookahead?.cancel(); consumingLookahead = nil
        finishPlaybackWaiter(false)
        streamTask?.cancel(); streamTask = nil; streamID = UUID(); pcm.stop()
        player?.stop(); player = nil; playing = false
        playingMessageID = nil
        currentReplyID = nil
        synthesizer.stopSpeaking(at: .immediate)
        if releaseSession && !recording { audioSession.release() }
    }
    private func finishPlaybackWaiter(_ finished: Bool) {
        let completion = playbackCompletion; playbackCompletion = nil
        completion?.resume(returning: finished)
    }
    func speakAndWait(_ text: String, api: MobileAPI, messageID: UUID, next: ChatItem? = nil) async -> Bool {
        guard !Task.isCancelled else { return false }
        return await withTaskCancellationHandler {
            await withCheckedContinuation { continuation in
                speak(text, api: api, messageID: messageID, next: next)
                playbackCompletion = continuation
            }
        } onCancel: {
            Task { @MainActor [weak self] in self?.stopPlayback() }
        }
    }
    private func prefetch(_ next: ChatItem?, api: MobileAPI) {
        guard let next, lookahead == nil, OriginalVoiceCache.read(next.id, text: next.voiceText) == nil else { return }
        let stream = VoiceLookahead()
        stream.start(cache: { samples in
            try OriginalVoiceCache.save(samples, messageID: next.id, text: next.voiceText)
        }) { buffer in
            try await api.speech(next.voiceText, waitForSlot: true) { data in try buffer.append(data) }
            try Task.checkCancellation()
        }
        lookahead = (next.id, stream)
    }
    func speak(_ text: String, api: MobileAPI, messageID: UUID? = nil, next: ChatItem? = nil) {
        let prepared = lookahead?.id == messageID ? lookahead?.stream : nil
        if prepared != nil { lookahead = nil }
        stopRecording(); stopPlayback(releaseSession: false)
        consumingLookahead = prepared
        let id = UUID(); streamID = id
        playingMessageID = messageID
        currentReplyID = messageID
        finishedReplyID = nil
        streamTask = Task { @MainActor [weak self] in
            guard let self else { return }
            let started = ContinuousClock.now
            var firstScheduleMS: Double?
            var completePCM = Data()
            var playbackStage = "audio_session"
            do {
                if let messageID, let audio = OriginalVoiceCache.read(messageID, text: text) {
                    try await self.play(audio); self.playingMessageID = messageID
                    let output = self.outputDiagnostics()
                    Task { try? await api.event(kind: "delivery", body: output.merging([
                        "stage": "audio_cache_player_started"
                    ]) { _, new in new }) }
                    self.streamStatus = "Loki 正在说话"; self.streamTask = nil
                    self.consumingLookahead = nil; self.prefetch(next, api: api); return
                }
                self.playing = true; self.streamStatus = "正在启动语音…"
                try await self.audioSession.playback()
                try Task.checkCancellation()
                playbackStage = "player_start"
                try self.pcm.start(); self.streamStatus = "等待首段原声…"
                self.pcm.firstScheduled = { [weak self] in
                    let parts = started.duration(to: .now).components
                    firstScheduleMS = Double(parts.seconds) * 1000 + Double(parts.attoseconds) / 1e15
                    self?.streamStatus = "Loki 正在说话"
                    // Request one next sentence while these samples are playing.
                    self?.prefetch(next, api: api)
                }
                self.pcm.rebuffering = { [weak self] in self?.streamStatus = "正在缓冲原声…" }
                playbackStage = "stream"
                if let prepared {
                    try await prepared.consume { [weak self] data in
                        guard let self, self.streamID == id else { throw CancellationError() }
                        try await self.pcm.append(data); completePCM.append(data)
                    }
                } else {
                    try await api.speech(text) { [weak self] data in
                        guard let self, self.streamID == id else { throw CancellationError() }
                        try await self.pcm.append(data); completePCM.append(data)
                    }
                }
                self.consumingLookahead = nil
                // Also covers very short final audio that starts only at drain.
                self.prefetch(next, api: api)
                playbackStage = "player_drain"
                try await self.pcm.drain()
                guard self.streamID == id else { return }
                let parts = started.duration(to: .now).components
                let totalMS = Double(parts.seconds) * 1000 + Double(parts.attoseconds) / 1e15
                let underruns = self.pcm.underrunCount
                let output = self.outputDiagnostics()
                Task { try? await api.event(kind: "delivery", body: output.merging(["stage": "audio_player_finished",
                    "first_schedule_ms": firstScheduleMS ?? -1, "player_duration_ms": totalMS,
                    "underruns": underruns, "scope": "player_only_not_human_heard"]) { _, new in new }) }
                self.pcm.stop(); self.playing = false; self.playingMessageID = nil; self.streamTask = nil
                if let messageID { try? OriginalVoiceCache.save(completePCM, messageID: messageID, text: text) }
                self.finishedReplyID = self.currentReplyID
                self.currentReplyID = nil
                self.finishPlaybackWaiter(true)
                self.scheduleIdleRelease()
            } catch {
                guard self.streamID == id else { return }
                self.pcm.stop(); self.playing = false; self.playingMessageID = nil; self.streamTask = nil
                if !(error is CancellationError) {
                    self.errorMessage = self.playbackError(error)
                    let failure = error as NSError
                    let stage = playbackStage
                    Task { try? await api.event(kind: "delivery", body: ["stage": "audio_player_failed",
                        "player_stage": stage, "error_domain": failure.domain, "error_code": failure.code]) }
                }
                self.audioSession.release()
                self.finishPlaybackWaiter(false)
            }
        }
    }
    private func outputDiagnostics() -> [String: Any] {
        let session = AVAudioSession.sharedInstance()
        return ["output_ports": session.currentRoute.outputs.map { $0.portType.rawValue },
                "output_volume": session.outputVolume]
    }
    func systemRead(_ text: String) {
        stopRecording(); stopPlayback()
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio)
        try? AVAudioSession.sharedInstance().setActive(true)
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        synthesizer.speak(utterance)
    }
    func startRecording(forCall: Bool = false) async throws {
        guard !recording else { return }
        let mic: Bool = await withCheckedContinuation { continuation in
            AVAudioApplication.requestRecordPermission { continuation.resume(returning: $0) }
        }
        guard mic else { throw LokiError.message("请允许 Loki 使用麦克风录音。") }
        try Task.checkCancellation()
        guard UIApplication.shared.applicationState == .active else { throw LokiError.message("请回到 Loki 页面后录音。") }
        stopPlayback(releaseSession: false); stopRecording()
        let id = UUID()
        let clip = RecordedVoice(id: id, duration: 0)
        try await audioSession.recording(forCall: forCall)
        try Task.checkCancellation()
        let value = try AVAudioRecorder(url: clip.url, settings: [AVFormatIDKey: kAudioFormatMPEG4AAC,
            AVSampleRateKey: 24_000, AVNumberOfChannelsKey: 1, AVEncoderBitRateKey: 64_000,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue])
        value.isMeteringEnabled = true
        guard value.prepareToRecord(), value.record(forDuration: 90) else { throw LokiError.message("无法开始录音。") }
        value.isMeteringEnabled = true
        recorder = value; recordingID = id; recordingForCall = forCall
        recording = true; recordingSeconds = 0
        do { try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete], ofItemAtPath: try clip.url.path) }
        catch { stopRecording(keep: false); throw error }
        recordingTimer = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(for: .milliseconds(100)) } catch { return }
                guard let self, let recorder = self.recorder else { return }
                if recorder.currentTime > 0 { self.recordingSeconds = recorder.currentTime }
                if !recorder.isRecording || self.recordingSeconds >= 89.8 { self.stopRecording(); return }
            }
        }
    }
    var microphoneLevel: Float {
        recorder?.updateMeters()
        guard let recorder else { return -160 }
        return max(recorder.averagePower(forChannel: 0), recorder.peakPower(forChannel: 0) - 6)
    }
    @discardableResult func stopRecording(keep: Bool = true) -> RecordedVoice? {
        guard let recorder, let id = recordingID else { return nil }
        let duration = recorder.currentTime > 0 ? recorder.currentTime : recordingSeconds
        recorder.stop(); recordingTimer?.cancel(); recordingTimer = nil
        self.recorder = nil; recordingID = nil; recording = false; recordingSeconds = 0
        if !playing { audioSession.release() }
        let clip = RecordedVoice(id: id, duration: duration)
        guard keep, duration >= 0.2 else {
            let path = try? clip.url
            if let path { try? FileManager.default.removeItem(at: path) }
            return nil
        }
        if !recordingForCall { draftRecording = clip }
        return clip
    }
    func discardDraft() {
        if let clip = draftRecording {
            let path = try? clip.url
            if let path { try? FileManager.default.removeItem(at: path) }
        }
        draftRecording = nil
    }
    func recordedPlaybackFraction(for id: UUID) -> Double? {
        guard playing, playingMessageID == id, let player, player.duration > 0 else { return nil }
        return min(1, max(0, player.currentTime / player.duration))
    }

    func playRecording(_ clip: RecordedVoice, messageID: UUID? = nil) {
        stopPlayback(releaseSession: false)
        let id = streamID
        streamTask = Task { @MainActor [weak self] in
            guard let self else { return }
            do {
                try await self.play(clip.data())
                guard self.streamID == id else { return }
                self.playingMessageID = messageID ?? clip.id; self.streamTask = nil
            } catch {
                guard self.streamID == id else { return }
                if !(error is CancellationError) { self.errorMessage = self.playbackError(error) }
                self.releaseAudioSessionIfIdle()
            }
        }
    }
    nonisolated func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        Task { @MainActor [weak self] in
            guard let self, self.player === player else { return }
            let next = self.lookahead; self.lookahead = nil
            if flag, let id = self.currentReplyID { self.finishedReplyID = id }
            self.finishPlaybackWaiter(flag)
            self.stopPlayback(releaseSession: !flag)
            if flag { self.lookahead = next } else { next?.stream.cancel() }
            if flag { self.scheduleIdleRelease() }
        }
    }
}
