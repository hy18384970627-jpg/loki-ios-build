import Foundation
import Combine
import FamilyControls
import DeviceActivity

@MainActor final class FocusService: ObservableObject {
    @Published var selection = FocusState.selection {
        didSet {
            FocusState.selection = selection; try? PrivateFiles.save(selection, "focus-selection.json")
            if FocusState.expires != nil {
                FocusState.store.shield.applications = selection.applicationTokens.isEmpty ? nil : selection.applicationTokens
                FocusState.store.shield.applicationCategories = selection.categoryTokens.isEmpty ? nil : .specific(selection.categoryTokens)
                FocusState.store.shield.webDomains = selection.webDomainTokens.isEmpty ? nil : selection.webDomainTokens
            }
            if NightFocusState.enabled {
                NightFocusState.clearShield()
                if let start = FocusState.defaults?.object(forKey: "nightStartMinute") as? Int,
                   let end = FocusState.defaults?.object(forKey: "nightEndMinute") as? Int {
                    do { try scheduleNight(start: start, end: end) }
                    catch { stopNight(); status = "选择已保存；夜间规则需重新启用。" }
                }
            }
        }
    }
    @Published var status = "请选择允许 Loki 限制的应用"
    @Published var authorized = AuthorizationCenter.shared.authorizationStatus == .approved
    @Published var autonomyEnabled = FocusState.defaults?.object(forKey: "lokiAppControlAllowed") as? Bool ?? true {
        didSet {
            FocusState.defaults?.set(autonomyEnabled, forKey: "lokiAppControlAllowed")
            if !autonomyEnabled {
                if FocusState.defaults?.string(forKey: "focusSource") == "loki" { stop() }
                stopNight()
            }
        }
    }
    init() {
        if FocusState.defaults?.data(forKey: "focusSelection") == nil {
            selection = PrivateFiles.load("focus-selection.json", fallback: FamilyActivitySelection())
            FocusState.selection = selection
        }
        refresh()
    }
    func authorize() async throws {
        refresh()
        if AuthorizationCenter.shared.authorizationStatus != .approved {
            try await AuthorizationCenter.shared.requestAuthorization(for: .individual)
        }
        refresh()
    }
    func start(minutes: Int, source: String = "manual") throws {
        guard AuthorizationCenter.shared.authorizationStatus == .approved else {
            throw LokiError.message("请先授权屏幕使用时间。")
        }
        guard (15...720).contains(minutes) else { throw LokiError.message("应用限制时长须为15分钟至12小时。") }
        guard !selection.applicationTokens.isEmpty || !selection.categoryTokens.isEmpty || !selection.webDomainTokens.isEmpty else {
            throw LokiError.message("请先选择需要限制的应用或类别。")
        }
        guard FocusState.defaults != nil else { throw LokiError.message("App Group 尚未正确签名。") }
        let end = Date().addingTimeInterval(Double(minutes * 60))
        let calendar = Calendar.current
        let components: Set<Calendar.Component> = [.year, .month, .day, .hour, .minute, .second]
        let schedule = DeviceActivitySchedule(intervalStart: calendar.dateComponents(components, from: Date()),
            intervalEnd: calendar.dateComponents(components, from: end), repeats: false)
        // Register the end callback before applying a shield.
        try DeviceActivityCenter().startMonitoring(FocusState.activity, during: schedule)
        FocusState.selection = selection
        FocusState.defaults?.set(end, forKey: "focusExpires")
        FocusState.defaults?.set(source, forKey: "focusSource")
        FocusState.store.shield.applications = selection.applicationTokens.isEmpty ? nil : selection.applicationTokens
        FocusState.store.shield.applicationCategories = selection.categoryTokens.isEmpty ? nil : .specific(selection.categoryTokens)
        FocusState.store.shield.webDomains = selection.webDomainTokens.isEmpty ? nil : selection.webDomainTokens
        status = "专注中，到 \(end.formatted(date: .omitted, time: .shortened))。可随时在这里结束。"
    }
    func stop() {
        FocusState.clear()
        NightFocusState.clearShield()
        DeviceActivityCenter().stopMonitoring([FocusState.activity])
        status = "已解除 Loki 设置的应用限制"
    }
    func refresh() {
        authorized = AuthorizationCenter.shared.authorizationStatus == .approved
        if !authorized && AuthorizationCenter.shared.authorizationStatus == .denied && FocusState.defaults?.bool(forKey: "screenTimeWasApproved") == true {
            // Apple invalidates old selection tokens on revocation, even if their
            // saved JSON remains decodable. Never claim a stale token was applied.
            FocusState.defaults?.set(false, forKey: "screenTimeWasApproved")
            selection = FamilyActivitySelection(); stop(); stopNight()
        }
        if authorized { FocusState.defaults?.set(true, forKey: "screenTimeWasApproved") }
        FocusState.clearIfExpired()
        if !authorized { status = "等待屏幕使用时间授权；系统撤销授权后需要重新选择应用。"; return }
        if let end = FocusState.expires {
            status = "专注至 \(end.formatted(date: .omitted, time: .shortened))"
        } else { status = "已授权，已保存 \(selection.applicationTokens.count) 个应用、\(selection.categoryTokens.count) 个类别和\(selection.webDomainTokens.count) 个网站。" }
    }
    var chatContext: [String: Any] {
        refresh()
        return ["authorized": authorized, "autonomy_enabled": autonomyEnabled,
            "selection_count": selection.applicationTokens.count + selection.categoryTokens.count + selection.webDomainTokens.count,
            "active_until": FocusState.expires?.timeIntervalSince1970 ?? 0,
            "scope": "Only owner-selected opaque app/category/domain tokens. Screen Time shields, also called app locks. No app list upload.",
            "night_rule_enabled": NightFocusState.enabled,
            "night_shield_active": NightFocusState.store.shield.applications != nil || NightFocusState.store.shield.applicationCategories != nil,
            "last_receipt": FocusState.defaults?.string(forKey: "lastLokiAppControlReceipt") ?? ""]
    }
    func apply(_ control: AppControl) -> (note: String, completed: Bool) {
        let previous: [String: String] = PrivateFiles.load("app-control-receipts.json", fallback: [:])
        if let note = previous[control.id.uuidString] { return (note, false) }
        var ledger = previous
        do {
            refresh()
            guard control.action == "unlock" || (autonomyEnabled && authorized) else { throw LokiError.message("聊天锁应用权限或系统授权尚未开启。") }
            ledger[control.id.uuidString] = "这次锁应用操作已领取，结果尚未核实；不会自动重复。"
            try PrivateFiles.save(ledger, "app-control-receipts.json")
            switch control.action {
            case "lock":
                guard let minutes = control.minutes else { throw LokiError.message("缺少锁定时长。") }
                try start(minutes: minutes, source: "loki")
            case "unlock": stop(); NightFocusState.clearShield()
            case "night_schedule":
                guard let start = control.start_minute, let end = control.end_minute else { throw LokiError.message("缺少夜间时间范围。") }
                try scheduleNight(start: start, end: end)
            default: throw LokiError.message("不支持这项应用限制请求。")
            }
            let note = control.action == "unlock" ? "已解除 Loki 的本次锁定；每日限额独立保留。" : control.action == "night_schedule" ? "夜间规则已交给系统：所选应用使用满1分钟后锁定，到窗口结束解除。" : "已应用所选应用的系统屏蔽，至 \(FocusState.expires?.formatted() ?? "指定时间")。"
            ledger[control.id.uuidString] = note; try PrivateFiles.save(ledger, "app-control-receipts.json")
            FocusState.defaults?.set(note, forKey: "lastLokiAppControlReceipt")
            return (note, true)
        } catch {
            let note = "锁应用执行结果未确认：\(error.localizedDescription)"
            FocusState.defaults?.set(note, forKey: "lastLokiAppControlReceipt")
            return (note, false)
        }
    }
    func scheduleNight(start: Int, end: Int) throws {
        guard authorized, autonomyEnabled, (0..<1440).contains(start), (0..<1440).contains(end),
              (15...720).contains((end - start + 1440) % 1440),
              !selection.applicationTokens.isEmpty || !selection.categoryTokens.isEmpty || !selection.webDomainTokens.isEmpty else {
            throw LokiError.message("需要授权、选择应用，以及15分钟至12小时的夜间窗口。")
        }
        let schedule = DeviceActivitySchedule(intervalStart: DateComponents(hour: start / 60, minute: start % 60),
            intervalEnd: DateComponents(hour: end / 60, minute: end % 60), repeats: true)
        let event = DeviceActivityEvent(applications: selection.applicationTokens, categories: selection.categoryTokens,
            webDomains: selection.webDomainTokens, threshold: DateComponents(minute: 1))
        try DeviceActivityCenter().startMonitoring(NightFocusState.activity, during: schedule,
            events: [NightFocusState.event: event])
        NightFocusState.enabled = true
        FocusState.defaults?.set(start, forKey: "nightStartMinute"); FocusState.defaults?.set(end, forKey: "nightEndMinute")
    }
    func stopNight() {
        NightFocusState.enabled = false; NightFocusState.clearShield()
        DeviceActivityCenter().stopMonitoring([NightFocusState.activity])
    }
}
