import SwiftUI

struct MiniCallView: View {
    @EnvironmentObject private var app: AppState
    @EnvironmentObject private var call: CallSession
    @State private var point: CGPoint?
    var body: some View {
        GeometryReader { geometry in
            let width: CGFloat = 180
            let height: CGFloat = 70
            let minX = width / 2 + 12
            let maxX = max(minX, geometry.size.width - minX)
            let minY = height / 2 + 12
            let maxY = max(minY, geometry.size.height - minY)
            let location = point ?? CGPoint(x: maxX, y: min(maxY, minY + 74))
            HStack(spacing: 8) {
                Button { call.restore() } label: {
                    HStack(spacing: 8) {
                        LokiPortrait(size: 38)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(call.startedAt, style: .timer).monospacedDigit().font(.subheadline)
                            Text(call.muted ? "已静音" : (app.voiceStage.isEmpty ? "通话中" : app.voiceStage))
                                .font(.caption2).lineLimit(1)
                        }
                    }.frame(maxWidth: .infinity, alignment: .leading)
                }.accessibilityLabel("返回 Loki 通话")
                Button { call.end() } label: {
                    Image(systemName: "phone.down.fill").foregroundStyle(.white)
                        .frame(width: 32, height: 36).background(.red, in: Capsule())
                }.accessibilityLabel("挂断通话")
            }.buttonStyle(.plain).padding(10).frame(width: width, height: height)
                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18))
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(.white.opacity(0.16)))
                .shadow(color: .black.opacity(0.3), radius: 12, y: 5)
                .contentShape(RoundedRectangle(cornerRadius: 18))
                .simultaneousGesture(DragGesture(minimumDistance: 8, coordinateSpace: .named("callCanvas"))
                    .onChanged { value in point = CGPoint(x: min(max(value.location.x, minX), maxX), y: min(max(value.location.y, minY), maxY)) })
                .position(x: min(max(location.x, minX), maxX), y: min(max(location.y, minY), maxY))
        }.coordinateSpace(name: "callCanvas")
    }
}
