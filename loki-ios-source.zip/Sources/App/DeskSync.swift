import Foundation

/// Keeps the existing desk snapshot without creating a scene or updating view state.
actor DeskSync {
    static let shared = DeskSync()
    private var refreshing = false
    private var revision: String?

    private struct Snapshot: Decodable {
        struct Contents: Decodable { let schema: String }
        let data: Contents
        let revision: String
    }

    func refresh(api: MobileAPI) async throws {
        guard !refreshing else { return }
        refreshing = true
        defer { refreshing = false }
        let data = try await api.data("/v1/desk", timeout: 8)
        try Task.checkCancellation()
        let snapshot = try JSONDecoder().decode(Snapshot.self, from: data)
        guard snapshot.data.schema == "loki_desk_v1" else {
            throw LokiError.message("书桌数据版本不匹配。")
        }
        guard snapshot.revision != revision else { return }
        try data.write(to: PrivateFiles.url("desk-cache.json"), options: [.atomic, .completeFileProtection])
        revision = snapshot.revision
    }
}
