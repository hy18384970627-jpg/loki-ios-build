import Foundation

/// Disk decoding and sync run away from the main actor. Concurrent readers share one fetch.
actor DeskSync {
    static let shared = DeskSync()
    private var refreshTask: Task<Void, Error>?
    private var revision: String?

    private struct Snapshot: Decodable {
        struct Contents: Decodable { let schema: String }
        let data: Contents
        let revision: String
    }

    func refresh(api: MobileAPI) async throws {
        if let refreshTask { return try await refreshTask.value }
        let task = Task { try await fetch(api: api) }
        refreshTask = task
        defer { refreshTask = nil }
        try await task.value
    }

    func cached() -> DeskEnvelope? {
        PrivateFiles.load("desk-cache.json", fallback: nil)
    }

    private func fetch(api: MobileAPI) async throws {
        let data = try await api.data("/v1/desk", timeout: 8)
        try Task.checkCancellation()
        let snapshot = try JSONDecoder().decode(Snapshot.self, from: data)
        guard snapshot.data.schema == "loki_desk_v1" else {
            throw LokiError.message("书桌数据版本不匹配。")
        }
        guard snapshot.revision != revision else { return }
        try data.write(to: PrivateFiles.url("desk-cache.json"), options: [.atomic, .completeFileProtection])
        revision = snapshot.revision
    }
}
