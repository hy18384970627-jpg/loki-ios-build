import Foundation

/// Private local outbox. Never contains pairing credentials.
struct OutgoingMessage: Codable {
    let id: UUID
    var text: String
    var image: Data?
    var recording: RecordedVoice?
    var inCall = false
    var requestBody: Data?
    var nativeActionStarted = false
    var serverAccepted: Bool?
    var retryRequested: Bool?
    var steerTargetID: UUID?
    var createdAt = Date()
}

enum MessageDelivery: String, Codable {
    case queued, steering, sending, waitingReply, failed, sent
}

enum OutgoingRecovery {
    static func restore(_ saved: [ChatItem], drafts: [OutgoingMessage]) -> [ChatItem] {
        var messages = saved
        for index in messages.indices {
            if let state = messages[index].delivery, [.queued, .steering, .sending, .waitingReply].contains(state) {
                messages[index].delivery = messages[index].acceptedByServer == true ? .waitingReply : state
            }
        }
        for draft in drafts.sorted(by: { $0.createdAt < $1.createdAt }) where !messages.contains(where: { $0.id == draft.id }) {
            var item = ChatItem(role: "user", text: draft.text + (draft.image == nil ? "" : "\n[附照片]"), id: draft.id)
            item.recordedVoice = draft.recording; item.delivery = draft.serverAccepted == true ? .waitingReply : .queued
            item.acceptedByServer = draft.serverAccepted
            messages.append(item)
        }
        return messages
    }
}
