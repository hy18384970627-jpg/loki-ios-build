import Foundation
import SwiftUI
import AlarmKit
import CryptoKit

private struct LokiAlarmMetadata: AlarmMetadata {}

@MainActor final class AlarmService: ObservableObject {
    @Published var saved: [SavedAlarm] = PrivateFiles.load("alarms.json", fallback: [])
    @Published var courseStatus = "课表自动闹钟未开启"
    @Published private(set) var courseSyncing = false
    var courseEnabled: Bool { UserDefaults.standard.bool(forKey: "courseAlarmsEnabled") }
    private var courseSuppressed: [String] = PrivateFiles.load("course-alarm-skips.json", fallback: [])
    private var courseEpoch = UUID()
    struct SavedAlarm: Identifiable, Codable {
        let id: UUID
        let title: String
        let date: Date
        var source: String? = nil
        var sourceKey: String? = nil
    }
    @discardableResult func schedule(title: String, at date: Date, id: UUID = UUID(),
                                    source: String? = nil, sourceKey: String? = nil) async throws -> SavedAlarm {
        guard date > Date() else { throw LokiError.message("闹钟时间需要晚于现在。") }
        let manager = AlarmManager.shared
        var authorization = manager.authorizationState
        if authorization != .authorized { authorization = try await manager.requestAuthorization() }
        guard authorization == .authorized else { throw LokiError.message("闹钟权限未开启。") }
        if (try? manager.alarms.contains(where: { $0.id == id })) == true,
           let old = saved.first(where: { $0.id == id }) { return old }
        let alert = AlarmPresentation.Alert(title: LocalizedStringResource(stringLiteral: title),
            stopButton: AlarmButton(text: "停止", textColor: .white, systemImageName: "stop.circle"))
        let attributes = AlarmAttributes(presentation: AlarmPresentation(alert: alert),
                                         metadata: LokiAlarmMetadata(), tintColor: Color.green)
        let configuration = AlarmManager.AlarmConfiguration.alarm(schedule: .fixed(date), attributes: attributes)
        _ = try await manager.schedule(id: id, configuration: configuration)
        let item = SavedAlarm(id: id, title: title, date: date, source: source, sourceKey: sourceKey)
        saved.removeAll { $0.id == id }; saved.append(item)
        try PrivateFiles.save(saved, "alarms.json")
        return item
    }
    func cancel(_ alarm: SavedAlarm) throws {
        try AlarmManager.shared.cancel(id: alarm.id)
        if alarm.source == "course", let key = alarm.sourceKey {
            courseSuppressed.append(key)
            try PrivateFiles.save(courseSuppressed, "course-alarm-skips.json")
        }
        saved.removeAll { $0.id == alarm.id }
        try PrivateFiles.save(saved, "alarms.json")
    }
    func refresh() {
        // Local schedule receipts are not evidence the user heard/dismissed an alarm.
        guard let current = try? AlarmManager.shared.alarms else { return }
        let ids = Set(current.map(\.id))
        saved.removeAll { !ids.contains($0.id) }
        try? PrivateFiles.save(saved, "alarms.json")
    }
    struct ChatResult {
        let note: String
        let payload: [String: Any]
    }
    func chatSnapshot() -> [String: Any] {
        guard AlarmManager.shared.authorizationState == .authorized,
              let system = try? AlarmManager.shared.alarms else {
            return ["verified": false, "note": "System alarm list unavailable; saved history alone is not proof."]
        }
        let ids = Set(system.map(\.id))
        let upcoming = saved.filter { ids.contains($0.id) && $0.date > Date() }.sorted { $0.date < $1.date }
        return ["verified": true, "scope": "Loki-owned AlarmKit alarms only", "course_auto_enabled": courseEnabled,
                "upcoming": upcoming.prefix(6).map { ["at": $0.date.timeIntervalSince1970, "title": String($0.title.prefix(60))] as [String: Any] }]
    }
    func handleChat(_ text: String, requestID: UUID, api: MobileAPI, health: [String: Any]? = nil,
                    confirmedDate: Date? = nil) async -> ChatResult? {
        func result(_ action: String, _ state: String, _ note: String, extra: [String: Any] = [:]) -> ChatResult {
            .init(note: note, payload: extra.merging(["action": action, "state": state, "note": note]) { _, b in b })
        }
        do {
            var intent = AlarmChatIntent.parse(text)
            if case .confirm = intent, let confirmedDate { intent = .specific(confirmedDate) }
            switch intent {
            case .none: return nil
            case .wakePlan:
                let plan = try await api.wakePlan(id: requestID, message: text, health: health)
                guard plan.state == "proposed", let at = plan.at, at.isFinite,
                      at > Date().timeIntervalSince1970, at < Date().timeIntervalSince1970 + 3 * 86400 else {
                    return result("alarm", "needs_time", plan.note)
                }
                let date = Date(timeIntervalSince1970: at)
                refresh()
                // Reuse an already scheduled course alarm at this exact wake time.
                let alarm: SavedAlarm
                if let old = saved.first(where: { abs($0.date.timeIntervalSince(date)) < 1 }) { alarm = old }
                else { alarm = try await schedule(title: "Loki · 起床", at: date, id: requestID, source: "chat") }
                var extra: [String: Any] = ["at": alarm.date.timeIntervalSince1970, "planning_note": plan.note]
                if let start = plan.expected_sleep_start { extra["expected_sleep_start"] = start }
                if let hours = plan.target_hours { extra["target_hours"] = hours }
                return result("alarm", "completed", "起床闹钟已由系统接受：\(alarm.date.formatted())", extra: extra)
            case .confirm, .needsTime: return result("alarm", "needs_time", "还没有创建闹钟，请告诉我具体日期和时间，例如今天上午 11 点。")
            case .specific(let date):
                refresh()
                let alarm: SavedAlarm
                if let old = saved.first(where: { abs($0.date.timeIntervalSince(date)) < 1 }),
                   (try? AlarmManager.shared.alarms.contains(where: { $0.id == old.id })) == true {
                    alarm = old
                } else {
                    alarm = try await schedule(title: "Loki", at: date, id: requestID, source: "chat")
                }
                return result("alarm", "completed", "系统闹钟已设：\(alarm.date.formatted())", extra: ["at": alarm.date.timeIntervalSince1970])
            case .stopCourse:
                try stopCourseAlarms()
                return result("course_alarm", "disabled", "已关闭课表自动闹钟，手动闹钟保留。")
            case .course(let day, let lead):
                if let day {
                    let plan = try await api.coursePlan()
                    guard plan.available, plan.policy == "first_morning_lesson_only_v2" else { throw LokiError.message("尚未读到已核实的上午起床课表，请稍后同步。") }
                    let formatter = DateFormatter(); formatter.calendar = Calendar(identifier: .gregorian)
                    formatter.locale = Locale(identifier: "en_US_POSIX"); formatter.timeZone = .current; formatter.dateFormat = "yyyy-MM-dd"
                    guard let lesson = plan.items.first(where: { $0.day == formatter.string(from: day) }) else {
                        return result("course_alarm", "no_class", "已核实的课表中，这一天上午没有课；未创建课表起床闹钟。")
                    }
                    let date = Date(timeIntervalSince1970: lesson.start_at - Double(lead * 60))
                    let alarm = try await schedule(title: "Loki · \(lesson.title)", at: date, id: requestID, source: "chat")
                    return result("course_alarm", "completed", "已设课前 \(lead) 分钟的系统闹钟：\(alarm.date.formatted())", extra: ["at": alarm.date.timeIntervalSince1970, "course": lesson.title])
                }
                let authorization = try await AlarmManager.shared.requestAuthorization()
                guard authorization == .authorized else { throw LokiError.message("需要允许 Loki 创建系统闹钟。") }
                UserDefaults.standard.set(true, forKey: "courseAlarmsEnabled")
                UserDefaults.standard.set(lead, forKey: "courseAlarmLeadMinutes")
                let count = try await syncCourses(api: api, force: true)
                return result("course_alarm", courseStatus.contains("失败") ? "partial" : "completed", courseStatus, extra: ["scheduled_count": count, "lead_minutes": lead])
            }
        } catch { return result("alarm", "failed", "未能完成闹钟设置：\(error.localizedDescription)") }
    }
    private static func courseID(_ key: String) -> UUID {
        let bytes = Array(SHA256.hash(data: Data(("loki-course:" + key).utf8)).prefix(16))
        return UUID(uuid: (bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7], bytes[8], bytes[9], bytes[10], bytes[11], bytes[12], bytes[13], bytes[14], bytes[15]))
    }
    @discardableResult func syncCourses(api: MobileAPI, force: Bool = false) async throws -> Int {
        guard courseEnabled else { return 0 }
        guard !courseSyncing else { throw LokiError.message("课表闹钟正在同步，请稍后查看。") }
        let previous = UserDefaults.standard.double(forKey: "courseAlarmLastSync")
        let currentPolicy = UserDefaults.standard.string(forKey: "courseAlarmPolicy") == "morning-only-v2"
        if !force && currentPolicy && Date().timeIntervalSince1970 - previous < 6 * 3600 { return saved.filter { $0.source == "course" && $0.date > Date() }.count }
        guard AlarmManager.shared.authorizationState == .authorized else { throw LokiError.message("课表闹钟等待系统授权，请在闹钟页开启。") }
        courseSyncing = true; defer { courseSyncing = false }
        let generation = courseEpoch
        let plan = try await api.coursePlan()
        guard plan.available, plan.policy == "first_morning_lesson_only_v2" else { throw LokiError.message("尚未取得上午起床闹钟规则，原有闹钟保持不变。") }
        try PrivateFiles.save(plan, "course-plan.json")
        let lead = UserDefaults.standard.integer(forKey: "courseAlarmLeadMinutes")
        let minutes = (5...180).contains(lead) ? lead : 40
        var wanted = Set<UUID>(), failures = 0, count = 0
        var through: Date?
        for lesson in plan.items where !courseSuppressed.contains(lesson.id) {
            guard courseEnabled && generation == courseEpoch else { throw CancellationError() }
            let date = Date(timeIntervalSince1970: lesson.start_at - Double(minutes * 60))
            guard date > Date() else { continue }
            let id = Self.courseID(lesson.id + ":" + String(Int(date.timeIntervalSince1970)))
            wanted.insert(id)
            do {
                try await schedule(title: "Loki · \(lesson.title)", at: date, id: id, source: "course", sourceKey: lesson.id)
                if !courseEnabled || generation != courseEpoch {
                    try? AlarmManager.shared.cancel(id: id); saved.removeAll { $0.id == id }
                    try? PrivateFiles.save(saved, "alarms.json")
                    throw CancellationError()
                }
                count += 1; through = max(through ?? date, date)
            } catch is CancellationError { throw CancellationError() }
            catch { failures += 1 }
        }
        // Only replace obsolete course alarms after the replacement set succeeded.
        if failures == 0 {
            for alarm in saved.filter({ $0.source == "course" && $0.date > Date() && !wanted.contains($0.id) }) {
                do {
                    try AlarmManager.shared.cancel(id: alarm.id); saved.removeAll { $0.id == alarm.id }
                } catch { failures += 1 }
            }
        }
        try PrivateFiles.save(saved, "alarms.json")
        if failures == 0 {
            UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: "courseAlarmLastSync")
            UserDefaults.standard.set("morning-only-v2", forKey: "courseAlarmPolicy")
        }
        courseStatus = "已安排 \(count) 个起床闹钟，仅上午有课的日子，按上午首节课提前 \(minutes) 分钟。"
        if let through { courseStatus += "已排到 \(through.formatted(date: .abbreviated, time: .omitted))。" }
        if failures > 0 { courseStatus += "另有 \(failures) 项失败，原有安排尽量保留，请检查。" }
        return count
    }
    func autoSyncCourses(api: MobileAPI) async {
        guard courseEnabled, !courseSyncing else { return }
        do { try await syncCourses(api: api) } catch { courseStatus = error.localizedDescription }
    }
    func enableCourses(api: MobileAPI) async {
        let result = await handleChat("按课表自动帮我设闹钟，提前40分钟", requestID: UUID(), api: api)
        if let result { courseStatus = result.note }
    }
    func stopCourseAlarms() throws {
        courseEpoch = UUID()
        UserDefaults.standard.set(false, forKey: "courseAlarmsEnabled")
        var failures = 0
        for alarm in saved.filter({ $0.source == "course" }) {
            do { try AlarmManager.shared.cancel(id: alarm.id); saved.removeAll { $0.id == alarm.id } }
            catch { failures += 1 }
        }
        try PrivateFiles.save(saved, "alarms.json")
        courseStatus = failures == 0 ? "课表自动闹钟已关闭" : "已停用自动安排，另有 \(failures) 个闹钟取消失败，请检查。"
        if failures > 0 { throw LokiError.message(courseStatus) }
    }
}

struct CoursePlan: Codable {
    let available: Bool
    let items: [CourseLesson]
    let revision: String?
    let policy: String?
}
struct CourseLesson: Codable, Identifiable {
    let id: String
    let day: String
    let title: String
    let start_at: Double
}
