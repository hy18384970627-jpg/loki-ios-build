import SwiftUI
import Combine
import FamilyControls
import DeviceActivity

@MainActor final class DailyLimitService: ObservableObject {
    @Published var rules = DailyLimitState.rules
    func add(title: String, minutes: Int, selection: FamilyActivitySelection) throws {
        guard AuthorizationCenter.shared.authorizationStatus == .approved else { throw LokiError.message("请先授权屏幕使用时间。") }
        guard DailyLimitState.defaults != nil else { throw LokiError.message("App Group 不可用。") }
        guard (1...480).contains(minutes), rules.count < 8 else { throw LokiError.message("最多设置 8 个应用，每个限额为 1–480 分钟。") }
        guard selection.applicationTokens.count == 1, selection.categoryTokens.isEmpty, selection.webDomainTokens.isEmpty else {
            throw LokiError.message("请展开类别，只选择一个应用，不要勾选整个类别或网站。")
        }
        guard !rules.contains(where: { !$0.selection.applicationTokens.isDisjoint(with: selection.applicationTokens) }) else {
            throw LokiError.message("这个应用已经设置每日限额，请先移除原限额再调整。")
        }
        let old = rules
        let rule = DailyLimitRule(id: UUID(), title: title.isEmpty ? "每日应用限额" : String(title.prefix(80)),
                                  minutes: minutes, selection: selection)
        rules.append(rule); DailyLimitState.rules = rules
        do { try monitor() }
        catch { rules = old; DailyLimitState.rules = old; throw error }
    }
    func remove(_ rule: DailyLimitRule) throws {
        let old = rules
        rules.removeAll { $0.id == rule.id }; DailyLimitState.rules = rules
        do { try monitor() }
        catch { rules = old; DailyLimitState.rules = old; throw error }
        var blocked = DailyLimitState.blockedIDs; blocked.remove(rule.id.uuidString)
        DailyLimitState.blockedIDs = blocked; DailyLimitState.rebuildShield()
    }
    private func monitor() throws {
        if rules.isEmpty {
            DeviceActivityCenter().stopMonitoring([DailyLimitState.activity])
            DailyLimitState.store.clearAllSettings(); return
        }
        var start = DateComponents(hour: 0, minute: 0, second: 0)
        var end = DateComponents(hour: 23, minute: 59, second: 59)
        start.timeZone = .current; end.timeZone = .current
        let schedule = DeviceActivitySchedule(intervalStart: start, intervalEnd: end, repeats: true)
        let events = Dictionary(uniqueKeysWithValues: rules.map { rule in
            (DeviceActivityEvent.Name("daily." + rule.id.uuidString),
             DeviceActivityEvent(applications: rule.selection.applicationTokens,
                threshold: DateComponents(minute: rule.minutes), includesPastActivity: true))
        })
        try DeviceActivityCenter().startMonitoring(DailyLimitState.activity, during: schedule, events: events)
    }
}

struct DailyLimitsView: View {
    @StateObject private var service = DailyLimitService()
    @EnvironmentObject private var app: AppState
    @EnvironmentObject private var focus: FocusService
    @State private var picker = false
    @State private var title = ""
    @State private var minutes = 120
    @State private var selection = FamilyActivitySelection()
    var body: some View {
        Form {
            Section("每天的使用额度") {
                Text("例如选择抖音、设置 120 分钟。累计达到限额后由系统回调屏蔽，下一天恢复；你可以随时移除限额。").font(.caption)
                Button("授权并选择一个应用") {
                    Task { do { try await focus.authorize(); picker = true }
                           catch { app.tell(error) } }
                }
                ForEach(Array(selection.applicationTokens.enumerated()), id: \.offset) { entry in Label(entry.element) }
                TextField("备注（如抖音）", text: $title)
                Stepper("每天 \(minutes) 分钟", value: $minutes, in: 1...480, step: 1)
                Button("启用每日限额") {
                    do { try service.add(title: title, minutes: minutes, selection: selection)
                         selection = .init(); title = ""; app.notice = "系统已接受每日限额；达到阈值时由扩展应用限制。" }
                    catch { app.tell(error) }
                }
            }
            Section("已设置") {
                ForEach(service.rules) { rule in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(rule.title).font(.headline)
                        ForEach(Array(rule.selection.applicationTokens.enumerated()), id: \.offset) { entry in Label(entry.element) }
                        Text("每天 \(rule.minutes) 分钟").font(.caption)
                        Button("移除此限额", role: .destructive) {
                            do { try service.remove(rule) } catch { app.tell(error) }
                        }
                    }
                }
            }
        }.navigationTitle("每日应用限额")
            .familyActivityPicker(isPresented: $picker, selection: $selection)
            .onAppear { DailyLimitState.resetDayIfNeeded() }
    }
}
