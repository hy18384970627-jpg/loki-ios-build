import Foundation

/// Interjections keep the next already-prefetched sentence, then take priority.
struct SentencePlaybackQueue<Element> {
    private var items: [Element] = []
    var first: Element? { items.first }
    var isEmpty: Bool { items.isEmpty }
    mutating func insert(_ values: [Element], interject: Bool, preservePreparedNext: Bool) {
        if interject { items.insert(contentsOf: values, at: preservePreparedNext ? min(1, items.count) : 0) }
        else { items.append(contentsOf: values) }
    }
    mutating func take() -> Element? { items.isEmpty ? nil : items.removeFirst() }
    mutating func remove(where predicate: (Element) -> Bool) -> [Element] {
        let removed = items.filter(predicate)
        items.removeAll(where: predicate)
        return removed
    }
}
