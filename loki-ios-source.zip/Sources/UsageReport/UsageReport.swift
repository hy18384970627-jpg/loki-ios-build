import DeviceActivity
import SwiftUI
import FamilyControls
import ManagedSettings

private extension DeviceActivityReport.Context {
    static let lokiDaily = Self("LokiDaily")
}

@main struct LokiUsageReport: DeviceActivityReportExtension {
    var body: some DeviceActivityReportScene {
        DailyScene { report in
            ScrollView { VStack(spacing: 16) {
                Image(systemName: "hourglass").font(.largeTitle)
                Text("今日使用时长").font(.headline)
                Text(durationString(report.total)).font(.system(size: 36, weight: .medium, design: .rounded))
                ForEach(report.apps) { row in
                    HStack {
                        if let token = row.application.token { Label(token).labelStyle(.titleAndIcon) }
                        else { Text(row.application.localizedDisplayName ?? "应用") }
                        Spacer()
                        Text(durationString(row.duration)).monospacedDigit()
                    }.padding(.vertical, 5)
                    Divider()
                }
                if report.apps.isEmpty { Text("暂时没有分应用记录。请确认屏幕使用时间已启用并授权。").font(.caption) }
                Text("由系统屏幕使用时间提供，仅在此报告中显示，不上传后端。")
                    .font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
            }.padding().frame(maxWidth: .infinity) }
        }
    }
}

private func durationString(_ duration: TimeInterval) -> String {
    let formatter = DateComponentsFormatter()
    formatter.allowedUnits = [.hour, .minute]; formatter.unitsStyle = .abbreviated
    return formatter.string(from: duration) ?? "0 分钟"
}

private struct AppUsageRow: Identifiable {
    let id = UUID()
    let application: Application
    var duration: TimeInterval
}

private struct DailyUsage {
    let total: TimeInterval
    let apps: [AppUsageRow]
}

private struct DailyScene<Content: View>: DeviceActivityReportScene {
    let context: DeviceActivityReport.Context = .lokiDaily
    let content: (DailyUsage) -> Content
    func makeConfiguration(representing data: DeviceActivityResults<DeviceActivityData>) async -> DailyUsage {
        var total: TimeInterval = 0
        var apps: [AppUsageRow] = []
        for await device in data {
            for await segment in device.activitySegments {
                total += segment.totalActivityDuration
                for await category in segment.categories {
                    for await item in category.applications {
                        if let index = apps.firstIndex(where: { $0.application == item.application }) {
                            apps[index].duration += item.totalActivityDuration
                        } else { apps.append(.init(application: item.application, duration: item.totalActivityDuration)) }
                    }
                }
            }
        }
        return .init(total: total, apps: apps.sorted { $0.duration > $1.duration })
    }
}
