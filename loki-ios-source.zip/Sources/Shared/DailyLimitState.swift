import Foundation
import FamilyControls
import ManagedSettings
import DeviceActivity

struct DailyLimitRule: Codable, Identifiable {
    let id: UUID
    var title: String
    var minutes: Int
    var selection: FamilyActivitySelection
}

enum DailyLimitState {
    static let activity = DeviceActivityName("lokiDailyLimits")
    static let store = ManagedSettingsStore(named: .init("lokiDailyLimits"))
    static var defaults: UserDefaults? { FocusState.defaults }
    static var rules: [DailyLimitRule] {
        get {
            guard let data = defaults?.data(forKey: "dailyLimitRules"),
                  let value = try? JSONDecoder().decode([DailyLimitRule].self, from: data) else { return [] }
            return value
        }
        set { defaults?.set(try? JSONEncoder().encode(newValue), forKey: "dailyLimitRules") }
    }
    static var blockedIDs: Set<String> {
        get { Set(defaults?.stringArray(forKey: "dailyLimitBlockedIDs") ?? []) }
        set { defaults?.set(Array(newValue), forKey: "dailyLimitBlockedIDs") }
    }
    static func resetDayIfNeeded(now: Date = Date()) {
        let components = Calendar.current.dateComponents([.year, .month, .day], from: now)
        let key = "\(TimeZone.current.identifier):\(components.year ?? 0)-\(components.month ?? 0)-\(components.day ?? 0)"
        if defaults?.string(forKey: "dailyLimitDay") != key {
            blockedIDs = []; store.clearAllSettings(); defaults?.set(key, forKey: "dailyLimitDay")
        }
    }
    static func rebuildShield() {
        let tokens = rules.filter { blockedIDs.contains($0.id.uuidString) }
            .reduce(into: Set<ApplicationToken>()) { $0.formUnion($1.selection.applicationTokens) }
        store.shield.applications = tokens.isEmpty ? nil : tokens
    }
    static func reached(_ event: DeviceActivityEvent.Name) {
        resetDayIfNeeded()
        guard let rule = rules.first(where: { event.rawValue == "daily." + $0.id.uuidString }) else { return }
        var ids = blockedIDs; ids.insert(rule.id.uuidString); blockedIDs = ids; rebuildShield()
    }
}
