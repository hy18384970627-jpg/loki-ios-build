import Foundation
import FamilyControls
import ManagedSettings
import DeviceActivity

enum FocusState {
    static let store = ManagedSettingsStore(named: .init("lokiFocus"))
    static let activity = DeviceActivityName("lokiFocus")
    static var defaults: UserDefaults? {
        guard let group = Bundle.main.object(forInfoDictionaryKey: "LokiAppGroup") as? String else { return nil }
        return UserDefaults(suiteName: group)
    }
    static var selection: FamilyActivitySelection {
        get {
            guard let data = defaults?.data(forKey: "focusSelection"),
                  let value = try? JSONDecoder().decode(FamilyActivitySelection.self, from: data) else { return .init() }
            return value
        }
        set { defaults?.set(try? JSONEncoder().encode(newValue), forKey: "focusSelection") }
    }
    static var expires: Date? {
        defaults?.object(forKey: "focusExpires") as? Date
    }
    static func clear() {
        store.clearAllSettings()
        defaults?.removeObject(forKey: "focusExpires")
        defaults?.removeObject(forKey: "focusSource")
    }
    static func clearIfExpired() {
        if let expires, expires <= Date() { clear() }
    }
}
