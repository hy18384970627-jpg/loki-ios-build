import Foundation
import DeviceActivity
import ManagedSettings
import FamilyControls

enum NightFocusState {
    static let activity = DeviceActivityName("lokiNightFocus")
    static let event = DeviceActivityEvent.Name("lokiNightUse")
    static let store = ManagedSettingsStore(named: .init("lokiNightFocus"))
    static var enabled: Bool {
        get { FocusState.defaults?.bool(forKey: "nightFocusEnabled") ?? false }
        set { FocusState.defaults?.set(newValue, forKey: "nightFocusEnabled") }
    }
    static func clearShield() { store.clearAllSettings() }
    static func reached() {
        guard enabled, FocusState.defaults?.object(forKey: "lokiAppControlAllowed") as? Bool ?? true else { return }
        let selection = FocusState.selection
        store.shield.applications = selection.applicationTokens.isEmpty ? nil : selection.applicationTokens
        store.shield.applicationCategories = selection.categoryTokens.isEmpty ? nil : .specific(selection.categoryTokens)
        store.shield.webDomains = selection.webDomainTokens.isEmpty ? nil : selection.webDomainTokens
    }
}
